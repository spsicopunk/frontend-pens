<?php if (!defined('FW')) die('Forbidden');
/**
 * @var string $uri Demo directory url
 */
 
$manifest = array();
$manifest['title'] = esc_html__('Kriya', 'kriya');
$manifest['screenshot'] = get_template_directory_uri(). '/screenshot.png';
$manifest['preview_link'] = 'https://kriyawp.wpengine.com/';