<?php $post_meta = get_post_meta( $post->ID,'_dt_post_settings', TRUE);
	$post_meta = is_array( $post_meta ) ? $post_meta  : array();
	
	$format = get_post_format( $post->ID );

	$show_post_format = kriya_option('pageoptions','post-format-meta'); 
	$show_post_format = isset( $show_post_format )? "" : "hidden";
	
	$show_author_meta = kriya_option('pageoptions','post-author-meta');
	$show_author_meta = isset( $show_author_meta ) ? "" : "hidden";
	
	$show_date_meta = kriya_option('pageoptions','post-date-meta');
	$show_date_meta = isset( $show_date_meta ) ? "" : "hidden";	

	$show_comment_meta = kriya_option('pageoptions','post-comment-meta');
	$show_comment_meta = isset( $show_comment_meta ) ? "" : "hidden";

	$show_category_meta = kriya_option('pageoptions','post-category-meta');
	$show_category_meta = isset( $show_category_meta ) ? "" : "hidden";
	
	$show_tag_meta = kriya_option('pageoptions','post-tag-meta');
	$show_tag_meta = isset( $show_tag_meta ) ? "" : "hidden";?>
<article id="post-<?php the_ID(); ?>" <?php post_class('blog-entry entry-date-left outer-frame-border'); ?>>

	<?php if( array_key_exists('show-featured-image', $post_meta)) :?>
		<!-- Featured Image -->
		<?php if( $format == "image" || empty($format) ) :
				if( has_post_thumbnail() ) :?>
					<div class="entry-thumb">
						<a href="<?php the_permalink();?>" title="<?php printf(esc_attr__('Permalink to %s','kriya'),the_title_attribute('echo=0'));?>"><?php the_post_thumbnail("full");?></a>
					</div><?php
				else:
					$custom_class = "has-no-post-thumbnail";
				endif;
			elseif( $format === "gallery" ) :
				if( array_key_exists("items", $post_meta) ) :
					echo '<div class="entry-thumb">';
					echo '	<ul class="entry-gallery-post-slider">';
							foreach ( $post_meta['items'] as $item ) {
								echo "<li><img src='". esc_url($item)."'/></li>";
                            }
                    echo '	</ul>';
                    echo '</div>';
            	elseif( has_post_thumbnail() ):?>
            		<div class="entry-thumb">
            			<a href="<?php the_permalink();?>" title="<?php printf(esc_attr__('Permalink to %s','kriya'),the_title_attribute('echo=0'));?>"><?php the_post_thumbnail("full");?></a>
            		</div><?php
            	else:
            		$custom_class = "has-no-post-thumbnail";
            	endif;
            elseif( $format === "video" ) :
            	if( array_key_exists('oembed-url', $post_meta) || array_key_exists('self-hosted-url', $post_meta) ) :
            		echo '<div class="entry-thumb">';
                   	echo'	<div class="dt-video-wrap">';
                   			if( array_key_exists('oembed-url', $post_meta) && ! isset( $_COOKIE['dtPrivacyVideoEmbedsDisabled'] ) ) :
                   				echo wp_oembed_get($post_meta['oembed-url']);
                   			elseif( array_key_exists('self-hosted-url', $post_meta) ) :
                   				echo wp_video_shortcode( array('src' => $post_meta['self-hosted-url']) );
                            endif;
                    echo '	</div>';
                    echo '</div>';
                elseif( has_post_thumbnail() ):?>
                	<div class="entry-thumb">
                		<a href="<?php the_permalink();?>" title="<?php printf(esc_attr__('Permalink to %s','kriya'),the_title_attribute('echo=0'));?>"><?php the_post_thumbnail("full");?></a>
	                </div><?php
                else:
                	$custom_class = "has-no-post-thumbnail";
                endif;
            elseif( $format === "audio" ) :
            	if( array_key_exists('oembed-url', $post_meta) || array_key_exists('self-hosted-url', $post_meta) ) :
            		echo '<div class="entry-thumb">';
            			if( array_key_exists('oembed-url', $post_meta) ) :
            				echo wp_oembed_get($post_meta['oembed-url']);
                   		elseif( array_key_exists('self-hosted-url', $post_meta) ) :
                   			$custom_class = "self-hosted-audio";
                   			echo wp_audio_shortcode( array('src' => $post_meta['self-hosted-url']) );
	                   	endif;
               		echo '</div>';
               	elseif( has_post_thumbnail() ):?>
               		<div class="entry-thumb">
               			<a href="<?php the_permalink();?>" title="<?php printf(esc_attr__('Permalink to %s','kriya'),the_title_attribute('echo=0'));?>"><?php the_post_thumbnail("full");?></a>
               		</div><?php
               	else:
               		$custom_class = "has-no-post-thumbnail";
                endif;
            else:
            	if( has_post_thumbnail() ) :?>
            		<div class="entry-thumb">
            			<a href="<?php the_permalink();?>" title="<?php printf(esc_attr__('Permalink to %s','kriya'),the_title_attribute('echo=0'));?>"><?php the_post_thumbnail("full");?></a>
					</div><?php
                else:
                	$custom_class = "has-no-post-thumbnail";
                endif;
            endif;?>		
		<!-- Featured Image -->		
	<?php endif;?>

	<div class="entry-details">

		<?php $tclass = ( ($show_date_meta == "hidden" ) && ($show_comment_meta == "hidden" ) ) ? "hidden" : ""; ?>
		<div class="entry-date <?php echo esc_attr($tclass);?>">
			<!-- date -->
			<div class="<?php echo esc_attr($show_date_meta);?>">
				<span><?php echo get_the_date('d');?></span>
				<?php echo get_the_date('M');?>
            </div><!-- date -->
        </div><!-- .entry-date -->

        <?php $tclass = ( ($show_comment_meta == "hidden") && ($show_author_meta == "hidden" ) && ($show_tag_meta == "hidden" ) && ($show_category_meta == "hidden" ) ) ? "hidden" : ""; ?>
        <div class="entry-meta-data <?php echo esc_attr($tclass);?>">

        	<!-- Author, Comment, Category & Tag -->
        	<p class="author <?php echo esc_attr( $show_author_meta );?>">
                <?php esc_html_e('By','kriya'); ?>
        		<a href="<?php echo get_author_posts_url(get_the_author_meta('ID'));?>" title="<?php esc_attr_e('View all posts by ', 'kriya'); echo get_the_author();?>"><?php echo get_the_author();?></a>
            </p>

            <!-- comment -->
            <p class="<?php echo esc_attr($show_comment_meta);?>"><?php
            	comments_popup_link( '<i class="pe-icon pe-chat"> </i>'.esc_html__(' 0 Comment','kriya'),
            		'<i class="pe-icon pe-chat"> </i>'.esc_html__(' 1 Comment','kriya'),
            		'<i class="pe-icon pe-chat"> </i>'.esc_html__(' % Comments','kriya'),
            		'',
            		'<i class="pe-icon pe-chat"> </i>'.esc_html__(' No Comments','kriya'));?>
           	</p><!-- comment -->

           	<p class="<?php echo esc_attr( $show_category_meta );?> category"> <?php esc_html_e('In','kriya'); echo ' '; the_category(', '); ?></p>

           	<?php the_tags("<p class='tags {$show_tag_meta}'> ",', ',"</p>");?>
           	<!-- Author, Comment, Category & Tag -->
        </div>

        <div class="entry-title">
        	<h4><a href="<?php the_permalink();?>" title="<?php printf(esc_attr__('Permalink to %s','kriya'), the_title_attribute('echo=0'));?>"><?php the_title(); ?></a></h4>
        </div>

        <div class="entry-body">
        	<?php the_content(); ?>
        </div>

        <div class="entry-format <?php echo esc_attr($show_post_format);?>">
        	<a class="ico-format" href="<?php echo esc_url(get_post_format_link( $format ));?>"></a>
        </div>
    </div>
</article>