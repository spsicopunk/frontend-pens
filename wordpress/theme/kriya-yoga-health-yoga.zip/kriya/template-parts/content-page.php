<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>><?php

	the_content();

	wp_link_pages( array(
		'before'      => '<div class="page-links"><span class="page-links-title">' . esc_html__( 'Pages:', 'kriya' ) . '</span>',
		'after'       => '</div>',
		'link_before' => '<span>',
		'link_after'  => '</span>',
		'next_or_number' => 'number',
		'pagelink'    => '%',
		'echo'	=> 1
	) );

	edit_post_link(
		sprintf(
			/* translators: %s: Name of current post */
			esc_html__( 'Edit "%s"', 'kriya' ),
			get_the_title()
		),
		'<span class="edit-link">',
		'</span>'
	);?>
</div>