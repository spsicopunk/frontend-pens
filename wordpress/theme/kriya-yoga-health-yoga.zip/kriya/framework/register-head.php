<?php
/* 
 * Meta tag for viewport scale
 */
if( !function_exists( 'kriya_viewport' )){
function kriya_viewport() {
	if(kriya_option('general', 'enable-responsive')){
		echo "<meta name='viewport' content='width=device-width, initial-scale=1'>\r";
	}
}
}

/**
 * Enqueues scripts
 */
if( !function_exists( 'kriya_scripts' )){
function kriya_scripts() {

	$nicescroll = ( kriya_option("general","enable-nicescroll") ) ? true : false;
	$loader = ( kriya_option("general","enable-loader") ) ? true : false;
	$stickynav = ( kriya_option("layout","layout-stickynav") ) ? true : false;

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}

	wp_enqueue_script('jquery-sticky', get_template_directory_uri().'/js/jquery.sticky.js', array(), false, true);
	wp_enqueue_script('jquery-nicescroll', get_template_directory_uri().'/js/jquery.nicescroll.min.js', array(), false, true);
	wp_enqueue_script('jquery-visualnav', get_template_directory_uri().'/js/jquery.visualNav.min.js', array(), false, true);
	wp_enqueue_script('isotope', get_template_directory_uri().'/js/isotope.pkgd.min.js', array(), false, true);
	wp_enqueue_script('jquery-debouncedresize', get_template_directory_uri().'/js/jquery.debouncedresize.js', array(), false, true);
	wp_enqueue_script('jquery-fitvids', get_template_directory_uri().'/js/jquery.fitvids.js', array(), false, true);
	wp_enqueue_script('jquery-bxslider', get_template_directory_uri().'/js/jquery.bxslider.js', array(), false, true);
	wp_enqueue_script('jquery-downcount', get_template_directory_uri().'/js/jquery.downcount.js', array(), false, true);
	wp_enqueue_script('retina', get_template_directory_uri().'/js/retina.js', array(), false, true);
	wp_enqueue_script('jquery-prettyphoto', get_template_directory_uri().'/js/jquery.prettyphoto.js', array(), false, true);

	wp_enqueue_script('kriya-custom', get_template_directory_uri().'/js/custom.js', array('jquery','jquery-nicescroll'), false, true);

	if( $loader ) {

		wp_enqueue_script('jq.pacemin', get_template_directory_uri().'/js/pace.min.js', array('jquery'), false, false);
		wp_localize_script('jq.pacemin', 'paceOptions', array(
			'restartOnRequestAfter' => 'false',
			'restartOnPushState' => 'false'
		));
	}

	wp_localize_script('jquery-nicescroll', 'kriya_urls', array(
		'ajaxurl' => esc_url( admin_url('admin-ajax.php') ),
		'url' => esc_url( get_site_url() ),
		'stickynav' => esc_js( $stickynav ),
		'loader' => esc_js( $loader ),
		'nicescroll' => esc_js( $nicescroll )
	) );
	
	if( ($custom_js = kriya_option('layout', 'customjs-content')) && kriya_option('layout','enable-customjs') ){		
		$custom_js = stripslashes($custom_js);
    	wp_add_inline_script('kriya-custom', kriya_wp_kses($custom_js, array( "\'", '\"' ) ) );
	}

	$cookiebar = kriya_option('privacy', 'enable-cookie-msgbar');
		if( isset($cookiebar) ) {
			wp_enqueue_script('jq-cookie-js', get_template_directory_uri().'/js/cookieconsent.js', array(), false, true);
		}

		wp_enqueue_script('jq-popup-js', get_template_directory_uri().'/js/magnific/jquery.magnific-popup.min.js', array(), false, true);
	
}
add_action( 'wp_enqueue_scripts', 'kriya_scripts' );
}
/**
 * Enqueues styles.
 */
if( !function_exists( 'kriya_styles' )){
function kriya_styles() {

	$layout_opts = kriya_option('layout');
	$general_opts = kriya_option('general');
	$colors_opts = kriya_option('colors');
	$pageopt_opts = kriya_option('pageoptions');

	if( ! isset( $_COOKIE['dtPrivacyGoogleWebfontsDisabled'] ) ) {
		wp_enqueue_style( 'kriya-fonts', kriya_fonts_url(), array(), null );
	}

	//custom fonts
    wp_add_inline_style('kriya-fonts', kriya_custom_fonts() );

    // font-awesome
	wp_enqueue_style( 'font-awesome', get_template_directory_uri()."/css/font-awesome.min.css", array(), false, 'all'  );

    // stroke-gap-icons
	wp_register_style('stroke-gap-icons', get_template_directory_uri().'/css/stroke-gap-icons-style.css', array(), null );
    wp_enqueue_style( 'stroke-gap-icons' );
	
	// Theme stylesheet.
	wp_enqueue_style( 'kriya-style', get_stylesheet_uri() );

    // prettyPhoto
	wp_enqueue_style( 'prettyPhoto', get_template_directory_uri()."/css/prettyPhoto.css", array(), false, 'all'  );	

	// extra RTL stylesheet
	if ( is_rtl() )
		wp_enqueue_style( 'kriya-rtl', get_template_directory_uri()."/rtl.css", array("kriya-style") );

	// Site icon
	if ( ! function_exists( 'has_site_icon' ) || ! has_site_icon() ) {

		$url = ! empty ( $layout_opts ['favicon-url'] ) ? $layout_opts ['favicon-url'] : get_template_directory_uri() . "/images/favicon.png";
		echo "<link href='$url' rel='shortcut icon' type='image/x-icon' />\n";

		$phone_url = ! empty ( $layout_opts ['apple-favicon'] ) ? $layout_opts ['apple-favicon'] : get_template_directory_uri() . "/images/apple-touch-icon.png";
		echo "<link href='$phone_url' rel='apple-touch-icon-precomposed'/>\n";
	
		$phone_retina_url = ! empty ( $layout_opts ['apple-retina-favicon'] ) ? $layout_opts ['apple-retina-favicon'] : get_template_directory_uri(). "/images/apple-touch-icon-114x114.png";
		echo "<link href='$phone_retina_url' sizes='114x114' rel='apple-touch-icon-precomposed'/>\n";
	
		$ipad_url = ! empty ( $layout_opts ['apple-ipad-favicon'] ) ? $layout_opts ['apple-ipad-favicon'] : get_template_directory_uri() . "/images/apple-touch-icon-72x72.png";
		echo "<link href='$ipad_url' sizes='72x72' rel='apple-touch-icon-precomposed'/>\n";
	
		$ipad_retina_url = ! empty ( $layout_opts ['apple-ipad-retina-favicon'] ) ? $layout_opts ['apple-ipad-retina-favicon'] : get_template_directory_uri() . "/images/apple-touch-icon-144x144.png";
		echo "<link href='$ipad_retina_url' sizes='144x144' rel='apple-touch-icon-precomposed'/>\n";		
	}

	// comingsoon css
	if(isset($pageopt_opts['enable-comingsoon']))
		wp_enqueue_style("comingsoon", get_template_directory_uri()."/css/comingsoon.css", array(), false, 'all' );

	// notfound css
	if ( is_404() )
		wp_enqueue_style("notfound", get_template_directory_uri(). "/css/notfound.css", array(), false, 'all' );

	// loader css
	if(isset($general_opts['enable-loader']))
		wp_enqueue_style("loader", get_template_directory_uri()."/css/loaders.css", array(), false, 'all' );

	// woocommerce css
	if( function_exists( 'is_woocommerce' ) )
		wp_enqueue_style( 'kriya-woo-style', get_template_directory_uri() .'/css/woocommerce.css', 'woocommerce-general-css', false, 'all' );

	// static css
	if(isset($general_opts['enable-staticcss'])) :
		wp_enqueue_style("kriya-static", get_template_directory_uri(). "/style-static.css", array(), false, 'all' );
	else:
		// skin css
		$skin = $colors_opts['theme-skin'];
		if( $skin != 'custom' ):
			wp_enqueue_style("kriya-skin", 	get_template_directory_uri()."/css/skins/$skin/style.css");
		endif;
	endif;

	// responsive css
	if(kriya_option('general', 'enable-responsive'))
		wp_enqueue_style("kriya-responsive", get_template_directory_uri(). "/css/responsive.css", array(), false, 'all' );

	wp_enqueue_style("kriya-animations", get_template_directory_uri(). "/css/animations.css", array(), false, 'all' );

	// show mobile slider
    if(empty($general_opts['show-mobileslider'])):

    	$css = '@media only screen and (max-width:320px), (max-width: 479px), (min-width: 480px) and (max-width: 767px), (min-width: 768px) and (max-width: 959px),
		 (max-width:1200px) { #slider { display:none !important; } }';
    	wp_add_inline_style('kriya-style', wp_kses( $css, array( "\'", '\"' ) ) ); 		
	endif;
	
	// Hide Default Scroll bar of browser
	if( isset( $general_opts['enable-nicescroll'] ) ) {
		
		wp_add_inline_style('kriya-style', '::-webkit-scrollbar { display: none; }' );
	}
	
	// boxed layout css
   	wp_add_inline_style('kriya-style', kriya_boxed_layout() );

	if( class_exists( 'Tribe__Events__Main' ) ) {
		// custom css
		wp_enqueue_style("kriya-tribe-events", get_template_directory_uri(). "/tribe-events/custom.css", array(), false, 'all' );
	}

	// gutenberg css ---------------------------------------------------------------------
	wp_enqueue_style( 'kriya-gutenberg', get_theme_file_uri('/css/gutenberg.css'), false, 'all' );

	$cookie_bar = kriya_option('privacy', 'enable-cookie-msgbar');
		if( isset($cookie_bar) ) {
			wp_enqueue_style( 'kriya-cookie-css', get_template_directory_uri() .'/css/cookieconsent.css', false, 'all' );
		}

		wp_enqueue_style( 'kriya-popup-css', get_template_directory_uri() .'/js/magnific/magnific-popup.css', false, 'all' );
}
add_action( 'wp_enqueue_scripts', 'kriya_styles' , 100 );
}


if( !function_exists( 'kriya_styles_dynamic' )){
function kriya_styles_dynamic() {

	ob_start();

	if( !kriya_opts_get('enable-staticcss') ) :

		// custom colors.php
		$colors_opts = kriya_option('colors');
		$skin	  = $colors_opts['theme-skin'];
		if($skin == 'custom'):
			include_once get_template_directory() . '/css/style-custom-skin.php';
		endif;

		// fonts.php
		include_once get_template_directory() . '/css/style-fonts.php';
	endif;

	// css from theme options
	include_once get_template_directory() . '/css/theme-option-custom-css.php';

	$css = ob_get_contents();

	ob_get_clean();

	$css = kriya_styles_minify( $css );

	wp_register_style( 'kriya-combined', '' );
	wp_enqueue_style( 'kriya-combined' );

	wp_add_inline_style('kriya-combined', $css);
}
add_action( 'wp_enqueue_scripts', 'kriya_styles_dynamic', 200 );
}

/**
 *  Menu
 */
if( !function_exists( 'kriya_wp_split_menu' )){
function kriya_wp_split_menu() {

		//Menu
		$args = array(
			'container'		=> 'false',
			'menu_id'		=> false,
			'fallback_cb'	=> 'kriya_menu_fallback_alt', 
			'depth' 		=> 0,
			'walker' 		=> new Kriya_FrontEndMenuWalker,
		);

	if( is_page_template('tpl-onepage.php') ):
		global $post;
		$page_id = ($post->ID == 0) ? get_queried_object_id() : $post->ID;
		$meta = get_post_meta($page_id, '_tpl_default_settings', true);
		$meta = is_array($meta) ? $meta  : array();

		// Left Menu
		$args['menu_class'] = 'onepage menu menu-left';
		$args['theme_location'] = false;		
		$args['menu'] = $meta['onepage_left_menu'];		
		wp_nav_menu( $args );

		// Right Menu
		$args['menu_class'] = 'onepage menu menu-right';
		$args['theme_location'] = false;		
		$args['menu'] = $meta['onepage_right_menu'];		
		wp_nav_menu( $args );
	else:
		// Left Menu
		$primary = has_nav_menu('primary');
		$secondary = has_nav_menu('secondary');

		if( $primary ) :
			$args['menu_class'] = 'menu menu-left';
			$args['theme_location'] = 'primary';	
			wp_nav_menu( $args );
		endif;

		// Right Menu
		if( $secondary ) :
			$args['menu_class'] = 'menu menu-right';
			$args['theme_location'] = 'secondary';
			wp_nav_menu( $args );	
		endif;

		if( !$primary && !$secondary) {
			kriya_menu_fallback();
		}
	endif;
}
}
/**
 * Menu Fallback
 */
if( !function_exists( 'kriya_menu_fallback' )){
function kriya_menu_fallback() {
	echo '<nav id="main-menu" class="menu-main-menu-container"><ul id="menu-main-menu" class="menu">';
	$args = array(
		'depth' 		=> 0,
		'title_li' 		=> '',
		'echo' 			=> 0,
		'post_type' 	=> 'page',
		'post_status' 	=> 'publish'
	);
	$pages = wp_list_pages($args);
	if ($pages)
		echo "{$pages}";
	echo '</ul></nav>';
}
}
/**
 * Slider
 */
if( !function_exists( 'kriya_slider' )){
function kriya_slider() {

	$slider = '';

	if(is_home() || get_post_type() == 'page' ) {

		if( is_home() )
			$id = get_option('page_for_posts');
		elseif( is_page() )
			$id = kriya_ID();

		$slider_key = get_post_meta( $id, '_tpl_default_settings', true );

		if( is_array( $slider_key) && array_key_exists('show_slider', $slider_key) ) {

			$slider .= '<div id="slider">';

			if( ( $slider_key['slider_type'] == 'revolutionslider' ) && ( array_key_exists( 'revolutionslider_id', $slider_key ) ) ) {
				$slider .= '<div class="dt-sc-main-slider" id="dt-sc-rev-slider">';
				$slider .= do_shortcode('[rev_slider '. $slider_key['revolutionslider_id'] .']');
				$slider .= '</div>';
			} elseif( ( $slider_key['slider_type'] == 'layerslider' ) && ( array_key_exists('layerslider_id', $slider_key) ) ) {
				$slider .= '<div class="dt-sc-main-slider" id="dt-sc-layer-slider">';
				$slider .= do_shortcode('[layerslider id="'. $slider_key['layerslider_id'] .'"]');
				$slider .= '</div>';
			} elseif( ( $slider_key['slider_type'] == 'customslider' ) && ( array_key_exists('customslider_sc', $slider_key) ) ) {
				$slider .= '<div class="dt-sc-main-slider" id="dt-sc-custom-slider">';
				$slider .= kriya_wp_kses(do_shortcode( $slider_key['customslider_sc'] ));
				$slider .= '</div>';
			}
			$slider .= '</div>';
		}
	}

	echo "{$slider}";
}
}

if( !function_exists( 'kriya_fonts_url' )){
function kriya_fonts_url() {	

	$fonts = kriya_fonts();
	$fonts = $fonts['all'];

	$subset = kriya_option('font','font-subset');
	if( $subset )
		$subset = str_replace(' ', '', $subset);

	if( $weight = kriya_option('fonts', 'font-style') )
		$weight = ':'. implode( ',', $weight );

	$selected = kriya_fonts_selected();
	$font_families = array();
	foreach( $selected as $font ) {
		if( in_array( $font, $fonts ) ){
			$font_families[] .= $font . $weight;
		}
	}
	
	$protocol = is_ssl() ? 'https:' : 'http:';
	
	$font_url = add_query_arg( array( 
		'family' => urlencode( implode( '|', $font_families ) ),
		'subset' => urlencode( $subset ),
	), $protocol.'//fonts.googleapis.com/css' );

	return $font_url;
}
}

if( !function_exists( 'kriya_custom_fonts' )){
function kriya_custom_fonts() {
	$fonts 		  = kriya_fonts_selected();
	$font_custom  = kriya_option('fonts','customfont-name');
	$font_custom2 = kriya_option('fonts','customfont2-name');

	$out = '';

	if( $font_custom && in_array( $font_custom, $fonts ) ) {
		$out .= '@font-face {';
			$out .= 'font-family: "'. $font_custom .'";';
			$out .= 'src: url("'. kriya_option('fonts','customfont-eot') .'");';
			$out .= 'src: url("'. kriya_option('fonts','customfont-eot') .'#iefix") format("embedded-opentype"),';
				$out .= 'url("'. kriya_option('fonts','customfont-woff') .'") format("woff"),';
				$out .= 'url("'. kriya_option('fonts','customfont-ttf') .'") format("truetype"),';
				$out .= 'url("'. kriya_option('fonts','customfont-svg') . $font_custom .'") format("svg");';
			$out .= 'font-weight: normal;';
			$out .= 'font-style: normal;';
		$out .= '}';
	}

	if( $font_custom && in_array( $font_custom, $fonts ) ) {
		$out .= '@font-face {';
			$out .= 'font-family: "'. $font_custom2 .'";';
			$out .= 'src: url("'. kriya_option('fonts','customfont2-eot') .'");';
			$out .= 'src: url("'. kriya_option('fonts','customfont2-eot') .'#iefix") format("embedded-opentype"),';
				$out .= 'url("'. kriya_option('fonts','customfont2-woff') .'") format("woff"),';
				$out .= 'url("'. kriya_option('fonts','customfont2-ttf') .'") format("truetype"),';
				$out .= 'url("'. kriya_option('fonts','customfont2-svg') . $font_custom2 .'") format("svg");';
			$out .= 'font-weight: normal;';
			$out .= 'font-style: normal;';
		$out .= '}';
	}

	if( !empty( $out ) )
		return $out;
}
}
if( !function_exists( 'kriya_fonts_selected' )){
function kriya_fonts_selected(){
	$fonts = array();
	
	$font_opts = kriya_option('fonts');
	
	$fonts['content'] 		= !empty ( $font_opts['content-font'] ) 	? 	$font_opts['content-font'] 		: 'Rosario';
	$fonts['menu'] 			= !empty ( $font_opts['menu-font'] ) 		? 	$font_opts['menu-font'] 		: 'Overlock';
	$fonts['title'] 		= !empty ( $font_opts['pagetitle-font'] ) 	? 	$font_opts['pagetitle-font'] 	: 'Bree Serif';
	$fonts['h1'] 		= !empty ( $font_opts['h1-font'] ) 	? 	$font_opts['h1-font'] 		: 'PT Serif';
	$fonts['h2'] 		= !empty ( $font_opts['h2-font'] ) 	? 	$font_opts['h2-font'] 		: 'PT Serif';
	$fonts['h3'] 		= !empty ( $font_opts['h3-font'] ) 	? 	$font_opts['h3-font'] 		: 'PT Serif';
	$fonts['h4'] 		= !empty ( $font_opts['h4-font'] ) 	? 	$font_opts['h4-font'] 		: 'PT Serif';
	$fonts['h5'] 		= !empty ( $font_opts['h5-font'] ) 	? 	$font_opts['h5-font'] 		: 'PT Serif';
	$fonts['h6'] 		= !empty ( $font_opts['h6-font'] ) 	? 	$font_opts['h6-font'] 		: 'PT Serif';

	return array_unique( $fonts );
}
}

/**
 * Boxed layout CSS
 */
if( !function_exists( 'kriya_boxed_layout' )){
function kriya_boxed_layout() {
	$output = '';

	if (kriya_option('layout', 'site-layout') == 'boxed') :

		if (kriya_option('layout', 'bg-type') == 'bg-patterns') :
			$pattern 			= 	kriya_option('layout', 'boxed-layout-pattern');
			$pattern_repeat 	= 	kriya_option('layout', 'boxed-layout-pattern-repeat');
			$pattern_opacity 	= 	kriya_option('layout', 'boxed-layout-pattern-opacity');
			$enable_color 		= 	kriya_option('layout', 'show-boxed-layout-pattern-color');
			$pattern_color 		= 	kriya_option('layout', 'boxed-layout-pattern-color');

			$output .= "body { ";

			if (!empty($pattern)) {
				$output .= "background-image:url('" . get_template_directory_uri() . "/framework/theme-options/images/patterns/{$pattern}');";
			}

			$output .= "background-repeat:$pattern_repeat;";
			if ($enable_color) {
				if (!empty($pattern_opacity)) {
					$color = kriya_hex2rgb($pattern_color);
					$output .= "background-color:rgba($color[0],$color[1],$color[2],$pattern_opacity); ";
				} else {
					$output .= "background-color:$pattern_color;";
				}
			}
			$output .= "}";

		elseif (kriya_option('layout', 'bg-type') == 'bg-custom') :
			$bg 			= 	kriya_option('layout', 'boxed-layout-bg');
			$bg_repeat 		= 	kriya_option('layout', 'boxed-layout-bg-repeat');
			$bg_opacity 	= 	kriya_option('layout', 'boxed-layout-bg-opacity');
			$bg_color 		= 	kriya_option('layout', 'boxed-layout-bg-color');
			$enable_color 	= 	kriya_option('layout', 'show-boxed-layout-bg-color');
			$bg_position 	= 	kriya_option('layout', 'boxed-layout-bg-position');

			$output .= "body { ";

			if (!empty($bg)) {
				$output .= "background-image:url($bg);";
				$output .= "background-repeat:$bg_repeat;";
				$output .= "background-position:$bg_position;";
			}

			if ($enable_color) {
				if (!empty($bg_opacity)) {
					$color = kriya_hex2rgb($bg_color);
					$output .= "background-color:rgba($color[0],$color[1],$color[2],$bg_opacity);";
				} else {
					$output .= "background-color:$bg_color;";
				}
			}
			$output .= "}";
		endif;		
	endif;

	if( !empty($output) )
		return $output;
}
}
/**
 * Adds custom classes to the array of body classes.
 */
if( !function_exists( 'kriya_body_classes' )){
function kriya_body_classes( $classes ) {

	// layout
	$classes[] = 'layout-'. kriya_option('layout','site-layout');

	// header
	$classes[] = kriya_option('layout','header-type');

	// topbar
	$topbar = kriya_option('layout','layout-topbar');
	if(isset($topbar)):
		$classes[] = 'header-with-topbar';
	endif;

	if( is_page() ) {
		$pageid = kriya_ID();
		if(($slider_key = get_post_meta( $pageid, '_tpl_default_settings', true )) && (array_key_exists( 'show_slider', $slider_key )) ) {
			$classes[] = "page-with-slider";
		}
	} elseif( is_home() ) {
		$pageid = get_option('page_for_posts');
		if(($slider_key = get_post_meta( $pageid, '_tpl_default_settings', true )) && (array_key_exists( 'show_slider', $slider_key )) ) {
			$classes[] = "page-with-slider";
		}
	}

	if(is_404()) {
		$classes[] = "type8";
	}

	# Gutenberg Class
	if ( is_singular() && function_exists('has_blocks') && has_blocks() ) {
		$classes[] = 'has-gutenberg-blocks';
	}

	return $classes;
}
add_filter( 'body_class', 'kriya_body_classes' );
}