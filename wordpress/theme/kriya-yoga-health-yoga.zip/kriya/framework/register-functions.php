<?php
/**
 * Sets up theme defaults and registers support for various WordPress features.
 */
if ( ! function_exists( 'kriya_setup' ) ) :

	function kriya_setup() {

		load_theme_textdomain( 'kriya', get_template_directory() . '/languages' );

		add_theme_support( 'automatic-feed-links' );

		add_theme_support( 'title-tag' );

		add_theme_support( 'custom-logo', array(
			'height'      => 240,
			'width'       => 240,
			'flex-height' => true,
		) );

		add_theme_support( 'post-thumbnails', array('post') );

		add_theme_support( 'html5', array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption'
		) );

		add_theme_support( 'post-formats', array(
			'aside',
			'image',
			'video',
			'quote',
			'link',
			'gallery',
			'status',
			'audio',
			'chat'
		) );

		register_nav_menus( array( 
			'primary' 	=> esc_html__( 'Primary Menu', 'kriya' ),
			'secondary' => esc_html__( 'Secondary Menu', 'kriya' )
		) );

		add_theme_support( 'custom-background', array() );

		add_theme_support( 'custom-header', array() );

	}
endif;
add_action( 'after_setup_theme', 'kriya_setup' );

/**
 * Sets the content width in pixels, based on the theme's design and stylesheet.
 */
function kriya_content_width() {
	$GLOBALS['content_width'] = apply_filters( 'kriya_content_width', 840 );
}
add_action( 'after_setup_theme', 'kriya_content_width', 0 );

/*
 * When theme activation, update kriya default option
 */
if (!function_exists('kriya_activation_function')) {

	// check activate theme
	function kriya_activation_function($oldname, $oldtheme=false) {
		if(!in_array($oldname, array('Kriya', 'Kriya Child'))) {
			update_option( 'kriya-opts', kriya_default_option());
		}
	}	
}
add_action("after_switch_theme", "kriya_activation_function", 10 , 2);

/* ---------------------------------------------------------------------------
 *	Under Construction
 * --------------------------------------------------------------------------- */
if( ! function_exists('kriya_under_construction') ){
	function kriya_under_construction(){
		if( ! is_user_logged_in() && ! is_admin() && ! is_404() ) {
			get_template_part('tpl-comingsoon');
			exit();
		}		
	}
}

if( kriya_option('pageoptions','enable-comingsoon') ):
	add_action('template_redirect', 'kriya_under_construction', 30);

	// getting shortcode css ----------------------
	add_action('wp_head', 'kriya_rand_css');
	function kriya_rand_css() {
		$id = kriya_option('pageoptions','comingsoon-pageid');
		if ( $id ) {
			$shortcodes_custom_css = get_post_meta( $id, '_wpb_shortcodes_custom_css', true );
			if ( ! empty( $shortcodes_custom_css ) ) {
				wp_add_inline_style( 'kriya-gutenberg', $shortcodes_custom_css );
			}
		}
	}
endif;

/**
 * Register widget area
 */
function kriya_widgets_init() {

	// standard sidebar
	register_sidebar(array(
		'name' 			=>	esc_html__('Standard Sidebar', 'kriya'),
		'id'			=>	'standard-sidebar',
		'description'	=>	esc_html__("Appears in the widget area side of the site, one enabled.",'kriya'),
		'before_widget' => 	'<aside id="%1$s" class="widget %2$s">',
		'after_widget' 	=> 	'</aside>',
		'before_title' 	=> 	'<h3 class="widgettitle">',
		'after_title' 	=> 	'</h3>'));

	// custom widget area
	$widget_area = kriya_option('widgetarea','custom');
	$widget_area = is_array($widget_area) ? array_unique($widget_area) : array();
    $widget_area = array_filter($widget_area);
    foreach ($widget_area as $key => $value) {
    	$id = mb_convert_case($value, MB_CASE_LOWER, "UTF-8");
    	$id = str_replace(" ", "-", $id);

    	register_sidebar(array(
			'name' 			=>	$value,
			'id'			=>	$id,
			'description'   =>  esc_html__("Custom sidebar created in Theme Options.",'kriya'),
			'before_widget' => 	'<aside id="%1$s" class="widget %2$s">',
			'after_widget' 	=> 	'</aside>',
			'before_title' 	=> 	'<h3 class="widgettitle">',
			'after_title' 	=> 	'</h3>'));
    }

    // post archives sidebar
	$layout = kriya_option('pageoptions','post-archives-page-layout');
	$layout = !empty($layout) ? $layout : "content-full-width";
	switch($layout) :
		case 'with-left-sidebar':
		case 'with-right-sidebar':
			register_sidebar(array(
				'name' 			=>	esc_html__("Post Archives Sidebar",'kriya'),
				'id'			=>	'post-archives-sidebar',
				'description'   =>  esc_html__("Appears in widget area side of Post Archives Page.",'kriya'),
				'before_widget' => 	'<aside id="%1$s" class="widget %2$s">',
				'after_widget' 	=> 	'</aside>',
				'before_title' 	=> 	'<h3 class="widgettitle">',
				'after_title' 	=> 	'</h3>'));
		break;
	endswitch;

	// events everywhere sidebar
	if( class_exists('Tribe__Events__Main')	):
		// Event sidebar
		register_sidebar(array(
			'name' 			=>	esc_html__('Events Sidebar', 'kriya'),
			'id'			=>	'events-everywhere-sidebar',
			'description'   =>  esc_html__("Main sidebar for The Events Calendar pages.",'kriya'),
			'before_widget' => 	'<aside id="%1$s" class="widget %2$s">',
			'after_widget' 	=> 	'</aside>',
			'before_title' 	=> 	'<h3 class="widgettitle">',
			'after_title' 	=> 	'</h3>'));		
	endif;

	// portfolio archives sidebar
	if( class_exists( 'DTCorePlugin' ) ):

		// Courses Archive
		$layout = kriya_option('pageoptions','course-archives-page-layout');
		$layout = !empty($layout) ? $layout : "content-full-width";
		switch($layout) :
			case 'with-left-sidebar':
			case 'with-right-sidebar':
				register_sidebar(array(
					'name' 			=>	esc_html__("Courses Archive Sidebar",'kriya'),
					'id'			=>	'dt_yoga_courses-archive-sidebar',
					'description'   =>  esc_html__("Appears in the widget area side of Courses Archive Page.",'kriya'),
					'before_widget' => 	'<aside id="%1$s" class="widget %2$s">',
					'after_widget' 	=> 	'</aside>',
					'before_title' 	=> 	'<h3 class="widgettitle">',
					'after_title' 	=> 	'</h3>'));
			break;
		endswitch;

		$layout = kriya_option('pageoptions','portfolio-archives-page-layout');
		$layout = !empty($layout) ? $layout : "content-full-width";
		switch($layout) :
			case 'with-left-sidebar':
			case 'with-right-sidebar':
				register_sidebar(array(
					'name' 			=>	esc_html__("Portfolio Archives Sidebar",'kriya'),
					'id'			=>	'custom-post-portfolio-archives-sidebar',
					'description'   =>  esc_html__("Appears in the widget area side of Portfolio Archives Page.",'kriya'),
					'before_widget' => 	'<aside id="%1$s" class="widget %2$s">',
					'after_widget' 	=> 	'</aside>',
					'before_title' 	=> 	'<h3 class="widgettitle">',
					'after_title' 	=> 	'</h3>'));
			break;
		endswitch;
	endif;

	// shop everywhere sidebar
	if( class_exists('woocommerce')	):

		// Shop sidebar
		register_sidebar(array(
			'name' 			=>	esc_html__('Shop Sidebar', 'kriya'),
			'id'			=>	'shop-everywhere-sidebar',
			'description'   =>  esc_html__("Main sidebar for The Shop pages.",'kriya'),
			'before_widget' => 	'<aside id="%1$s" class="widget %2$s">',
			'after_widget' 	=> 	'</aside>',
			'before_title' 	=> 	'<h3 class="widgettitle">',
			'after_title' 	=> 	'</h3>'));
			
		// custom sidebar for product layout
		$layout = kriya_option('woo','product-layout');
		$layout = !empty($layout) ? $layout : "content-full-width";
		switch($layout) :
			case 'with-left-sidebar':
			case 'with-right-sidebar':

				register_sidebar(array(
					'name' 			=>	esc_html__('Product detail Sidebar', 'kriya'),
					'id'			=>	"product-detail-sidebar",
					'description'	=>  esc_html__("Appears on Product detail Page.",'kriya'),
					'before_widget' => 	'<aside id="%1$s" class="widget %2$s">',
					'after_widget' 	=> 	'</aside>',
					'before_title' 	=> 	'<h3 class="widgettitle">',
					'after_title' 	=> 	'</h3>'));
			break;
		endswitch;

		// custom sidebars for product category
		$layout = kriya_option('woo','product-category-layout');
		$layout = !empty($layout) ? $layout : "content-full-width";
		switch($layout) :
			case 'with-left-sidebar':
			case 'with-right-sidebar':

				register_sidebar(array(
					'name' 			=>	esc_html__('Product Category Sidebar', 'kriya'),
					'id'			=>	"product-category-sidebar",
					'description'	=>  esc_html__("Appears on Product Category Page.",'kriya'),
					'before_widget' => 	'<aside id="%1$s" class="widget %2$s">',
					'after_widget' 	=> 	'</aside>',
					'before_title' 	=> 	'<h3 class="widgettitle">',
					'after_title' 	=> 	'</h3>'));
			break;
		endswitch;

		// custom sidebars for product tag
		$layout = kriya_option('woo','product-tag-layout');
		$layout = !empty($layout) ? $layout : "content-full-width";
		switch($layout) :
			case 'with-left-sidebar':
			case 'with-right-sidebar':

				register_sidebar(array(
					'name' 			=>	esc_html__('Product Tag Sidebar', 'kriya'),
					'id'			=>	"product-tag-sidebar",
					'description'	=>  esc_html__("Appears on Product Tag Page.",'kriya'),
					'before_widget' => 	'<aside id="%1$s" class="widget %2$s">',
					'after_widget' 	=> 	'</aside>',
					'before_title' 	=> 	'<h3 class="widgettitle">',
					'after_title' 	=> 	'</h3>'));
			break;
		endswitch;
	endif;

	$footer_columns = kriya_option('layout','footer-columns');
	kriya_footer_widgetarea($footer_columns);
}
add_action("widgets_init", "kriya_widgets_init");

/**
 * Add new mimes to use custom font upload
 */
if( !function_exists('kriya_upload_mimes') ) :

	function kriya_upload_mimes( $mimes = array() ) {

		$mimes['woff']	= 'font/woff';
		$mimes['ttf'] 	= 'font/ttf';
		$mimes['svg'] 	= 'font/svg';
		$mimes['eot'] 	= 'font/eot';

		return $mimes;
	}
endif;
add_filter('upload_mimes', 'kriya_upload_mimes');

/* 
 * Excerpt
 */
if( !function_exists( 'kriya_excerpt' )):
function kriya_excerpt($limit = NULL) {
	$limit = !empty($limit) ? $limit : 10;

	$excerpt = explode(' ', get_the_excerpt(), $limit);
	$excerpt = array_filter($excerpt);

	if (!empty($excerpt)) {
		if (count($excerpt) >= $limit) {
			array_pop($excerpt);
			$excerpt = implode(" ", $excerpt).'...';
		} else {
			$excerpt = implode(" ", $excerpt);
		}
		$excerpt = preg_replace('`\[[^\]]*\]`', '', $excerpt);
		return "<p>{$excerpt}</p>";
	}
}
endif;

/* ---------------------------------------------------------------------------
 * Pagination for Blog and Portfolio
 * --------------------------------------------------------------------------- */
if( !function_exists( 'kriya_pagination' )):
function kriya_pagination( $query = false, $load_more = false ){
	$wp_query = kriya_global_variables('wp_query');
	$paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : ( ( get_query_var( 'page' ) ) ? get_query_var( 'page' ) : 1 );

	// default $wp_query
	if( $query ) $wp_query = $query;

	$wp_query->query_vars['paged'] > 1 ? $current = $wp_query->query_vars['paged'] : $current = 1;  
	
	if( empty( $paged ) ) $paged = 1;
	$prev = $paged - 1;
	$next = $paged + 1;

	$end_size = 1;
	$mid_size = 2;
	$show_all = kriya_option('general','showall-pagination');
	$dots = false;

	if( ! $total = $wp_query->max_num_pages ) $total = 1;
	
	$output = '';
	if( $total > 1 )
	{
		if( $load_more ){
			// ajax load more -------------------------------------------------
			if( $paged < $total ){
				$output .= '<div class="dt-pager-wrapper pager_lm">';
					$output .= '<a class="pager_load_more button button_js" href="'. get_pagenum_link( $next ) .'">';
						$output .= '<span class="button_icon"><i class="icon-layout"></i></span>';
						$output .= '<span class="button_label">'. esc_html__('Load more', 'kriya') .'</span>';
					$output .= '</a>';
				$output .= '</div>';
			}

		} else {
			// default --------------------------------------------------------	
			$output .= '<div class="dt-pager-wrapper">';

				$big = 999999999; // need an unlikely integer
				$args = array(
					'base'               => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
					'total'              => $wp_query->max_num_pages,
					'current'            => max( 1, get_query_var('paged') ),
					'show_all'           => $show_all,
					'end_size'           => $end_size,
					'mid_size'           => $mid_size,
					'prev_next'          => true,
					'prev_text'          => '<i class="fa fa-angle-double-left"></i>'.esc_html__('Prev', 'kriya'),
					'next_text'          => esc_html__('Next', 'kriya').'<i class="fa fa-angle-double-right"></i>',
					'type'               => 'list'
				);
				$output .= paginate_links( $args );

			$output .= '</div>'."\n";
		}
	}
	return $output;
}
endif;
/*
 * WordPress wp_kses function for allowed html
 */
function kriya_wp_kses($content) {
	$dt_allowed_html_tags = array(
		'a' => array('class' => array(), 'data-product_id' => array(), 'href' => array(), 'title' => array(), 'target' => array(), 'id' => array(), 'data-post-id' => array(), 'data-gal' => array(), 'data-image' => array(), 'rel' => array()),
		'abbr' => array('title' => array()),
		'address' => array(),
		'area' => array('shape' => array(), 'coords' => array(), 'href' => array(), 'alt' => array()),
		'article' => array('id' => array(), 'class' => array()),
		'aside' => array('id' => array(), 'class' => array()),
		'audio' => array('autoplay' => array(), 'controls' => array(), 'loop' => array(), 'muted' => array(), 'preload' => array(), 'src' => array()),
		'b' => array(),
		'base' => array('href' => array(), 'target' => array()),
		'bdi' => array(),
		'bdo' => array('dir' => array()), 
		'blockquote' => array('cite' => array()), 
		'br' => array(),
		'button' => array('autofocus' => array(), 'disabled' => array(), 'form' => array(), 'formaction' => array(), 'formenctype' => array(), 'formmethod' => array(), 'formnovalidate' => array(), 'formtarget' => array(), 'name' => array(), 'type' => array(), 'value' => array()),
		'canvas' => array('height' => array(), 'width' => array()),
		'caption' => array('align' => array()),
		'cite' => array(),
		'code' => array(),
		'col' => array(),
		'colgroup' => array(),
		'datalist' => array('id' => array()),
		'dd' => array(),
		'del' => array('cite' => array(), 'datetime' => array()),
		'details' => array('open' => array()),
		'dfn' => array(),
		'dialog' => array('open' => array()),
		'div' => array('class' => array(), 'id' => array(), 'style' => array(), 'align' => array(), 'data-for' => array()),
		'dl' => array(),
		'dt' => array(),
		'em' => array(),
		'embed' => array('height' => array(), 'src' => array(), 'type' => array(), 'width' => array()),
		'fieldset' => array('disabled' => array(), 'form' => array(), 'name' => array()),
		'figcaption' => array(),
		'figure' => array(),
		'form' => array('accept' => array(), 'accept-charset' => array(), 'action' => array(), 'autocomplete' => array(), 'enctype' => array(), 'method' => array(), 'name' => array(), 'novalidate' => array(), 'target' => array(), 'id' => array(), 'class' => array()),
		'h1' => array('class' => array()), 'h2' => array('class' => array()), 'h3' => array('class' => array()), 'h4' => array('class' => array()), 'h5' => array('class' => array()), 'h6' => array('class' => array()),
		'hr' => array(), 
		'i' => array('class' => array(), 'id' => array()), 
		'iframe' => array('name' => array(), 'seamless' => array(), 'src' => array(), 'srcdoc' => array(), 'width' => array(), 'height' => array(), 'frameborder' => array(), 'allowfullscreen' => array(), 'mozallowfullscreen' => array(), 'webkitallowfullscreen' => array(), 'title' => array()),
		'img' => array('alt' => array(), 'crossorigin' => array(), 'height' => array(), 'ismap' => array(), 'src' => array(), 'usemap' => array(), 'width' => array(), 'title' => array(), 'data-default' => array()),
		'input' => array('align' => array(), 'alt' => array(), 'autocomplete' => array(), 'autofocus' => array(), 'checked' => array(), 'disabled' => array(), 'form' => array(), 'formaction' => array(), 'formenctype' => array(), 'formmethod' => array(), 'formnovalidate' => array(), 'formtarget' => array(), 'height' => array(), 'list' => array(), 'max' => array(), 'maxlength' => array(), 'min' => array(), 'multiple' => array(), 'name' => array(), 'pattern' => array(), 'placeholder' => array(), 'readonly' => array(), 'required' => array(), 'size' => array(), 'src' => array(), 'step' => array(), 'type' => array(), 'value' => array(), 'width' => array(), 'id' => array(), 'class' => array()),
		'ins' => array('cite' => array(), 'datetime' => array()),
		'label' => array('for' => array(), 'form' => array(), 'class' => array()),
		'legend' => array('align' => array()), 
		'li' => array('type' => array(), 'value' => array(), 'class' => array(), 'id' => array()),
		'link' => array('crossorigin' => array(), 'href' => array(), 'hreflang' => array(), 'media' => array(), 'rel' => array(), 'sizes' => array(), 'type' => array()),
		'main' => array(), 
		'map' => array('name' => array()), 
		'mark' => array(), 
		'menu' => array('label' => array(), 'type' => array()),
		'menuitem' => array('checked' => array(), 'command' => array(), 'default' => array(), 'disabled' => array(), 'icon' => array(), 'label' => array(), 'radiogroup' => array(), 'type' => array()),
		'meta' => array('charset' => array(), 'content' => array(), 'http-equiv' => array(), 'name' => array()),
		'object' => array('form' => array(), 'height' => array(), 'name' => array(), 'type' => array(), 'usemap' => array(), 'width' => array()),
		'ol' => array('class' => array(), 'reversed' => array(), 'start' => array(), 'type' => array()),
		'option' => array('value' => array(), 'selected' => array()),
		'p' => array('class' => array()), 
		'q' => array('cite' => array()), 
		'section' => array(), 
		'select' => array('autofocus' => array(), 'disabled' => array(), 'form' => array(), 'multiple' => array(), 'name' => array(), 'required' => array(), 'size' => array(), 'class' => array()),
		'small' => array(), 
		'source' => array('media' => array(), 'src' => array(), 'type' => array()),
		'span' => array('class' => array()), 
		'strong' => array(),
		'style' => array('media' => array(), 'scoped' => array(), 'type' => array()),
		'sub' => array(),
		'sup' => array(),
		'table' => array('sortable' => array()), 
		'tbody' => array(), 
		'td' => array('colspan' => array(), 'headers' => array()),
		'textarea' => array('autofocus' => array(), 'cols' => array(), 'disabled' => array(), 'form' => array(), 'maxlength' => array(), 'name' => array(), 'placeholder' => array(), 'readonly' => array(), 'required' => array(), 'rows' => array(), 'wrap' => array()),
		'tfoot' => array(),
		'th' => array('abbr' => array(), 'colspan' => array(), 'headers' => array(), 'rowspan' => array(), 'scope' => array(), 'sorted' => array()),
		'thead' => array(), 
		'time' => array('datetime' => array()), 
		'title' => array(), 
		'tr' => array(), 
		'track' => array('default' => array(), 'kind' => array(), 'label' => array(), 'src' => array(), 'srclang' => array()), 
		'u' => array(), 
		'ul' => array('class' => array(), 'id' => array()), 
		'var' => array(), 
		'video' => array('autoplay' => array(), 'controls' => array(), 'height' => array(), 'loop' => array(), 'muted' => array(), 'muted' => array(), 'poster' => array(), 'preload' => array(), 'src' => array(), 'width' => array()),
		'wbr' => array(),
	);

	$data = wp_kses($content, $dt_allowed_html_tags);
	return $data;
}

# Move comment filed in comment form to bottom
add_filter( 'comment_form_fields', 'kriya_move_comment_field_to_bottom' );
function kriya_move_comment_field_to_bottom( $fields ) {

	$comment_field = $fields['comment'];
	$comment_privacy_field = '';
	if(isset($fields['comment-form-dt-privatepolicy'])) {
		$comment_privacy_field = $fields['comment-form-dt-privatepolicy'];
	}
	$comment_cookies = $fields['cookies'];

	unset( $fields['comment'] );
	if(isset($fields['comment-form-dt-privatepolicy'])) {
		unset( $fields['comment-form-dt-privatepolicy'] );
	}
	unset( $fields['cookies'] );

	$fields['comment'] = $comment_field;
	if($comment_privacy_field != '') {
		$fields['comment-form-dt-privatepolicy'] = $comment_privacy_field;
	}
	$fields['cookies'] = $comment_cookies;

	return $fields;
}

/* ---------------------------------------------------------------------------
 * Filter to modify default category widget view
 * --------------------------------------------------------------------------- */
if( !function_exists('kriya_wp_list_categories') ){
	function kriya_wp_list_categories( $output ){
		if (strpos($output, "</span>") <= 0) {
			$output = str_replace('</a> (', ' <span>(', $output);
			$output = str_replace(')', ')</span></a> ', $output);
		}
		
		return $output;
	}
	
	add_filter('wp_list_categories', 'kriya_wp_list_categories');
}

/* ---------------------------------------------------------------------------
 * Filter to modify default list archive widget view
 * --------------------------------------------------------------------------- */
if( !function_exists('kriya_wp_list_archive') ){
	function kriya_wp_list_archive($link_html,$url, $text, $format, $before, $after ) {
		
		if( $format == 'html' ) {
			$link_html = "\t<li>$before<a href='$url'>$text <span>$after</span></a></li>\n";
		}
		
		return $link_html;

	}
	add_filter('get_archives_link', 'kriya_wp_list_archive', 10,6);	
}

/* ---------------------------------------------------------------------------
 * Filter to execute shortcode inside contact form7
 * --------------------------------------------------------------------------- */
if( !function_exists('kriya_wpcf7_form_elements') ){
	function kriya_wpcf7_form_elements($form) {
		$form = do_shortcode( $form );
		return $form;
	}
	add_filter('wpcf7_form_elements', 'kriya_wpcf7_form_elements');
}