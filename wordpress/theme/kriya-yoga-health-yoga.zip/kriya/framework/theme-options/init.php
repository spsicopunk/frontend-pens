<?php
/**
 * Add Kriya theme options menu
 */
if ( ! function_exists( 'kriya_theme_option' ) ) :

	function kriya_theme_option() {

		add_theme_page(
			esc_html__('Kriya Theme Options', 'kriya'),
			esc_html__('Kriya Options', 'kriya'),
			'manage_options',
			'kriya-opts',
			'kriya_options_page'
		);
	}
endif;
add_action('admin_menu', 'kriya_theme_option' );

/**
 * Create Kriya theme options page
 */
function kriya_options_page() {?>
	<!-- wrapper -->
	<div id="wrapper">

		<!-- Result -->
		<div id="bpanel-message" style="display:none;"></div>
		<div id="ajax-feedback" style="display:none;">
			<img src="<?php echo  get_template_directory_uri().'/framework/theme-options/images/loading.png'; ?>" alt="<?php esc_attr_e('loader', 'kriya');?>" />
		</div>
    	<!-- Result -->

    	<!-- panel-wrap -->
    	<div id="panel-wrap">

    		<!-- bpanel-wrapper -->
    		<div id="bpanel-wrapper">

    			<!-- bpanel -->
    			<div id="bpanel">

    				<!-- bpanel-left -->
    				<div id="bpanel-left">

    					<div id="logo"><?php
    						$logo = get_template_directory_uri().'/framework/theme-options/images/logo.png';
    						$k_general = kriya_option('general');
    						$logo = ( isset($k_general['bpanel-logo-url']) && isset( $k_general['enable-bpanel-logo-url']) ) ? $k_general['bpanel-logo-url'] : $logo;?>

    						<img src="<?php echo esc_url($logo);?>" width="186" height="101" alt="<?php esc_attr_e('dtlogo', 'kriya');?>" />
    					</div><?php

						/* ---------------------------------------------------------------------------
						 * Load all theme option tabs.
						 * --------------------------------------------------------------------------- */
						$tabs = array(
							'general' 	  => array('icon' => 'dashicons-admin-home', 'name'=>esc_html__('General','kriya'), 'display'=>true),
							'layout'  	  => array('icon' => 'dashicons-exerpt-view', 'name'=>esc_html__('Layout','kriya'), 'display'=>true),
							'widgetarea'  => array('icon' => 'dashicons-welcome-widgets-menus', 'name'=>esc_html__('Widget Area','kriya'), 'display'=>true),
							'pageoptions' => array('icon' => 'dashicons-admin-page', 'name'=>esc_html__('Page Options','kriya'), 'display'=>true),
							'woocommerce' => array('icon' => 'dashicons-cart', 'name'=>esc_html__('WooCommerce','kriya'), 'display'=>false),
							'colors'	  => array('icon' => 'dashicons-admin-appearance', 'name'=>esc_html__('Colors','kriya'), 'display'=>true),
							'fonts'		  => array('icon' => 'dashicons-editor-spellcheck', 'name'=>esc_html__('Fonts','kriya'), 'display'=>true),
							'import'	  => array('icon' => 'dashicons-upload', 'name'=>esc_html__('Importer','kriya'), 'display'=>false),
							'privacy'	  => array('icon' => 'dashicons-chart-pie', 'name'=>esc_html__('Privacy & Cookies','kriya'), 'display'=>true),
							'backup'	  => array('icon' => 'dashicons-backup', 'name'=>esc_html__('Backup','kriya'), 'display'=>true),
							'paypal' 	  => array('icon' => 'dashicons-chart-line', 'name'=>esc_html__('Paypal','kriya'), 'display'=>false),
							'changelog'   => array('icon' => 'dashicons-info', 'name'=> esc_html__('Kriya Version', 'kriya'), 'display'=>true)
						);

						if(class_exists('woocommerce')) $tabs['woocommerce']['display'] = true;
						if(class_exists('DTCorePlugin')) $tabs['paypal']['display'] = true;
						if(class_exists('DTKriyaImporter')) $tabs['import']['display'] = true;?>

						<!-- bpanel-mainmenu -->
						<ul id='bpanel-mainmenu'>
							<?php foreach($tabs as $tabkey => $tab ):
									if($tab['display'])
										echo "<li><a href='#{$tabkey}' title='{$tab['name']}'><span class='dashicons {$tab['icon']}'></span>{$tab['name']}</a></li>";
								  endforeach; ?>
						</ul><!-- bpanel-mainmenu -->

    				</div><!-- bpanel-left -->

    				<form id="dttheme_options_form" name="dttheme_options_form" enctype="multipart/form-data" method="post" action="options.php">
    					<?php settings_fields( 'dttheme' );?>
    					<input type="hidden" id="dttheme-full-submit" name="dttheme-full-submit" value="0" />
    					<input type="hidden" name="dttheme_admin_wpnonce" value="<?php echo wp_create_nonce('dttheme_wpnonce');?>" /><?php
							/* ---------------------------------------------------------------------------
						 	* Load theme options php files
						 	* --------------------------------------------------------------------------- */
							foreach($tabs as $tabkey => $tab ):
								if($tab['display']) {

									if($tabkey == 'import') {
										require_once WP_PLUGIN_DIR.'/kriya-demo-importer/theme-options/importer.php';
									} else {
										require_once( get_template_directory() .'/framework/theme-options/' .$tabkey. '.php' );
									}
								}
							endforeach; ?>

						<!-- #bpanel-bottom -->
                        <div id="bpanel-bottom">
                           <input type="submit" value="<?php esc_attr_e('Reset All','kriya');?>" class="save-reset dttheme-reset-button bpanel-button white-btn" name="dttheme[reset]" />
						   <input type="submit" value="<?php esc_attr_e('Save All','kriya');?>" name="submit"  class="save-reset dttheme-footer-submit bpanel-button white-btn" />
                        </div><!-- #bpanel-bottom end-->
    				</form>
    			</div><!-- bpanel -->

    		</div><!-- bpanel-wrapper -->

    	</div><!-- panel-wrap -->
	</div><!-- wrapper --><?php
}

/**
 * Load css & scripts for Kriya theme options page
 */
if ( ! function_exists( 'kriya_admin_scripts' ) ) :
	function kriya_admin_scripts() {
		wp_enqueue_style('kriya-admin', get_template_directory_uri() .'/framework/theme-options/style.css');
		wp_enqueue_style('kriya-chosen', get_template_directory_uri() .'/framework/theme-options/css/chosen.css');
		wp_enqueue_style('wp-color-picker');

		wp_enqueue_script('jquery-ui-tabs');
		wp_enqueue_script('jquery-ui-sortable');
		wp_enqueue_script('jquery-ui-slider');
		wp_enqueue_script('wp-color-picker');
		
		wp_enqueue_script('kriya-tooltip', get_template_directory_uri() . '/framework/theme-options/js/jquery.tools.min.js');
		wp_enqueue_script('kriya-chosen', get_template_directory_uri() . '/framework/theme-options/js/chosen.jquery.min.js');
		wp_enqueue_script('kriya-custom', get_template_directory_uri() . '/framework/theme-options/js/dttheme.admin.js' , array( 'wp-blocks' ));
		wp_enqueue_media();

		wp_localize_script('kriya-custom', 'objectL10n', array(
			'saveall' => esc_html__('Save All', 'kriya'),
			'saving' => esc_html__('Saving ...', 'kriya'),
			'noResult' => esc_html__('No Results Found!', 'kriya'),
			'resetConfirm' => esc_html__('This will restore all of your options to default. Are you sure?', 'kriya'),
			'importConfirm' => esc_html__('You are going to import the dummy data provided with the theme, kindly confirm?', 'kriya'),
			'backupMsg' => esc_html__('Click OK to backup your current saved options.', 'kriya'),
			'backupSuccess' => esc_html__('Your options are backuped successfully', 'kriya'),
			'backupFailure' => esc_html__('Backup Process not working', 'kriya'),
			'disableImportMsg' => esc_html__('Importing is disabled.. :), Please select atleast import type','kriya'),
			'restoreMsg' => esc_html__('Warning: All of your current options will be replaced with the data from your last backup! Proceed?', 'kriya'),
			'restoreSuccess' => esc_html__('Your options are restored from previous backup successfully', 'kriya'),
			'restoreFailure' => esc_html__('Restore Process not working', 'kriya'),
			'importMsg' => esc_html__('Click ok import options from the above textarea', 'kriya'),
			'importSuccess' => esc_html__('Your options are imported successfully', 'kriya'),
			'importFailure' => esc_html__('Import Process not working', 'kriya')));
		}
endif;
add_action( 'admin_enqueue_scripts', 'kriya_admin_scripts' );

/**
 * Initiates Kriya theme options
 */
add_action('admin_init', 'kriya_options_init', 1);
function kriya_options_init() {
	register_setting('kriya-opts', 'kriya-opts');
	add_option('kriya-opts', kriya_default_option());

	if (isset($_POST['dttheme-option-save'])) :
		kriya_ajax_option_save();
	endif;

	if (isset($_POST['dttheme']['reset'])) :
		delete_option('kriya-opts');
		update_option('kriya-opts', kriya_default_option()); # To set Default options
		wp_redirect(admin_url('admin.php?page=parent&reset=true'));
		exit;
	endif;
}

/**
 * Save Kriya theme options
 */
function kriya_ajax_option_save() {

	$ajax_ref_check = check_ajax_referer('dttheme_wpnonce', 'dttheme_admin_wpnonce');

	if($ajax_ref_check === false) {
		return false;
	} else {

		$data = $_POST;

		unset($data['_wp_http_referer'], $data['_wpnonce'], $data['action']);
		unset($data['dttheme_admin_wpnonce'], $data['dttheme-option-save'], $data['option_page']);

		$msg = array(
			'success' => false, 
			'message' => esc_html__('Error: Options not saved, please try again.', 'kriya')
		);

		$data = array_filter($data['dttheme']);

		if (get_option('kriya-opts') != $data) {
			if (update_option('kriya-opts', $data))
				$msg = array(
					'success' => 'options_saved',
					'message' => esc_html__('Options Saved.', 'kriya')
				);
		} else {
			$msg = array(
				'success' => true,
				'message' => esc_html__('Options Saved.', 'kriya')
			);
		}

		$echo = json_encode($msg);
		header('Content-Type: application/json; charset='.get_option('blog_charset'));
		echo "{$echo}";
		exit;
	}
}

/**
 * Backup & Restore Kriya options
 */
add_action('wp_ajax_kriya_backup_and_restore_action', 'kriya_backup_and_restore_action');
function kriya_backup_and_restore_action() {
	
	$save_type = $_REQUEST['type'];
	
	if ($save_type == 'backup_options') :
	
		$data = array(
			'general' => kriya_option('general'),
			'layout' => kriya_option('layout'),
			'social' => kriya_option('social'),
			'pageoptions' => kriya_option('pageoptions'),
			'woo' => kriya_option('woo'),
			'colors' => kriya_option('colors'),
			'fonts' => kriya_option('fonts'),
			'paypal' => kriya_option('paypal'),
			'backup' => date('r')
		);
		
		update_option("dt_theme_backup", $data);
		die('1');
	elseif ($save_type == 'restore_options') :
		$data = get_option("dt_theme_backup");
		update_option('kriya-opts', $data);
		die('1');
	elseif ($save_type == "import_options") :
		$data = $_REQUEST['data'];
		$data =  unserialize( stripcslashes($data) );
		update_option('kriya-opts', $data);
		die('1');
	elseif( $save_type == "reset_options") :
		delete_option('kriya-opts');
		update_option('kriya-opts', kriya_default_option()); #To set Default options
		die('1');
	endif;
}

/**
 * Create admin panel image preview
 */
function kriya_adminpanel_image_preview($src, $backend = true, $default = "no-image.jpg") {
	$default = ($backend) ? get_template_directory_uri() . "/framework/theme-options/images/" . $default : get_template_directory_uri() . "/images/" . $default;
	$src = ! empty ( $src ) ? $src : $default;
	$output = "<div class='bpanel-option-help'>\n";
	$output .= "<a href='' title='' class='a_image_preivew'> <img src='" . get_template_directory_uri() . "/framework/theme-options/images/image-preview.png' alt='img' /> </a>\n";
	$output .= "\r<div class='bpanel-option-help-tooltip imagepreview'>\n";
	$output .= "\r<img src='{$src}' data-default='{$default}'/>";
	$output .= "\r</div>\n";
	$output .= "</div>\n";
	echo "{$output}";
}

/* 
 * Types of Background option available
 */
function kriya_bgtypes($name, $parent, $child) {
	$args = array (
		"bg-patterns" => esc_html__ ( "Pattern", 'kriya' ),
		"bg-custom" => esc_html__ ( "Custom Background", 'kriya' ),
		"bg-none" => esc_html__ ( "None", 'kriya' ) 
	);
	$out = '<div class="bpanel-option-set">';
	$out .= "<label>" . esc_html__ ( "Background Type", 'kriya' ) . "</label>";
	$out .= "<div class='clear'></div>";
	$out .= "<select class='bg-type dt-chosen-select' name='{$name}'>";
	foreach ( $args as $k => $v ) :
		$rs = selected ( $k, kriya_option ( $parent, $child ), false );
		$out .= "<option value='{$k}' {$rs}>{$v}</option>";
	endforeach;
	$out .= "</select>";
	$out .= '</div>';
	echo "{$out}";
}

/* ---------------------------------------------------------------------------
 * Getting privacy button action selection box
 * --------------------------------------------------------------------------- */
if ( ! function_exists( 'kriya_privacy_btnaction_selection' ) ) {
	function kriya_privacy_btnaction_selection($name = '', $selected = "") {
		$actions = array( '' => esc_html__('Dismiss the notification', 'kriya'), 'link' => esc_html__('Link to another page', 'kriya'), 'info_modal' => esc_html__('Open info modal on privacy and cookies', 'kriya') );
	
		$name = ! empty ( $name ) ? "name='dttheme[privacy-bar][{$name}][action]'" : '';
		$out = "<select class='button-select' {$name}>"; // name attribute will be added to this by jQuery menuAdd()
		foreach ( $actions as $key => $value ) :
			$s = selected ( $key, $selected, false );
			$v = $value;
			$out .= "<option value='{$key}' {$s} >{$v}</option>";
		endforeach;
		$out .= "</select>";
	
		return $out;
	}
}

/* 
 * Getting color picker for color option
 */
function kriya_admin_color_picker($label, $name, $value, $tooltip = NULL) {
	$output = "<div class='bpanel-option-set'>\n";
	if (! empty ( $label )) :
		$output .= "<label>{$label}</label>";
		$output .= "<div class='hr_invisible'></div><div class='clear'></div>";
	endif;
	
	$output .= "<input type='text' class='dt-color-field medium' name='{$name}' value='{$value}' />";

	echo "{$output}";
	if ($tooltip != NULL)
		kriya_adminpanel_tooltip ( $tooltip );

	echo "</div>\n";
}

/* 
 * Getting color picker for color option
 */
function kriya_admin_color_picker_two($name, $value) {
	echo "<input type='text' class='dt-color-field small' name='{$name}' value='{$value}' />";
}

/* 
 * Getting jquery ui slider
 */ 
function kriya_admin_jqueryuislider($label, $id = '', $value = '', $px = "px") {
	$div_value = (! empty ( $value ) && ($px == "px")) ? $value . "px" : $value;
	$output = "<label>{$label}</label>";
	$output .= "<div class='clear'></div>";
	$output .= "<div id='{$id}' class='dttheme-slider' data-for='{$px}'></div>";
	$output .= "<input type='hidden' class='' name='{$id}' value='{$value}'/>";
	$output .= "<div class='dttheme-slider-txt'>{$div_value}</div>";
	echo "{$output}";
}

/*
 * Getting theme switch button
 */
function kriya_switch($label, $parent, $name) {
	$checked = ("true" == kriya_option ( $parent, $name )) ? ' checked="checked"' : '';
	$switchclass = ("true" == kriya_option ( $parent, $name )) ? 'checkbox-switch-on' : 'checkbox-switch-off';
	$out = "<div data-for='dttheme-{$parent}-{$name}' class='checkbox-switch {$switchclass}'></div>";
	$out .= "<input id='dttheme-{$parent}-{$name}' class='hidden' name='dttheme[{$parent}][{$name}]' type='checkbox' value='true' {$checked} />";
	echo "{$out}";
}

/* 
 * Getting theme sociable selection box
 */
function kriya_sociables_selection($name = '', $selected = "") {
	$sociables = kriya_listSocial();

	$name = ! empty ( $name ) ? "name='dttheme[social][{$name}][icon]'" : '';
	$out = "<select class='social-select' {$name}>"; // name attribute will be added to this by jQuery menuAdd()
	foreach ( $sociables as $key => $value ) :
		$s = selected ( $key, $selected, false );
		$v = ucwords ( $value );
		$out .= "<option value='{$key}' {$s} >{$v}</option>";
	endforeach;
	$out .= "</select>";

	return $out;
}

function kriya_paypal_languages() {

	return array_unique( array(
		"da_DK" => esc_html__('Danish','kriya'),
		"nl_BE" => esc_html__('Dutch','kriya'),
		"EN_US" => esc_html__('English','kriya'),
		"en_GB" => esc_html__('English - UK','kriya'),
		"fr_CA" => esc_html__('French','kriya'),
		"de_DE" => esc_html__('German','kriya'),
		"he_IL" => esc_html__('Hebrew','kriya'),
		"it_IT" => esc_html__('Italian','kriya'),
		"ja_JP" => esc_html__('Japanese','kriya'),
		"no_NO" => esc_html__('Norwgian','kriya'),
		"pl_PL" => esc_html__('Polish','kriya'),
		"pt_BR" => esc_html__('Portuguese','kriya'),
		"ru_RU" => esc_html__('Russian','kriya'),
		"es_ES" => esc_html__('Spanish','kriya'),
		"sv_SE" => esc_html__('Swedish','kriya'),
		"zh_CN" => esc_html__('Simplified Chinese -China only','kriya'),
		"zh_HK" => esc_html__('Traditional Chinese - Hong Kong only','kriya'),
		"zh_TW" => esc_html__('Traditional Chinese - Taiwan only','kriya'),
		"tr_TR" => esc_html__('Turkish','kriya'),
		"th_TH" => esc_html__('Thai','kriya')
	) );
}

function kriya_paypal_currencies() {

	return array_unique( array(
		'AUD' => esc_html__('Australian Dollar','kriya').' - '.'AUD',
		'BRL' => esc_html__('Brazilian Real ','kriya').' - '.'BRL',
		'CAD' => esc_html__('Canadian Dollar','kriya').' - '.'CAD',
		'CZK' => esc_html__('Czech Koruna','kriya').' - '.'CZK',
		'DKK' => esc_html__('Danish Krone','kriya').' - '.'DKK',
		'EUR' => esc_html__('Euro','kriya').' - '.'EUR',
		'HKD' => esc_html__('Hong Kong Dollar','kriya').' - '.'HKD',
		'HUF' => esc_html__('Hungarian Forint','kriya').' - '.'HUF',
		'ILS' => esc_html__('Israeli New Sheqel','kriya').' - '.'ILS',
		'JPY' => esc_html__('Japanese Yen','kriya').' - '.'JPY',
		'MYR' => esc_html__('Malaysian Ringgit','kriya').' - '.'MYR',
		'MXN' => esc_html__('Mexican Peso','kriya').' - '.'MXN',
		'NOK' => esc_html__('Norwegian Krone','kriya').' - '.'NOK',
		'NZD' => esc_html__('New Zealand Dollar','kriya').' - '.'NZD',
		'PHP' => esc_html__('Philippine Peso','kriya').' - '.'PHP',
		'PLN' => esc_html__('Polish Zloty','kriya').' - '.'PLN',
		'GBP' => esc_html__('Pound Sterling','kriya').' - '.'GBP',
		'RUB' => esc_html__('Russian Ruble','kriya').' - '.'RUB',
		'SGD' => esc_html__('Singapore Dollar','kriya').' - '.'SGD',
		'SEK' => esc_html__('Swedish Krona','kriya').' - '.'SEK',
		'CHF' => esc_html__('Swiss Franc','kriya').' - '.'CHF',
		'TWD' => esc_html__('Taiwan New Dollar','kriya').' - '.'TWD',
		'THB' => esc_html__('Thai Baht','kriya').' - '.'THB',
		'TRY' => esc_html__('Turkish Lira','kriya').' - '.'TRY',
		'USD' => esc_html__('U.S. Dollar','kriya').' - '.'USD',
		'INR' => esc_html__('INR Indian Rupee','kriya').' - '.'INR'
	) );
}

function kriya_currency_symbol( $currency = '' ) {

	switch( $currency ) {
		case 'AUD': 
		case 'CAD': 
		case 'HKD':
		case 'MXN':
		case 'NZD':
		case 'SGD':
		case 'USD':
		default:   
			$symbol = '&#36;';
		break;
		case 'BRL': 
			$symbol = '&#82;&#36;';
		break;
		case 'CZK': 
			$symbol = '&#75;&#269;';
		break;
		case 'DKK': 
			$symbol = '&#107;&#114;';
		break;
		case 'EUR': 
			$symbol = '&euro;';
		break;
		case 'HUF': 
			$symbol = '&#70;&#116;';
		break;
		case 'ILS': 
			$symbol = '&#8362;';
		break;
		case 'JPY': 
			$symbol = '&yen;';
		break;
		case 'MYR': 
			$symbol = '&#82;&#77;';
		break;
		case 'NOK': 
			$symbol = '&#107;&#114;';
		break;
		case 'PHP': 
			$symbol = '&#8369;';
		break;
		case 'PLN': 
			$symbol = '&#122;&#322;';
		break;
		case 'GBP': 
			$symbol = '&pound;';
		break;
		case 'RUB': 
			$symbol = '&#1088;&#1091;&#1073;.';
		break;

		case 'SEK': 
			$symbol = '&#107;&#114;';
		break;
		case 'CHF': 
			$symbol = '&#67;&#72;&#70;';
		break;
		case 'TWD': 
			$symbol = '&#78;&#84;&#36;';
		break;
		case 'THB': 
			$symbol = '&#3647;';
		break;
		case 'TRY': 
			$symbol = '&#84;&#76;';
		break;
		case 'INR': 
			$symbol = '&#8377';
		break;
		
	}
		return $symbol;	
}