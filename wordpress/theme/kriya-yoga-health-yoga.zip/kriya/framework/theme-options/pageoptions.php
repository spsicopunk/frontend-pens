<!-- #pageoptions -->
<div id="pageoptions" class="bpanel-content">

    <!-- .bpanel-main-content -->
    <div class="bpanel-main-content">

        <ul class="sub-panel">
        	<li><a href="#tab0"><?php esc_html_e('Global', 'kriya');?></a></li>
            <li><a href="#tab1"><?php esc_html_e('Post', 'kriya');?></a></li>
            <li><a href="#tab2"><?php esc_html_e('Portfolio', 'kriya');?></a></li>
            <li><a href="#tab3"><?php esc_html_e('404', 'kriya');?></a></li>
            <li><a href="#tab4"><?php esc_html_e('Under Construction', 'kriya');?></a></li>
            <?php if(class_exists('DTCorePlugin')): ?>
            <li><a href="#tab5"><?php esc_html_e('Yoga Module', 'kriya');?></a></li>
            <?php endif;?>
        </ul>

        <!-- tab0-global -->
        <div id="tab0" class="tab-content">
            <!-- .bpanel-box -->
            <div class="bpanel-box">

              <div class="box-title">
                <h3><?php esc_html_e('Page Layout', 'kriya');?></h3>
              </div>
              <div class="box-content">

                <!-- Page -->
                <h6><?php esc_html_e('Force to Enable Global Page Layout', 'kriya');?></h6><?php
                $checked = ( "true" ==  kriya_option('pageoptions','force-enable-global-page-layout') ) ? ' checked="checked"' : '';
                $switchclass = ( "true" ==  kriya_option('pageoptions','force-enable-global-page-layout') ) ? 'checkbox-switch-on' :'checkbox-switch-off'; ?>
                <div data-for="dttheme-force-enable-global-page-layout" class="checkbox-switch <?php echo esc_attr($switchclass);?>"></div>
                <input class="hidden" id="dttheme-force-enable-global-page-layout" name="dttheme[pageoptions][force-enable-global-page-layout]"
                  type="checkbox" value="true" <?php echo "{$checked}";?> />
                <div class="clear"> </div>
                <div class="hr"> </div>

                <h6><?php esc_html_e('Choose Layout', 'kriya');?></h6>
                <p class="note no-margin"> <?php esc_html_e("Choose the page layout", 'kriya');?></p>
                <div class="bpanel-option-set">
                  <ul class="bpanel-post-layout bpanel-layout-set"><?php
                    $layout = array('content-full-width'=>'without-sidebar','with-left-sidebar'=>'left-sidebar','with-right-sidebar'=>'right-sidebar');
                    $v =  kriya_option('pageoptions',"global-page-layout");
                    $v = !empty($v) ? $v : "";
                    foreach($layout as $key => $value):
                      $class = ( $key ==   $v ) ? " class='selected' " : "";
                      echo "<li><a href='#' rel='{$key}' {$class}><img src='" . get_template_directory_uri() . "/framework/theme-options/images/columns/{$value}.png' /></a></li>";
                    endforeach; ?>
                  </ul>
                  <input name="dttheme[pageoptions][global-page-layout]" type="hidden" value="<?php echo esc_attr($v);?>"/>
                </div>
                <!-- Page -->

                <!-- Post -->
                <h6><?php esc_html_e('Force to Enable Global Post Layout', 'kriya');?></h6><?php
                $checked = ( "true" ==  kriya_option('pageoptions','force-enable-global-post-layout') ) ? ' checked="checked"' : '';
                $switchclass = ( "true" ==  kriya_option('pageoptions','force-enable-global-post-layout') ) ? 'checkbox-switch-on' :'checkbox-switch-off'; ?>
                <div data-for="dttheme-force-enable-global-post-layout" class="checkbox-switch <?php echo esc_attr($switchclass);?>"></div>
                <input class="hidden" id="dttheme-force-enable-global-post-layout" name="dttheme[pageoptions][force-enable-global-post-layout]"
                  type="checkbox" value="true" <?php echo "{$checked}";?> />
                <div class="clear"> </div>
                <div class="hr"> </div>

                <h6><?php esc_html_e('Choose Layout', 'kriya');?></h6>
                <p class="note no-margin"> <?php esc_html_e("Choose the post layout", 'kriya');?></p>
                <div class="bpanel-option-set">
                  <ul class="bpanel-post-layout bpanel-layout-set"><?php
                    $layout = array('content-full-width'=>'without-sidebar','with-left-sidebar'=>'left-sidebar','with-right-sidebar'=>'right-sidebar');
                    $v =  kriya_option('pageoptions',"global-post-layout");
                    $v = !empty($v) ? $v : "";
                    foreach($layout as $key => $value):
                      $class = ( $key ==   $v ) ? " class='selected' " : "";
                      echo "<li><a href='#' rel='{$key}' {$class}><img src='" . get_template_directory_uri() . "/framework/theme-options/images/columns/{$value}.png' /></a></li>";
                    endforeach; ?>
                  </ul>
                  <input name="dttheme[pageoptions][global-post-layout]" type="hidden" value="<?php echo esc_attr($v);?>"/>
                </div>                
                <!-- Post -->

                <div class="box-title">
                   <h3><?php esc_html_e('Tracking Code', 'kriya');?></h3>
               </div>

               <div class="box-content">
                    <h6><?php esc_html_e('Enable Tracking Code', 'kriya');?></h6>
                    <div class="column one-fifth">
                         <?php $checked = ( "true" ==  kriya_option('pageoptions','enable-tracking-code') ) ? ' checked="checked"' : ''; ?>
                         <?php $switchclass = ( "true" ==  kriya_option('pageoptions','enable-tracking-code') ) ? 'checkbox-switch-on' :'checkbox-switch-off'; ?>
                         <div data-for="dttheme-pageoptions-tracking-code" class="checkbox-switch <?php echo esc_attr($switchclass);?>"></div>
                         <input class="hidden" id="dttheme-pageoptions-tracking-code" name="dttheme[pageoptions][enable-tracking-code]" type="checkbox" value="true" <?php echo "{$checked}";?> />
                    </div>
                    <div class="column four-fifth last">
                       <p class="note"><?php esc_html_e('YES! to enable tracking code.', 'kriya');?></p>
                    </div>
                    <div class="clear"></div>

                    <h6><?php esc_html_e('Google Analytics Tracking Code', 'kriya');?></h6>
                    <textarea id="dttheme[pageoptions][tracking-code]" name="dttheme[pageoptions][tracking-code]"><?php echo stripslashes(kriya_option('pageoptions', 'tracking-code'));?></textarea>
                    <p class="note"><?php esc_html_e('Enter your Google tracking id (UA-XXXXX-X) here. If you want to offer your visitors the option to stop being tracked you can place the shortcode [dt_sc_privacy_google_tracking] somewhere on your site', 'kriya');?></p>
               </div><!-- .box-content -->
              </div>
            </div>
        </div><!-- tab0-global -->

        <!-- tab1-post -->
        <div id="tab1" class="tab-content">
            <!-- .bpanel-box -->
            <div class="bpanel-box">
                <div class="box-title">
                    <h3><?php esc_html_e('Post', 'kriya');?></h3>
                </div>
                
                <div class="box-content">
                
                	<div class="column one-half">
                        <h6><?php esc_html_e('Single Author Box', 'kriya');?></h6>
                        <div class="column one-fifth">
                              <?php $checked = ( "true" ==  kriya_option('pageoptions','single-post-authorbox') ) ? ' checked="checked"' : ''; ?>
                              <?php $switchclass = ( "true" ==  kriya_option('pageoptions','single-post-authorbox') ) ? 'checkbox-switch-on' :'checkbox-switch-off'; ?>
                              <div data-for="dttheme-single-post-authorbox" class="checkbox-switch <?php echo esc_attr($switchclass);?>"></div>
                              <input class="hidden" id="dttheme-single-post-authorbox" name="dttheme[pageoptions][single-post-authorbox]" 
                              	type="checkbox" value="true" <?php echo "{$checked}";?> />
                        </div>
                        <div class="column four-fifth last">
                              <p class="note"><?php esc_html_e('YES! to display author box in single blog posts.', 'kriya');?></p>
                        </div>
                    </div>
                    <div class="column one-half last">
                        <h6><?php esc_html_e('Single Related Posts', 'kriya');?></h6>
                        <div class="column one-fifth">
                              <?php $checked = ( "true" ==  kriya_option('pageoptions','single-post-related') ) ? ' checked="checked"' : ''; ?>
                              <?php $switchclass = ( "true" ==  kriya_option('pageoptions','single-post-related') ) ? 'checkbox-switch-on' :'checkbox-switch-off'; ?>
                              <div data-for="dttheme-single-post-related" class="checkbox-switch <?php echo esc_attr($switchclass);?>"></div>
                              <input class="hidden" id="dttheme-single-post-related" name="dttheme[pageoptions][single-post-related]" type="checkbox" 
                              	value="true" <?php echo "{$checked}";?> />
                        </div>
                        <div class="column four-fifth last">
                              <p class="note"><?php esc_html_e('YES! to display related blog posts in single posts.', 'kriya');?></p>
                        </div>
                    </div>
                    
                    <div class="hr"></div>
                    
                	<div class="column one-half">
                        <h6><?php esc_html_e('Posts Comments', 'kriya');?></h6>
                        <div class="column one-fifth">
                              <?php $checked = ( "true" ==  kriya_option('pageoptions','single-post-comments') ) ? ' checked="checked"' : ''; ?>
                              <?php $switchclass = ( "true" ==  kriya_option('pageoptions','single-post-comments') ) ? 'checkbox-switch-on' :'checkbox-switch-off'; ?>
                              <div data-for="dttheme-single-post-comments" class="checkbox-switch <?php echo esc_attr($switchclass);?>"></div>
                              <input class="hidden" id="dttheme-single-post-comments" name="dttheme[pageoptions][single-post-comments]" type="checkbox" 
                              	value="true" <?php echo "{$checked}";?> />
                        </div>
                        <div class="column four-fifth last">
                              <p class="note"><?php esc_html_e('YES! to display single blog post comments.', 'kriya');?></p>
                        </div>
                    </div>
                    <div class="column one-half last">
                    </div>
                </div><!-- .box-content -->

                <div class="box-title">
                    <h3><?php esc_html_e('Post Archives Page Layout', 'kriya');?></h3>
                </div>

                <div class="box-content">
                    <h6><?php esc_html_e('Layout', 'kriya');?></h6>
                    <p class="note no-margin"> <?php esc_html_e("Choose the Post archives page layout Style", 'kriya');?></p>
                    <div class="hr_invisible"> </div>
                    <div class="bpanel-option-set">
                        <ul class="bpanel-post-layout bpanel-layout-set" id="post-archives-layout">
                        <?php $layout = array('content-full-width'=>'without-sidebar','with-left-sidebar'=>'left-sidebar','with-right-sidebar'=>'right-sidebar');
                              $v =  kriya_option('pageoptions',"post-archives-page-layout");
                              $v = !empty($v) ? $v : "content-full-width";
                              foreach($layout as $key => $value):
                                  $class = ( $key ==   $v ) ? " class='selected' " : "";
                                  echo "<li><a href='#' rel='{$key}' {$class}><img src='" . get_template_directory_uri() . "/framework/theme-options/images/columns/{$value}.png' /></a></li>";
                              endforeach; ?>
                        </ul>
                        <input name="dttheme[pageoptions][post-archives-page-layout]" type="hidden" value="<?php echo esc_attr($v);?>"/>
                    </div><?php 
                    $sb_layout = kriya_option('pageoptions',"post-archives-page-layout");
                    $sidebar_both = $sidebar_left = $sidebar_right = '';
                    if($sb_layout == 'content-full-width') {
                      $sidebar_both = 'style="display:none;"'; 
                    } elseif($sb_layout == 'with-left-sidebar') {
                      $sidebar_right = 'style="display:none;"'; 
                    } elseif($sb_layout == 'with-right-sidebar') {
                      $sidebar_left = 'style="display:none;"'; 
                    } ?>
                    <div id="bpanel-widget-area-options" <?php echo 'class="post-archives-layout" '.$sidebar_both;?>>
                      <div id="left-sidebar-container" class="bpanel-page-left-sidebar" <?php echo "{$sidebar_left}"; ?>>
                          <!-- 2. Standard Sidebar Left Start -->
                          <div id="page-commom-sidebar" class="bpanel-sidebar-section custom-box">
                              <h6><?php esc_html_e('Show Standard Left Sidebar', 'kriya');?></label></h6>
                              <?php kriya_switch("",'pageoptions','show-standard-left-sidebar-for-post-archives'); ?>
                          </div><!-- Standard Sidebar Left End-->
                      </div>

                      <div id="right-sidebar-container" class="bpanel-page-right-sidebar" <?php echo "{$sidebar_right}"; ?>>
                          <!-- 3. Standard Sidebar Right Start -->
                          <div id="page-commom-sidebar" class="bpanel-sidebar-section custom-box">
                              <h6><?php esc_html_e('Show Standard Right Sidebar', 'kriya');?></label></h6>
                              <?php kriya_switch("",'pageoptions','show-standard-right-sidebar-for-post-archives'); ?>
                          </div><!-- Standard Sidebar Right End-->
                      </div>
                    </div>
                </div>
                
                <div class="box-title">
                    <h3><?php esc_html_e('Post Archives Post Layout', 'kriya');?></h3>
                </div>

                <div class="box-content">
                
                    <h6><?php esc_html_e('Layout', 'kriya');?></h6>
                    <p class="note no-margin"><?php esc_html_e("Choose the Post Layout Style in Post Archives", 'kriya');?></p>
                    <div class="hr_invisible"> </div>
                    <div class="bpanel-option-set">
                        <ul class="bpanel-post-layout bpanel-layout-set">
                        <?php $posts_layout = array('one-column'=>esc_html__("One post per row.", 'kriya'), 'one-half-column'=>esc_html__("Two posts per row.", 'kriya'),
													'one-third-column' => esc_html__("Three posts per row.", 'kriya') );
                              $v = kriya_option('pageoptions',"post-archives-post-layout");
                              $v = !empty($v) ? $v : "one-half-column";
                              foreach($posts_layout as $key => $value):
                                 $class = ( $key ==  $v ) ? " class='selected' " :"";                                  
                                 echo "<li><a href='#' rel='{$key}' {$class} title='{$value}'><img src='" . get_template_directory_uri() . "/framework/theme-options/images/columns/{$key}.png' /></a></li>";
                              endforeach;?>                        
                        </ul>
                        <input name="dttheme[pageoptions][post-archives-post-layout]" type="hidden" value="<?php echo esc_attr($v);?>"/>
                    </div>
                    <div class="hr"></div>

                	<div class="column one-half">
                    	<h6><?php esc_html_e('Allow Excerpt', 'kriya');?></h6>
                        <div class="column one-fifth">
                        	<?php $checked = ( "true" ==  kriya_option('pageoptions','post-archives-enable-excerpt') ) ? ' checked="checked"' : ''; ?>
                            <?php $switchclass = ( "true" ==  kriya_option('pageoptions','post-archives-enable-excerpt') ) ? 'checkbox-switch-on' :'checkbox-switch-off'; ?>
                        	<div data-for="dttheme-post-archives-enable-excerpt" class="checkbox-switch <?php echo esc_attr($switchclass);?>"></div>
                            <input class="hidden" id="dttheme-post-archives-enable-excerpt" name="dttheme[pageoptions][post-archives-enable-excerpt]"
                            	type="checkbox" value="true" <?php echo "{$checked}";?> />                        
                        </div>
                        <div class="column four-fifth last">
                              <p class="note"><?php esc_html_e('YES! to allow excerpt', 'kriya');?></p>
                        </div>
                    </div>

                	<div class="column one-half last">
                    	<h6><?php esc_html_e('Excerpt Length', 'kriya');?></h6>
                        <div class="column one-fifth">
                        	<input type="text" name="dttheme[pageoptions][post-archives-excerpt]" class="large" 
                            	value="<?php echo stripslashes(kriya_option('pageoptions', 'post-archives-excerpt'));?>"/>
                        </div>
                        <div class="column four-fifth last">
                              <p class="note"><?php esc_html_e('Enter Excerpt Length', 'kriya');?></p>
                        </div>
                    </div>
                    <div class="hr"></div>

                    <div class="column one-half">
                        <h6><?php esc_html_e('Read More', 'kriya');?></h6>
                        <div class="column one-fifth">
                            <?php $checked = ( "true" ==  kriya_option('pageoptions','post-archives-enable-readmore') ) ? ' checked="checked"' : ''; ?>
                            <?php $switchclass = ( "true" ==  kriya_option('pageoptions','post-archives-enable-readmore') ) ? 'checkbox-switch-on' :'checkbox-switch-off'; ?>
                            <div data-for="dttheme-post-archives-enable-readmore" class="checkbox-switch <?php echo esc_attr($switchclass);?>"></div>
                            <input class="hidden" id="dttheme-post-archives-enable-readmore" name="dttheme[pageoptions][post-archives-enable-readmore]"
                                type="checkbox" value="true" <?php echo "{$checked}";?> />                        
                        </div>
                        <div class="column four-fifth last">
                              <p class="note"><?php esc_html_e('YES! to enable read more button', 'kriya');?></p>
                        </div>
                    </div>
                    <div class="column one-half last">
                        <h6><?php esc_html_e('Border Style', 'kriya');?></h6>
                        <div class="column one-fifth">
                            <?php $checked = ( "true" ==  kriya_option('pageoptions','post-archives-enable-border-style') ) ? ' checked="checked"' : ''; ?>
                            <?php $switchclass = ( "true" ==  kriya_option('pageoptions','post-archives-enable-border-style') ) ? 'checkbox-switch-on' :'checkbox-switch-off'; ?>
                            <div data-for="dttheme-post-archives-enable-border-style" class="checkbox-switch <?php echo esc_attr($switchclass);?>"></div>
                            <input class="hidden" id="dttheme-post-archives-enable-border-style" name="dttheme[pageoptions][post-archives-enable-border-style]"
                                type="checkbox" value="true" <?php echo "{$checked}";?> />                        
                        </div>
                        <div class="column four-fifth last">
                              <p class="note"><?php esc_html_e('YES! to enable border style', 'kriya');?></p>
                        </div>                    
                    </div>
                </div>

                <div class="box-title">
                    <h3><?php esc_html_e('Single Post & Post Archive options','kriya');?></h3>
                </div>
                <div class="box-content">
                	<div class="column one-half">
                    	<h6><?php esc_html_e('Post Format Meta', 'kriya');?></h6>
                        <div class="column one-fifth">
                        	<?php $checked = ( "true" ==  kriya_option('pageoptions','post-format-meta') ) ? ' checked="checked"' : ''; ?>
                            <?php $switchclass = ( "true" ==  kriya_option('pageoptions','post-format-meta') ) ? 'checkbox-switch-on' :'checkbox-switch-off'; ?>
                        	<div data-for="dttheme-post-format-meta" class="checkbox-switch <?php echo esc_attr($switchclass);?>"></div>
                            <input class="hidden" id="dttheme-post-format-meta" name="dttheme[pageoptions][post-format-meta]"
                            	type="checkbox" value="true" <?php echo "{$checked}";?> />                        
                        </div>
                        <div class="column four-fifth last">
                              <p class="note"><?php esc_html_e('YES! to show post format meta information', 'kriya');?></p>
                        </div>
                    </div>
                    <div class="column one-half last">
                    	<h6><?php esc_html_e('Author Meta', 'kriya');?></h6>
                        <div class="column one-fifth">
                        	<?php $checked = ( "true" ==  kriya_option('pageoptions','post-author-meta') ) ? ' checked="checked"' : ''; ?>
                            <?php $switchclass = ( "true" ==  kriya_option('pageoptions','post-author-meta') ) ? 'checkbox-switch-on' :'checkbox-switch-off'; ?>
                        	<div data-for="dttheme-post-author-meta" class="checkbox-switch <?php echo esc_attr($switchclass);?>"></div>
                            <input class="hidden" id="dttheme-post-author-meta" name="dttheme[pageoptions][post-author-meta]"
                            	type="checkbox" value="true" <?php echo "{$checked}";?> />                        
                        </div>
                        <div class="column four-fifth last">
                              <p class="note"><?php esc_html_e('YES! to show post author meta information', 'kriya');?></p>
                        </div>
                    </div>
                    <div class="hr"></div>

                	<div class="column one-half">
                    	<h6><?php esc_html_e('Date Meta', 'kriya');?></h6>
                        <div class="column one-fifth">
                        	<?php $checked = ( "true" ==  kriya_option('pageoptions','post-date-meta') ) ? ' checked="checked"' : ''; ?>
                            <?php $switchclass = ( "true" ==  kriya_option('pageoptions','post-date-meta') ) ? 'checkbox-switch-on' :'checkbox-switch-off'; ?>
                        	<div data-for="dttheme-post-date-meta" class="checkbox-switch <?php echo esc_attr($switchclass);?>"></div>
                            <input class="hidden" id="dttheme-post-date-meta" name="dttheme[pageoptions][post-date-meta]"
                            	type="checkbox" value="true" <?php echo "{$checked}";?> />                        
                        </div>
                        <div class="column four-fifth last">
                              <p class="note"><?php esc_html_e('YES! to show post date meta information', 'kriya');?></p>
                        </div>
                    </div>
                    <div class="column one-half last">
                    	<h6><?php esc_html_e('Comment Meta', 'kriya');?></h6>
                        <div class="column one-fifth">
                        	<?php $checked = ( "true" ==  kriya_option('pageoptions','post-comment-meta') ) ? ' checked="checked"' : ''; ?>
                            <?php $switchclass = ( "true" ==  kriya_option('pageoptions','post-comment-meta') ) ? 'checkbox-switch-on' :'checkbox-switch-off'; ?>
                        	<div data-for="dttheme-post-comment-meta" class="checkbox-switch <?php echo esc_attr($switchclass);?>"></div>
                            <input class="hidden" id="dttheme-post-comment-meta" name="dttheme[pageoptions][post-comment-meta]"
                            	type="checkbox" value="true" <?php echo "{$checked}";?> />                        
                        </div>
                        <div class="column four-fifth last">
                              <p class="note"><?php esc_html_e('YES! to show post comment meta information', 'kriya');?></p>
                        </div>
                    </div>
                    <div class="hr"></div>

                	<div class="column one-half">
                    	<h6><?php esc_html_e('Category Meta', 'kriya');?></h6>
                        <div class="column one-fifth">
                        	<?php $checked = ( "true" ==  kriya_option('pageoptions','post-category-meta') ) ? ' checked="checked"' : ''; ?>
                            <?php $switchclass = ( "true" ==  kriya_option('pageoptions','post-category-meta') ) ? 'checkbox-switch-on' :'checkbox-switch-off'; ?>
                        	<div data-for="dttheme-post-category-meta" class="checkbox-switch <?php echo esc_attr($switchclass);?>"></div>
                            <input class="hidden" id="dttheme-post-category-meta" name="dttheme[pageoptions][post-category-meta]"
                            	type="checkbox" value="true" <?php echo "{$checked}";?> />                        
                        </div>
                        <div class="column four-fifth last">
                              <p class="note"><?php esc_html_e('YES! to show post category information', 'kriya');?></p>
                        </div>
                    </div>
                    <div class="column one-half last">
                    	<h6><?php esc_html_e('Tag Meta', 'kriya');?></h6>
                        <div class="column one-fifth">
                        	<?php $checked = ( "true" ==  kriya_option('pageoptions','post-tag-meta') ) ? ' checked="checked"' : ''; ?>
                            <?php $switchclass = ( "true" ==  kriya_option('pageoptions','post-tag-meta') ) ? 'checkbox-switch-on' :'checkbox-switch-off'; ?>
                        	<div data-for="dttheme-post-tag-meta" class="checkbox-switch <?php echo esc_attr($switchclass);?>"></div>
                            <input class="hidden" id="dttheme-post-tag-meta" name="dttheme[pageoptions][post-tag-meta]"
                            	type="checkbox" value="true" <?php echo "{$checked}";?> />                        
                        </div>
                        <div class="column four-fifth last">
                              <p class="note"><?php esc_html_e('YES! to show post tag information', 'kriya');?></p>
                        </div>
                    </div>
                </div>
            </div><!-- .bpanel-box end -->
        </div><!--tab1-post end-->

        <!-- tab2-portfolio -->
        <div id="tab2" class="tab-content">
            <!-- .bpanel-box -->
            <div class="bpanel-box">
                <div class="box-title">
                    <h3><?php esc_html_e('Portfolio', 'kriya');?></h3>
                </div>
                
                <div class="box-content">
                
                	<div class="column one-half">
                    	<h6><?php esc_html_e('Single Related Portfolios', 'kriya');?></h6>
                        <div class="column one-fifth">
                        	<?php $checked = ( "true" ==  kriya_option('pageoptions','single-portfolio-related') ) ? ' checked="checked"' : ''; ?>
                            <?php $switchclass = ( "true" ==  kriya_option('pageoptions','single-portfolio-related') ) ? 'checkbox-switch-on' :'checkbox-switch-off'; ?>
                            <div data-for="dttheme-single-portfolio-related" class="checkbox-switch <?php echo esc_attr($switchclass);?>"></div>
                            <input class="hidden" id="dttheme-single-portfolio-related" name="dttheme[pageoptions][single-portfolio-related]" type="checkbox" 
                            	value="true" <?php echo "{$checked}";?> />
                        </div>
                        <div class="column four-fifth last">
                        	<p class="note"><?php esc_html_e('YES! to show related portfolio items in single portfolio.', 'kriya');?></p>
                        </div>
                    </div>
                    
                    <div class="column one-half last">
                    </div>
                    <div class="clear"></div>             
                </div><!-- .box-content -->
                
                <div class="box-title">
                    <h3><?php esc_html_e('Portfolio Archives Page Layout', 'kriya');?></h3>
                </div>

                <div class="box-content">
                    <h6><?php esc_html_e('Layout', 'kriya');?></h6>
                    <p class="note no-margin"> <?php esc_html_e("Choose the Portfolio archives page layout Style", 'kriya');?></p>
                    <div class="hr_invisible"> </div>
                    <div class="bpanel-option-set">
                        <ul class="bpanel-post-layout bpanel-layout-set" id="portfolio-archives-layout">
                        <?php $layout = array('content-full-width'=>'without-sidebar','with-left-sidebar'=>'left-sidebar','with-right-sidebar'=>'right-sidebar');
                              $v =  kriya_option('pageoptions',"portfolio-archives-page-layout");
                              $v = !empty($v) ? $v : "content-full-width";
                              foreach($layout as $key => $value):
                                  $class = ( $key ==   $v ) ? " class='selected' " : "";
                                  echo "<li><a href='#' rel='{$key}' {$class}><img src='" . get_template_directory_uri() . "/framework/theme-options/images/columns/{$value}.png' /></a></li>";
                              endforeach; ?>
                        </ul>
                        <input name="dttheme[pageoptions][portfolio-archives-page-layout]" type="hidden" value="<?php echo esc_attr($v);?>"/>
                    </div><?php 
                    $sb_layout = kriya_option('pageoptions',"portfolio-archives-page-layout");
                    $sidebar_both = $sidebar_left = $sidebar_right = '';
                    if($sb_layout == 'content-full-width') {
                      $sidebar_both = 'style="display:none;"'; 
                    } elseif($sb_layout == 'with-left-sidebar') {
                      $sidebar_right = 'style="display:none;"'; 
                    } elseif($sb_layout == 'with-right-sidebar') {
                      $sidebar_left = 'style="display:none;"'; 
                    } ?>
                    <div id="bpanel-widget-area-options" <?php echo 'class="portfolio-archives-layout" '.$sidebar_both;?>>
                      <div id="left-sidebar-container" class="bpanel-page-left-sidebar" <?php echo "{$sidebar_left}"; ?>>
                          <!-- 2. Standard Sidebar Left Start -->
                          <div id="page-commom-sidebar" class="bpanel-sidebar-section custom-box">
                              <h6><?php esc_html_e('Show Standard Left Sidebar', 'kriya');?></label></h6>
                              <?php kriya_switch("",'pageoptions','show-standard-left-sidebar-for-portfolio-archives'); ?>
                          </div><!-- Standard Sidebar Left End-->
                      </div>

                      <div id="right-sidebar-container" class="bpanel-page-right-sidebar" <?php echo "{$sidebar_right}"; ?>>
                          <!-- 3. Standard Sidebar Right Start -->
                          <div id="page-commom-sidebar" class="bpanel-sidebar-section custom-box">
                              <h6><?php esc_html_e('Show Standard Right Sidebar', 'kriya');?></label></h6>
                              <?php kriya_switch("",'pageoptions','show-standard-right-sidebar-for-portfolio-archives'); ?>
                          </div><!-- Standard Sidebar Right End-->
                      </div>
                    </div>
                </div>

                <div class="box-title">
                    <h3><?php esc_html_e('Portfolio Archives Post Layout', 'kriya');?></h3>
                </div>

                <div class="box-content">

                    <h6><?php esc_html_e('Layout', 'kriya');?></h6>
                    <p class="note no-margin"><?php esc_html_e("Choose the Post Layout Style in Portfolio Archives", 'kriya');?></p>
                    <div class="hr_invisible"> </div>
                    <div class="bpanel-option-set">
                        <ul class="bpanel-post-layout bpanel-layout-set">
                        <?php $posts_layout = array( 'one-half-column'=>esc_html__("Two posts per row.", 'kriya'),
                                'one-third-column' => esc_html__("Three posts per row.", 'kriya'),
                                'one-fourth-column' => esc_html__("Four posts per row.", 'kriya'));
								
                              $v = kriya_option('pageoptions',"portfolio-archives-post-layout");
                              $v = !empty($v) ? $v : "one-half-column";
                              foreach($posts_layout as $key => $value):
                                 $class = ( $key ==  $v ) ? " class='selected' " :"";                                  
                                 echo "<li><a href='#' rel='{$key}' {$class} title='{$value}'><img src='" . get_template_directory_uri() . "/framework/theme-options/images/columns/{$key}.png' /></a></li>";
                              endforeach;?>                        
                        </ul>
                        <input name="dttheme[pageoptions][portfolio-archives-post-layout]" type="hidden" value="<?php echo esc_attr($v);?>"/>
                    </div>
                    <div class="hr"></div>

                	<div class="column one-half">
                    	<h6><?php esc_html_e('Allow Grid Space', 'kriya');?></h6>
                        <div class="column one-fifth">
                        	<?php $checked = ( "true" ==  kriya_option('pageoptions','portfolio-allow-grid-space') ) ? ' checked="checked"' : ''; ?>
                            <?php $switchclass = ( "true" ==  kriya_option('pageoptions','portfolio-allow-grid-space') ) ? 'checkbox-switch-on' :'checkbox-switch-off'; ?>
                        	<div data-for="dttheme-portfolio-allow-grid-space" class="checkbox-switch <?php echo esc_attr($switchclass);?>"></div>
                            <input class="hidden" id="dttheme-portfolio-allow-grid-space" name="dttheme[pageoptions][portfolio-allow-grid-space]"
                            	type="checkbox" value="true" <?php echo "{$checked}";?> />                        
                        </div>
                        <div class="column four-fifth last">
                              <p class="note"><?php esc_html_e('YES! to allow grid space', 'kriya');?></p>
                        </div>
                    </div>
                    <div class="column one-half last">
                        <h6><?php esc_html_e('Grid Space Size', 'kriya');?></h6>
                        <div class="column one-fifth">
                            <select name="dttheme[pageoptions][portfolio-grid-space-size]" class="dt-chosen-select"><?php
                                $selected = kriya_option('pageoptions','portfolio-grid-space-size');
                                foreach( array('5' => esc_html__('Thin','kriya'), '10' => esc_html__('Thick','kriya'), '20' => esc_html__('Medium','kriya')  ) as $k => $v): ?>
                                    <option value="<?php echo esc_attr($k);?>" <?php selected($k,$selected);?>><?php echo esc_attr($v);?></option><?php
                                endforeach;?>
                            </select>
                        </div>
                        <div class="column four-fifth last">
                            <p class="note"><?php esc_html_e('Select grid space size', 'kriya');?></p>
                        </div>                        
                    </div>
                    <div class="hr"></div>

                	<div class="column one-half">
                    	<h6><?php esc_html_e('Allow Masonry', 'kriya');?></h6>
                        <div class="column one-fifth">
                        	<?php $checked = ( "true" ==  kriya_option('pageoptions','portfolio-allow-masonry') ) ? ' checked="checked"' : ''; ?>
                            <?php $switchclass = ( "true" ==  kriya_option('pageoptions','portfolio-allow-masonry') ) ? 'checkbox-switch-on' :'checkbox-switch-off'; ?>
                        	<div data-for="dttheme-portfolio-allow-masonry" class="checkbox-switch <?php echo esc_attr($switchclass);?>"></div>
                            <input class="hidden" id="dttheme-portfolio-allow-masonry" name="dttheme[pageoptions][portfolio-allow-masonry]"
                            	type="checkbox" value="true" <?php echo "{$checked}";?> />                        
                        </div>
                        <div class="column four-fifth last">
                              <p class="note"><?php esc_html_e('YES! to allow masonry layout', 'kriya');?></p>
                        </div>
                    </div>
                </div>

                <div class="box-title">
                    <h3><?php esc_html_e('Permalinks', 'kriya');?></h3>
                </div>

                <div class="box-content">
                    <div class="column one-third"><label><?php esc_html_e('Single Portfolio slug', 'kriya');?></label></div>
                    <div class="column two-third last">
                        <input name="dttheme[pageoptions][single-portfolio-slug]" type="text" class="medium" value="<?php echo trim(stripslashes(kriya_option('pageoptions','single-portfolio-slug')));?>" />
                        <p class="note"><?php esc_html_e('Do not use characters not allowed in links. Use, eg. portfolio-item <br> <b>After change go to Settings > Permalinks and click Save changes.</b>', 'kriya');?></p>
                    </div>
                    <div class="hr"></div>

                    <div class="column one-third"><label><?php esc_html_e('Portfolio Category slug', 'kriya');?></label></div>
                    <div class="column two-third last">
                        <input name="dttheme[pageoptions][portfolio-category-slug]" type="text" class="medium" value="<?php echo trim(stripslashes(kriya_option('pageoptions','portfolio-category-slug')));?>" />
                        <p class="note"><?php esc_html_e('Do not use characters not allowed in links. Use, eg. portfolio-types <br> <b>After change go to Settings > Permalinks and click Save changes.</b>', 'kriya');?></p>
                    </div>
                    <div class="hr"></div>

                    <div class="column one-third"><label><?php esc_html_e('Portfolio Tag slug', 'kriya');?></label></div>
                    <div class="column two-third last">
                        <input name="dttheme[pageoptions][portfolio-tag-slug]" type="text" class="medium" value="<?php echo trim(stripslashes(kriya_option('pageoptions','portfolio-tag-slug')));?>" />
                        <p class="note"><?php esc_html_e('Do not use characters not allowed in links. Use, eg. portfolio-tags <br> <b>After change go to Settings > Permalinks and click Save changes.</b>', 'kriya');?></p>
                    </div>
				</div>
            </div><!-- .bpanel-box end -->
        </div><!--tab2-portfolio end-->

        <!-- tab3-404 -->
        <div id="tab3" class="tab-content">
            <!-- .bpanel-box -->
            <div class="bpanel-box">
                <div class="box-title">
                    <h3><?php esc_html_e('404 Message', 'kriya');?></h3>
                </div>

                <div class="box-content">
					<div class="column one-half">
                        <h6><?php esc_html_e('Enable Message', 'kriya');?></h6>
                        <div class="column one-fifth">
                              <?php $checked = ( "true" ==  kriya_option('pageoptions','enable-404message') ) ? ' checked="checked"' : ''; ?>
                              <?php $switchclass = ( "true" ==  kriya_option('pageoptions','enable-404message') ) ? 'checkbox-switch-on' :'checkbox-switch-off'; ?>
                              <div data-for="dttheme-enable-404message" class="checkbox-switch <?php echo esc_attr($switchclass);?>"></div>
                              <input class="hidden" id="dttheme-enable-404message" name="dttheme[pageoptions][enable-404message]" type="checkbox" value="true" <?php echo "{$checked}";?> />
                        </div>
                        <div class="column four-fifth last">
                              <p class="note"><?php esc_html_e('YES! to enable not-found page message.', 'kriya');?></p>
                        </div>
                    </div>
                    <div class="column one-half last">
						        </div>
                    <div class="hr"></div>

					<div class="column one-column">
                        <h6><?php esc_html_e('Custom Page', 'kriya');?></h6>
                        <select name="dttheme[pageoptions][notfound-pageid]" class="dt-chosen-select">
							<option value=""><?php esc_html_e('Choose the page', 'kriya'); ?></option><?php
                            $selected = kriya_option('pageoptions','notfound-pageid');
							$pages = get_pages ( 'title_li=&orderby=name' );
							foreach ( $pages as $page ) :
								$id = esc_attr ( $page->ID );
								$title = esc_html ( $page->post_title );
								echo "<option value='{$id}' " . selected ( $selected, $id, false ) . ">{$title}</option>";
							endforeach ?>
                        </select>
                        <p class="note"><?php esc_html_e('Choose the page for not-found content.', 'kriya');?></p>
					</div>
				</div>

				<div class="box-title">
                    <h3><?php esc_html_e('Background Options', 'kriya');?></h3>
                </div>
                <div class="box-content">
                    <h6><?php esc_html_e("Background Image", 'kriya');?></h6>
                    <div class="clear"></div>
                    <div class="image-preview-container">
                        <input id="dttheme-notfound-bg" name="dttheme[pageoptions][notfound-bg]" type="text" class="uploadfield large" readonly="readonly"
                                value="<?php echo kriya_option('pageoptions','notfound-bg');?>"/>
                        <input type="button" value="<?php esc_attr_e('Upload', 'kriya');?>" class="upload_image_button show_preview" />
                        <input type="button" value="<?php esc_attr_e('Remove', 'kriya');?>" class="upload_image_reset" />
                        <?php kriya_adminpanel_image_preview(kriya_option('pageoptions','notfound-bg'));?>
                    </div>
                    <p class="note"><?php esc_html_e("Upload an image for not-found page's background", 'kriya');?> </p>

                    <div class="hr_invisible"> </div>

                    <!-- Not Found BG Settings -->
                    <div class="column one-half">
                    <?php $bg_settings = array(
                                array(
                                    "label"=>	esc_html__('Background Image Repeat', 'kriya'),
                                    "tooltip"=>	esc_html__("Select how would you like to repeat the background image", 'kriya'),
                                    "name" => "dttheme[pageoptions][notfound-bg-repeat]",
                                    "db-key"=>"notfound-bg-repeat",
                                    "options"=>  array("repeat","repeat-x","repeat-y","no-repeat")
                                ),
                                array(
                                    "label"=>esc_html__('Background Image Position', 'kriya'),
                                    "tooltip"=>	esc_html__("Select how would you like to position the background", 'kriya'),
                                    "name" => "dttheme[pageoptions][notfound-bg-position]",
                                    "db-key"=>"notfound-bg-position",
                                    "options"=>  array("top left","top center","top right","center left","center center","center right","bottom left","bottom center","bottom right")
                                )
                          );    
                          foreach($bg_settings as $bgsettings): ?>
                              <div class="bpanel-option-set">
                                <label><?php echo esc_html( $bgsettings['label'] );?></label>
                                <div class="clear"></div>
                                <select name="<?php echo esc_attr($bgsettings['name']);?>" class="dt-chosen-select">
                                    <option value=""><?php esc_html_e("Select", 'kriya');?></option>
                                    <?php foreach($bgsettings['options'] as $option):?>
                                        <option value="<?php echo esc_attr($option);?>"
                                            <?php selected($option,kriya_option('pageoptions',$bgsettings['db-key'])); ?>><?php echo "{$option}";?></option>
                                    <?php endforeach;?>
                                </select>
                                <p class="note"><?php echo esc_html( $bgsettings['tooltip'] );?></p>
                                <div class="hr_invisible"> </div>
                              </div><?php
                          endforeach;?>
    
                          <div class="bpanel-option-set">
                             <h6><?php esc_html_e("Show Background Color", 'kriya');?></h6>
                             <?php kriya_switch("",'pageoptions','show-notfound-bg-color');?>
                             <p class="note"><?php esc_html_e("YES! to use background color.", 'kriya');?></p>
                          </div>
                    </div><!-- Not Found BG Settings End -->
                    
                     <!-- Not Found BG Color -->
                     <div class="column one-half last">
                        <?php $label = 		esc_html__("Background Color", 'kriya');
                              $name  =		"dttheme[pageoptions][notfound-bg-color]";
                              $value =  	(kriya_option('pageoptions','notfound-bg-color') != NULL) ? kriya_option('pageoptions','notfound-bg-color') :"";
                              $tooltip = 	esc_html__("Pick a background color of the page.(e.g. #a314a3)", 'kriya');
                              kriya_admin_color_picker($label,$name,$value,'');?>
                              <p class="note"><?php echo esc_html($tooltip);?></p>
                              <div class="hr_invisible"> </div>
                            
                         <?php echo kriya_admin_jqueryuislider( esc_html__("Background opacity", 'kriya'),	"dttheme[pageoptions][notfound-bg-opacity]",
                                                                  kriya_option("pageoptions","notfound-bg-opacity"),"");?>
						<p class="note"><?php esc_html_e("Set the background color opacity.", 'kriya');?> </p>

                        <div class="bpanel-option-set">
                          <label><?php esc_html_e('Background Style', 'kriya');?></label>
                          <div class="hr_invisible"> </div>
                          <div class="clear"></div>
                          <textarea id="dttheme[pageoptions][notfound-bg-style]" style="height:60px;" name="dttheme[pageoptions][notfound-bg-style]"><?php echo stripslashes(kriya_option('pageoptions', 'notfound-bg-style'));?></textarea>
                          <p class="note"><?php esc_html_e("Paste CSS code for background style.", 'kriya');?> </p>
                        </div>                                    
                     </div><!-- Not Found BG Color -->
                </div>
            </div><!-- .bpanel-box end -->
        </div><!--tab3-404 end-->

        <!-- tab4-comingsoon -->
        <div id="tab4" class="tab-content">
            <!-- .bpanel-box -->
            <div class="bpanel-box">
                <div class="box-title">
                    <h3><?php esc_html_e('Under Construction', 'kriya');?></h3>
                </div>
                <div class="box-content">
					<div class="column one-half">
                        <h6><?php esc_html_e('Enable Coming Soon', 'kriya');?></h6>
                        <div class="column one-fifth">
                              <?php $checked = ( "true" ==  kriya_option('pageoptions','enable-comingsoon') ) ? ' checked="checked"' : ''; ?>
                              <?php $switchclass = ( "true" ==  kriya_option('pageoptions','enable-comingsoon') ) ? 'checkbox-switch-on' :'checkbox-switch-off'; ?>
                              <div data-for="dttheme-enable-comingsoon" class="checkbox-switch <?php echo esc_attr($switchclass);?>"></div>
                              <input class="hidden" id="dttheme-enable-comingsoon" name="dttheme[pageoptions][enable-comingsoon]" type="checkbox" value="true" <?php echo "{$checked}";?> />
                        </div>
                        <div class="column four-fifth last">
                              <p class="note"><?php esc_html_e('YES! to check under construction page of your website.', 'kriya');?></p>
                        </div>
                    </div>
                    <div class="column one-half last">
                        <h6><?php esc_html_e('Custom Page', 'kriya');?></h6>
                        <select name="dttheme[pageoptions][comingsoon-pageid]" class="dt-chosen-select">
                            <option value=""><?php esc_html_e('Choose the page', 'kriya'); ?></option><?php
                            $selected = kriya_option('pageoptions','comingsoon-pageid');
                            $pages = get_pages ( 'title_li=&orderby=name' );
                            foreach ( $pages as $page ) :
                                $id = esc_attr ( $page->ID );
                                $title = esc_html ( $page->post_title );
                                echo "<option value='{$id}' " . selected ( $selected, $id, false ) . ">{$title}</option>";
                            endforeach ?>
                        </select>
                        <p class="note"><?php esc_html_e('Choose the page for comingsoon content.', 'kriya');?></p>
                    </div>
                    <div class="hr"></div>
                    <div class="column one-half">
                        <h6><?php esc_html_e('Launch Date', 'kriya');?></h6>
                        <input type="text" class="large" name="dttheme[pageoptions][comingsoon-launchdate]" placeholder="10/30/2016 12:00:00" value="<?php echo kriya_option('pageoptions','comingsoon-launchdate');?>" />
                        <p class="note"><?php esc_html_e('Put Format: 12/30/2016 12:00:00 month/day/year hour:minute:second', 'kriya');?></p>
                    </div>
                    <div class="column one-half last">
                        <h6><?php esc_html_e('UTC Timezone', 'kriya');?></h6>
                        <select name="dttheme[pageoptions][comingsoon-timezone]" class="medium"><?php
                            $selected = kriya_option('pageoptions','comingsoon-timezone');
                            $timezones =  array(''=>'0','-12'=>'-12','-11'=>'-11','-10'=>'-10','-9'=>'-9','-8'=>'-8',
                                '-7'=>'-7','-6'=>'-6','-5'=>'-5','-4'=>'-4','-3'=>'-3','-2'=>'-2','-1'=>'-1',
                                '+1'=>'+1','+2'=>'+2','+3'=>'+3','+4'=>'+4','+5'=>'+5','+6'=>'+6',
                                '+7'=>'+7','+8'=>'+8','+9'=>'+9','+10'=>'+10','+11'=>'+11','+12'=>'+12');
                            foreach( $timezones as $tv ):
                                echo "<option value='{$tv}'".selected($selected,$tv,false).">{$tv}</option>";
                            endforeach;?></select>
                        <p class="note"><?php esc_html_e('Choose utc timezone, by default UTC:00:00', 'kriya');?></p>
                    </div>
                </div>

				<div class="box-title">
                    <h3><?php esc_html_e('Body Background Options', 'kriya');?></h3>
                </div>
                <div class="box-content">
                    <h6><?php esc_html_e("Background Image", 'kriya');?></h6>
                    <div class="clear"></div>
                    <div class="image-preview-container">
                        <input id="dttheme-comingsoon-bg" name="dttheme[pageoptions][comingsoon-bg]" type="text" class="uploadfield large" readonly="readonly"
                                value="<?php echo kriya_option('pageoptions','comingsoon-bg');?>"/>
                        <input type="button" value="<?php esc_attr_e('Upload', 'kriya');?>" class="upload_image_button show_preview" />
                        <input type="button" value="<?php esc_attr_e('Remove', 'kriya');?>" class="upload_image_reset" />
                        <?php kriya_adminpanel_image_preview(kriya_option('pageoptions','comingsoon-bg'));?>
                    </div>
                    <p class="note"><?php esc_html_e("Upload an image for coming soon page's background", 'kriya');?> </p>

                    <div class="hr_invisible"> </div>

                    <!-- Coming Soon BG Settings -->
                    <div class="column one-half">
                    <?php $bg_settings = array(
                                array(
                                    "label"=>	esc_html__('Background Image Repeat', 'kriya'),
                                    "tooltip"=>	esc_html__("Select how would you like to repeat the background image", 'kriya'),
                                    "name" => "dttheme[pageoptions][comingsoon-bg-repeat]",
                                    "db-key"=>"comingsoon-bg-repeat",
                                    "options"=>  array("repeat","repeat-x","repeat-y","no-repeat")
                                ),
                                array(
                                    "label"=>esc_html__('Background Image Position', 'kriya'),
                                    "tooltip"=>	esc_html__("Select how would you like to position the background", 'kriya'),
                                    "name" => "dttheme[pageoptions][comingsoon-bg-position]",
                                    "db-key"=>"comingsoon-bg-position",
                                    "options"=>  array("top left","top center","top right","center left","center center","center right","bottom left","bottom center","bottom right")
                                )
                          );    
                          foreach($bg_settings as $bgsettings): ?>
                              <div class="bpanel-option-set">
                                <label><?php echo esc_html( $bgsettings['label'] );?></label>
                                <div class="clear"></div>
                                <select name="<?php echo esc_attr($bgsettings['name']);?>" class="dt-chosen-select">
                                    <option value=""><?php esc_html_e("Select", 'kriya');?></option>
                                    <?php foreach($bgsettings['options'] as $option):?>
                                        <option value="<?php echo esc_attr($option);?>"
                                            <?php selected($option,kriya_option('pageoptions',$bgsettings['db-key'])); ?>><?php echo "{$option}";?></option>
                                    <?php endforeach;?>
                                </select>
                                <p class="note"><?php echo esc_html( $bgsettings['tooltip'] );?></p>
                                <div class="hr_invisible"> </div>
                              </div><?php
                          endforeach;?>
    
                          <div class="bpanel-option-set">
                             <h6><?php esc_html_e("Show Background Color", 'kriya');?></h6>
                             <?php kriya_switch("",'pageoptions','show-comingsoon-bg-color');?>
                             <p class="note"><?php esc_html_e('YES! to use background color.','kriya');?></p>
                          </div>
                    </div><!-- Coming Soon BG Settings End -->

                     <!-- Coming Soon BG Color -->
                     <div class="column one-half last">
                        <?php $label = 		esc_html__("Background Color", 'kriya');
                              $name  =		"dttheme[pageoptions][comingsoon-bg-color]";
                              $value =  	(kriya_option('pageoptions','comingsoon-bg-color') != NULL) ? kriya_option('pageoptions','comingsoon-bg-color') :"";
                              $tooltip = 	esc_html__("Pick a background color of the page.(e.g. #a314a3)", 'kriya');
                              kriya_admin_color_picker($label,$name,$value,'');?>
                              <p class="note"><?php echo esc_html($tooltip);?></p>
                              <div class="hr_invisible"> </div>

                         <?php echo kriya_admin_jqueryuislider( esc_html__("Background opacity", 'kriya'), "dttheme[pageoptions][comingsoon-bg-opacity]",
                            kriya_option("pageoptions","comingsoon-bg-opacity"),"");?>
							           <p class="note"><?php esc_html_e("Set the background color opacity.", 'kriya');?> </p>
                         
                        <div class="bpanel-option-set">
                          <label><?php esc_html_e('Background Style', 'kriya');?></label>
                          <div class="hr_invisible"> </div>
                          <div class="clear"></div>
                          <textarea id="dttheme[pageoptions][comingsoon-bg-style]" style="height:60px;" name="dttheme[pageoptions][comingsoon-bg-style]"><?php echo stripslashes(kriya_option('pageoptions', 'comingsoon-bg-style'));?></textarea>
                          <p class="note"><?php esc_html_e("Paste CSS code for background style.", 'kriya');?> </p>
                        </div>
                     </div><!-- Coming Soon BG Color -->
                </div>
            </div>
        </div>

         <?php if(class_exists('DTCorePlugin')):?>
            <!-- tab5-yoga module -->
            <div id="tab5" class="tab-content">
               <div class="bpanel-box">

                  <div class="box-title">
                     <h3><?php esc_html_e('Courses Archives', 'kriya');?></h3>
                  </div>
                  <div class="box-content">
                     <!-- Post Layout -->
                        <h6><?php esc_html_e('Post Layout', 'kriya');?></h6>                           
                        <p class="note no-margin"> <?php esc_html_e("Choose the course archives post layout style", 'kriya');?></p>
                        <div class="hr_invisible"> </div>
                        <div class="bpanel-option-set">
                           <ul class="bpanel-post-layout bpanel-layout-set"><?php

                              $posts_layout = array( 'one-half-column'=>esc_html__("Two posts per row.", 'kriya'),
                                 'one-third-column' => esc_html__("Three posts per row.", 'kriya'),
                                 'one-fourth-column' => esc_html__("Four posts per row.", 'kriya'));

                              $v = kriya_option('pageoptions',"course-archives-post-layout");
                              $v = !empty($v) ? $v : "one-half-column";

                              foreach($posts_layout as $key => $value):

                                 $class = ( $key ==  $v ) ? " class='selected' " :"";                                  
                                 echo "<li><a href='#' rel='{$key}' {$class} title='{$value}'><img src='" . get_template_directory_uri() . "/framework/theme-options/images/columns/{$key}.png' /></a></li>";
                              endforeach;?>                        
                           </ul>
                           <input name="dttheme[pageoptions][course-archives-post-layout]" type="hidden" value="<?php echo esc_attr($v);?>"/>
                        </div>
                     <!-- Post Layout -->

                     <div class="hr"></div>
                     <div class="hr_invisible"></div>

                     <!-- Page Layout -->
                        <h6><?php esc_html_e('Page Layout', 'kriya');?></h6>
                        <p class="note no-margin"> <?php esc_html_e("Choose the course archives page layout style", 'kriya');?></p>
                        <div class="hr_invisible"> </div>

                        <div class="bpanel-option-set">
                           <ul class="bpanel-post-layout bpanel-layout-set" id="course-archives-layout"><?php
                              $layout = array('content-full-width'=>'without-sidebar','with-left-sidebar'=>'left-sidebar','with-right-sidebar'=>'right-sidebar');
                              $v =  kriya_option('pageoptions',"course-archives-page-layout");
                              $v = !empty($v) ? $v : "content-full-width";

                              foreach($layout as $key => $value):
                                 $class = ( $key ==   $v ) ? " class='selected' " : "";
                                 echo "<li><a href='#' rel='{$key}' {$class}><img src='" . get_template_directory_uri() . "/framework/theme-options/images/columns/{$value}.png' /></a></li>";
                              endforeach; ?>
                           </ul>
                           <input name="dttheme[pageoptions][course-archives-page-layout]" type="hidden" value="<?php echo esc_attr($v);?>"/>
                        </div>

                        <?php $sidebar_left = $sidebar_right = '';
                           if($v == 'content-full-width') {
                              $sidebar_both = 'style="display:none;"'; 
                           } elseif($v == 'with-left-sidebar') {
                              $sidebar_right = 'style="display:none;"'; 
                           } elseif($v == 'with-right-sidebar') {
                              $sidebar_left = 'style="display:none;"'; 
                           }?>
                        <div id="bpanel-widget-area-options" <?php echo 'class="course-archives-layout" '.$sidebar_both;?>>
                         <div id="left-sidebar-container" class="bpanel-page-left-sidebar" <?php echo "{$sidebar_left}"; ?>>
                             <!-- 2. Standard Sidebar Left Start -->
                             <div id="page-commom-sidebar" class="bpanel-sidebar-section custom-box">
                                 <h6><?php esc_html_e('Show Standard Left Sidebar', 'kriya');?></label></h6>
                                 <?php kriya_switch("",'pageoptions','show-standard-left-sidebar-for-course-archives'); ?>
                             </div><!-- Standard Sidebar Left End-->
                         </div>

                         <div id="right-sidebar-container" class="bpanel-page-right-sidebar" <?php echo "{$sidebar_right}"; ?>>
                             <!-- 3. Standard Sidebar Right Start -->
                             <div id="page-commom-sidebar" class="bpanel-sidebar-section custom-box">
                                 <h6><?php esc_html_e('Show Standard Right Sidebar', 'kriya');?></label></h6>
                                 <?php kriya_switch("",'pageoptions','show-standard-right-sidebar-for-course-archives'); ?>
                             </div><!-- Standard Sidebar Right End-->
                         </div>
                        </div>
                     <!-- Page Layout -->
                  </div>

                  <div class="box-title">
                     <h3><?php esc_html_e('Courses Permalinks', 'kriya');?></h3>
                  </div>
                  <div class="box-content">
                     <!-- Course -->
                        <div class="column one-third">
                           <label><?php esc_html_e('Single Course slug', 'kriya');?></label>
                        </div>
                        <div class="column two-third last">
                           <input name="dttheme[pageoptions][single-course-slug]" type="text" class="medium" value="<?php echo trim(stripslashes(kriya_option('pageoptions','single-course-slug')));?>" />
                           <p class="note"><?php echo sprintf( esc_html__('Do not use characters not allowed in links. Use, eg. dt_courses %sAfter change go to Settings > Permalinks and click Save changes.%s', 'kriya'), '<br> <b>', '</b>');?></p>
                        </div>
                        <div class="hr"></div>

                        <div class="column one-half">
                           <label><?php esc_html_e('Singular Course Name', 'kriya');?></label>
                           <input name="dttheme[pageoptions][singular-course-name]" type="text" class="medium" value="<?php echo trim(stripslashes(kriya_option('pageoptions','singular-course-name')));?>" />
                           <p class="note"><?php esc_html_e('By default "Course", save options &amp; reload.', 'kriya');?></p>
                        </div>
                        <div class="column one-half last">
                           <label><?php esc_html_e('Plural Course Name', 'kriya');?></label>
                           <input name="dttheme[pageoptions][plural-course-name]" type="text" class="medium" value="<?php echo trim(stripslashes(kriya_option('pageoptions','plural-course-name')));?>" />
                           <p class="note"><?php esc_html_e('By default "Courses", save options &amp; reload.', 'kriya');?></p>
                        </div>
                    <!-- Course -->
                  </div>

                  <div class="box-title">
                     <h3><?php esc_html_e('Stages Permalinks', 'kriya');?></h3>
                  </div>
                  <div class="box-content">
                     <!-- Stage -->
                        <div class="column one-third">
                           <label><?php esc_html_e('Single Stage slug', 'kriya');?></label>
                        </div>
                        <div class="column two-third last">
                           <input name="dttheme[pageoptions][single-stage-slug]" type="text" class="medium" value="<?php echo trim(stripslashes(kriya_option('pageoptions','single-stage-slug')));?>" />
                           <p class="note"><?php echo sprintf( esc_html__('Do not use characters not allowed in links. Use, eg. dt_yoga_stages %sAfter change go to Settings > Permalinks and click Save changes.%s', 'kriya'), '<br> <b>', '</b>');?></p>
                        </div>
                        <div class="hr"></div>

                        <div class="column one-half">
                           <label><?php esc_html_e('Singular Stage Name', 'kriya');?></label>
                           <input name="dttheme[pageoptions][singular-stage-name]" type="text" class="medium" value="<?php echo trim(stripslashes(kriya_option('pageoptions','singular-stage-name')));?>" />
                           <p class="note"><?php esc_html_e('By default "Stage", save options &amp; reload.', 'kriya');?></p>
                        </div>
                        <div class="column one-half last">
                           <label><?php esc_html_e('Plural Stage Name', 'kriya');?></label>
                           <input name="dttheme[pageoptions][plural-stage-name]" type="text" class="medium" value="<?php echo trim(stripslashes(kriya_option('pageoptions','plural-stage-name')));?>" />
                           <p class="note"><?php esc_html_e('By default "Stages", save options &amp; reload.', 'kriya');?></p>
                        </div>
                     <!-- Stage -->
                  </div> 

                  <div class="box-title">
                     <h3><?php esc_html_e('Days Permalinks', 'kriya');?></h3>
                  </div>
                  <div class="box-content">
                     <!-- Day -->
                        <div class="column one-third">
                           <label><?php esc_html_e('Single Day slug', 'kriya');?></label>
                        </div>
                        <div class="column two-third last">
                           <input name="dttheme[pageoptions][single-day-slug]" type="text" class="medium" value="<?php echo trim(stripslashes(kriya_option('pageoptions','single-day-slug')));?>" />
                           <p class="note"><?php echo sprintf( esc_html__('Do not use characters not allowed in links. Use, eg. dt_yoga_days %sAfter change go to Settings > Permalinks and click Save changes.%s', 'kriya'), '<br> <b>', '</b>');?></p>
                        </div>
                        <div class="hr"></div>

                        <div class="column one-half">
                           <label><?php esc_html_e('Singular Day Name', 'kriya');?></label>
                           <input name="dttheme[pageoptions][singular-day-name]" type="text" class="medium" value="<?php echo trim(stripslashes(kriya_option('pageoptions','singular-day-name')));?>" />
                           <p class="note"><?php esc_html_e('By default "Day", save options &amp; reload.', 'kriya');?></p>
                        </div>
                        <div class="column one-half last">
                           <label><?php esc_html_e('Plural Day Name', 'kriya');?></label>
                           <input name="dttheme[pageoptions][plural-day-name]" type="text" class="medium" value="<?php echo trim(stripslashes(kriya_option('pageoptions','plural-day-name')));?>" />
                           <p class="note"><?php esc_html_e('By default "Days", save options &amp; reload.', 'kriya');?></p>
                        </div>
                     <!-- Day -->
                  </div> 

                  <div class="box-title">
                     <h3><?php esc_html_e('Classes Permalinks', 'kriya');?></h3>
                  </div>
                  <div class="box-content">
                     <!-- class -->
                        <div class="column one-third">
                           <label><?php esc_html_e('Single class slug', 'kriya');?></label>
                        </div>
                        <div class="column two-third last">
                           <input name="dttheme[pageoptions][single-class-slug]" type="text" class="medium" value="<?php echo trim(stripslashes(kriya_option('pageoptions','single-class-slug')));?>" />
                           <p class="note"><?php echo sprintf( esc_html__('Do not use characters not allowed in links. Use, eg. dt_yoga_classes %sAfter change go to Settings > Permalinks and click Save changes.%s', 'kriya'), '<br> <b>', '</b>' );?></p>
                        </div>
                        <div class="hr"></div>

                        <div class="column one-half">
                           <label><?php esc_html_e('Singular class Name', 'kriya');?></label>
                           <input name="dttheme[pageoptions][singular-class-name]" type="text" class="medium" value="<?php echo trim(stripslashes(kriya_option('pageoptions','singular-class-name')));?>" />
                           <p class="note"><?php esc_html_e('By default "class", save options &amp; reload.', 'kriya');?></p>
                        </div>
                        <div class="column one-half last">
                           <label><?php esc_html_e('Plural class Name', 'kriya');?></label>
                           <input name="dttheme[pageoptions][plural-class-name]" type="text" class="medium" value="<?php echo trim(stripslashes(kriya_option('pageoptions','plural-class-name')));?>" />
                           <p class="note"><?php esc_html_e('By default "Classes", save options &amp; reload.', 'kriya');?></p>
                        </div>
                     <!-- class -->
                  </div>

                  <div class="box-title">
                     <h3><?php esc_html_e('Periods Permalinks', 'kriya');?></h3>
                  </div>
                  <div class="box-content">
                     <!-- period -->
                        <div class="column one-third">
                           <label><?php esc_html_e('Single period slug', 'kriya');?></label>
                        </div>
                        <div class="column two-third last">
                           <input name="dttheme[pageoptions][single-period-slug]" type="text" class="medium" value="<?php echo trim(stripslashes(kriya_option('pageoptions','single-period-slug')));?>" />
                           <p class="note"><?php echo sprintf( esc_html__('Do not use characters not allowed in links. Use, eg. dt_yoga_period %sAfter change go to Settings > Permalinks and click Save changes.%s', 'kriya'), '<br> <b>', '</b>');?></p>
                        </div>
                        <div class="hr"></div>

                        <div class="column one-half">
                           <label><?php esc_html_e('Singular period Name', 'kriya');?></label>
                           <input name="dttheme[pageoptions][singular-period-name]" type="text" class="medium" value="<?php echo trim(stripslashes(kriya_option('pageoptions','singular-period-name')));?>" />
                           <p class="note"><?php esc_html_e('By default "period", save options &amp; reload.', 'kriya');?></p>
                        </div>
                        <div class="column one-half last">
                           <label><?php esc_html_e('Plural period Name', 'kriya');?></label>
                           <input name="dttheme[pageoptions][plural-period-name]" type="text" class="medium" value="<?php echo trim(stripslashes(kriya_option('pageoptions','plural-period-name')));?>" />
                           <p class="note"><?php esc_html_e('By default "Periods", save options &amp; reload.', 'kriya');?></p>
                        </div>
                     <!-- period -->
                  </div>

                  <div class="box-title">
                     <h3><?php esc_html_e('Poses Permalinks', 'kriya');?></h3>
                  </div>
                  <div class="box-content">
                     <!-- pose -->
                        <div class="column one-third">
                           <label><?php esc_html_e('Single pose slug', 'kriya');?></label>
                        </div>
                        <div class="column two-third last">
                           <input name="dttheme[pageoptions][single-pose-slug]" type="text" class="medium" value="<?php echo trim(stripslashes(kriya_option('pageoptions','single-pose-slug')));?>" />
                           <p class="note"><?php echo sprintf( esc_html__('Do not use characters not allowed in links. Use, eg. dt_poses %sAfter change go to Settings > Permalinks and click Save changes.%s', 'kriya'), '<br> <b>', '</b>');?></p>
                        </div>
                        <div class="hr"></div>

                        <div class="column one-half">
                           <label><?php esc_html_e('Singular pose Name', 'kriya');?></label>
                           <input name="dttheme[pageoptions][singular-pose-name]" type="text" class="medium" value="<?php echo trim(stripslashes(kriya_option('pageoptions','singular-pose-name')));?>" />
                           <p class="note"><?php esc_html_e('By default "Pose", save options &amp; reload.', 'kriya');?></p>
                        </div>
                        <div class="column one-half last">
                           <label><?php esc_html_e('Plural pose Name', 'kriya');?></label>
                           <input name="dttheme[pageoptions][plural-pose-name]" type="text" class="medium" value="<?php echo trim(stripslashes(kriya_option('pageoptions','plural-pose-name')));?>" />
                           <p class="note"><?php esc_html_e('By default "Poses", save options &amp; reload.', 'kriya');?></p>
                        </div>
                     <!-- pose -->
                  </div>

                  <div class="box-title">
                     <h3><?php esc_html_e('Poses Category Permalinks', 'kriya');?></h3>
                  </div>
                  <div class="box-content">
                     <!-- pose -->
                        <div class="column one-third">
                           <label><?php esc_html_e('Single pose categories slug', 'kriya');?></label>
                        </div>
                        <div class="column two-third last">
                           <input name="dttheme[pageoptions][single-pose-category-slug]" type="text" class="medium" value="<?php echo trim(stripslashes(kriya_option('pageoptions','single-pose-category-slug')));?>" />
                           <p class="note"><?php echo sprintf( esc_html__('Do not use characters not allowed in links. Use, eg. dt_poses_categories %sAfter change go to Settings > Permalinks and click Save changes.%s', 'kriya'), '<br> <b>', '</b>');?></p>
                        </div>
                        <div class="hr"></div>

                        <div class="column one-half">
                           <label><?php esc_html_e('Singular pose categoriesName', 'kriya');?></label>
                           <input name="dttheme[pageoptions][singular-pose-category-name]" type="text" class="medium" value="<?php echo trim(stripslashes(kriya_option('pageoptions','singular-pose-category-name')));?>" />
                           <p class="note"><?php esc_html_e('By default "Category", save options &amp; reload.', 'kriya');?></p>
                        </div>
                        <div class="column one-half last">
                           <label><?php esc_html_e('Plural pose categories Name', 'kriya');?></label>
                           <input name="dttheme[pageoptions][plural-pose-category-name]" type="text" class="medium" value="<?php echo trim(stripslashes(kriya_option('pageoptions','plural-pose-category-name')));?>" />
                           <p class="note"><?php esc_html_e('By default "Categories", save options &amp; reload.', 'kriya');?></p>
                        </div>
                     <!-- pose -->
                  </div>

                

               </div>
            </div>
         <?php endif; ?>
    </div><!-- .bpanel-main-content end-->
</div><!-- pageoptions end-->