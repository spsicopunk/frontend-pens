<!-- #paypal -->
<div id="paypal" class="bpanel-content">

    <!-- .bpanel-main-content -->
    <div class="bpanel-main-content">

        <!-- tab1-paypal -->
        <div id="tab1-paypal" class="tab-content">
            <!-- .bpanel-box -->
            <div class="bpanel-box">
                <div class="box-title">
                    <h3><?php esc_html_e('Paypal', 'kriya');?></h3>
                </div>
                
                <div class="box-content">
                    <div><?php esc_html_e('You can setup paypal settings, which will be used in yoga course module.', 'kriya');?></div>
                    <br/>

                    <h6><?php esc_html_e('Enable Paypal', 'kriya');?></h6>
                    <div class="column one-fifth">
                          <?php $checked = ( "true" ==  kriya_option('paypal','enable') ) ? ' checked="checked"' : ''; ?>
                          <?php $switchclass = ( "true" ==  kriya_option('paypal','enable') ) ? 'checkbox-switch-on' :'checkbox-switch-off'; ?>
                          <div data-for="dttheme-enable" class="checkbox-switch <?php echo esc_attr($switchclass);?>"></div>
                          <input class="hidden" id="dttheme-enable" name="dttheme[paypal][enable]" type="checkbox" value="true" <?php echo "{$checked}";?> />
                    </div>
                    <div class="column four-fifth last">
                          <p class="note"><?php esc_html_e('YES! to enable paypal for course module.', 'kriya');?></p>
                    </div>
                    <div class="hr"></div>

                    <h6><?php esc_html_e('Account Email id','kriya');?></h6>
                    <input name="dttheme[paypal][email]" type="text" class="large" value="<?php echo kriya_option('paypal', 'email');?>">
                    <p class="note"><?php esc_html_e('Enter a valid Merchant account ID or PayPal account email address. All payments will go to this account.', 'kriya');?></p>
                    <div class="hr"></div>

                    <h6><?php esc_html_e('Currency','kriya');?></h6>
                    <select name="dttheme[paypal][currency]"><?php
                        $selected = kriya_option('paypal', 'currency'); 
                        $currencies = kriya_paypal_currencies();
                        foreach ( $currencies as $k => $v ) {
                            $s =  ( $k === $selected ) ? ' selected="selected" ' : "";
                            echo "<option value='{$k}' {$s}>{$v}</option>";
                        }
                    ?></select>
                    <div class="hr"></div>

                    <h6><?php esc_html_e('Language','kriya');?></h6>
                    <select name="dttheme[paypal][language]"><?php
                        $selected = kriya_option('paypal', 'language'); 
                        $languages = kriya_paypal_languages();
                        foreach ( $languages as $k => $v ) {
                            $s =  ( $k === $selected ) ? ' selected="selected" ' : "";
                            echo "<option value='{$k}' {$s}>{$v}</option>";
                        }
                    ?></select>
                    <div class="hr"></div>

                    <h6><?php esc_html_e('Paypal Live', 'kriya');?></h6>
                    <div class="column one-fifth">
                          <?php $checked = ( "true" ==  kriya_option('paypal','enable-live') ) ? ' checked="checked"' : ''; ?>
                          <?php $switchclass = ( "true" ==  kriya_option('paypal','enable-live') ) ? 'checkbox-switch-on' :'checkbox-switch-off'; ?>
                          <div data-for="dttheme-enable-live" class="checkbox-switch <?php echo esc_attr($switchclass);?>"></div>
                          <input class="hidden" id="dttheme-enable-live" name="dttheme[paypal][enable-live]" type="checkbox" value="true" <?php echo "{$checked}";?> />
                    </div>
                    <div class="column four-fifth last">
                        <p class="note"><?php esc_html_e('YES! to enable paypal live for course module.', 'kriya');?></p>
                    </div>                    
                </div><!-- .box-content -->
            </div><!-- .bpanel-box end -->            
        </div><!--tab1-import-demo end-->

    </div><!-- .bpanel-main-content end-->
</div><!-- paypal end-->