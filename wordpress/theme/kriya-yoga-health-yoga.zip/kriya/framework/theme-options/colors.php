<!-- #colors -->
<div id="colors" class="bpanel-content">

    <!-- .bpanel-main-content -->
    <div class="bpanel-main-content">
        <ul class="sub-panel"> 
            <li><a href="#tab1"><?php esc_html_e('General', 'kriya');?></a></li>
            <li><a href="#tab2"><?php esc_html_e('Header', 'kriya');?></a></li>
			<li><a href="#tab3"><?php esc_html_e('Menu', 'kriya');?></a></li>
            <li><a href="#tab4"><?php esc_html_e('Content', 'kriya');?></a></li>
            <li><a href="#tab5"><?php esc_html_e('Footer', 'kriya');?></a></li>
            <li><a href="#tab6"><?php esc_html_e('Heading', 'kriya');?></a></li>
        </ul>
        
        <!-- tab1-general -->
        <div id="tab1" class="tab-content">
            <!-- .bpanel-box -->
            <div class="bpanel-box">
                <div class="box-title">
                    <h3><?php esc_html_e('Skin', 'kriya');?></h3>
                </div>
                
                <div class="box-content">
                    <div class="column one-third"><label><?php esc_html_e('Theme Skin', 'kriya');?></label></div>
                    <div class="column two-third last">
                        <select id="dttheme-skin-color" name="dttheme[colors][theme-skin]" class="medium dt-chosen-select skin-types">
                        	<optgroup label="Custom">
								<!-- <option value="custom"><?php esc_html_e('Custom Skin', 'kriya'); ?></option> -->
							</optgroup>
							<optgroup label="Skins"><?php
								foreach(kriya_getfolders(get_template_directory()."/css/skins") as $skin):
									$s = selected(kriya_option('colors','theme-skin'),$skin,false);
									echo "<option $s >$skin</option>";
								endforeach;?>
                            </optgroup>    
                        </select>
                        <p class="note"><?php esc_html_e('Choose one of the predefined styles or set your own colors.', 'kriya');?></p>
                    </div>
                    <div class="hr hidden"></div>

                    <div class="column hidden one-third"><label><?php esc_html_e('Body Background Color', 'kriya');?></label></div>
                    <div class="column hidden two-third last"><?php
						$name  =  "dttheme[colors][body-bgcolor]";
						$value =  (kriya_option('colors','body-bgcolor') != NULL) ? kriya_option('colors','body-bgcolor') :"";
                        kriya_admin_color_picker_two($name,$value);?>
                        <p class="note"><?php esc_html_e('Pick a custom background color of the body.(e.g. #a314a3)', 'kriya');?></p>
                    </div>
                    <div class="hr hidden"></div>

                    <?php $panelvisible = ( kriya_option('colors','theme-skin') == 'custom' ) ? 'style="display:block"' : 'style="display:none"'; ?>

					<div class="custom-skin-panel" <?php echo "{$panelvisible}";?>>
                        <div class="column one-third"><label><?php esc_html_e('Default Color', 'kriya');?></label></div>
                        <div class="column two-third last"><?php
                            $name  =  "dttheme[colors][custom-default]";
                            $value =  (kriya_option('colors','custom-default') != NULL) ? kriya_option('colors','custom-default') :"";
                            kriya_admin_color_picker_two($name,$value);?>
                            <p class="note"><?php esc_html_e('Important: This option can be used only with the <b>"Custom Skin"</b>.', 'kriya');?></p>
                        </div>
                        <div class="hr"></div>
    
                        <div class="column one-third"><label><?php esc_html_e('Light Color', 'kriya');?></label></div>
                        <div class="column two-third last"><?php
                            $name  =  "dttheme[colors][custom-light]";
                            $value =  (kriya_option('colors','custom-light') != NULL) ? kriya_option('colors','custom-light') :"";
                            kriya_admin_color_picker_two($name,$value);?>
                            <p class="note"><?php esc_html_e('Important: This option can be used only with the <b>"Custom Skin"</b>.', 'kriya');?></p>
                        </div>
                        <div class="hr"></div>
    
                        <div class="column one-third"><label><?php esc_html_e('Dark Color', 'kriya');?></label></div>
                        <div class="column two-third last"><?php
                            $name  =  "dttheme[colors][custom-dark]";
                            $value =  (kriya_option('colors','custom-dark') != NULL) ? kriya_option('colors','custom-dark') :"";
                            kriya_admin_color_picker_two($name,$value);?>
                            <p class="note"><?php esc_html_e('Important: This option can be used only with the <b>"Custom Skin"</b>.', 'kriya');?></p>
                        </div>
                    </div>    

                </div><!-- .box-content -->
            </div><!-- .bpanel-box end -->
        </div><!--tab1-general end-->

        <!-- tab2-header -->
        <div id="tab2" class="tab-content">
            <!-- .bpanel-box -->
            <div class="bpanel-box">
                <div class="box-title">
                    <h3><?php esc_html_e('Header', 'kriya');?></h3>
                </div>
                
                <div class="box-content">
                    <div class="column one-half">
                    	<label><?php esc_html_e('Header BG Color', 'kriya');?></label>
                        <div class="clear"></div><?php
						$name  =  "dttheme[colors][header-bgcolor]";
						$value =  (kriya_option('colors','header-bgcolor') != NULL) ? kriya_option('colors','header-bgcolor') :"";
                        kriya_admin_color_picker_two($name,$value);?>
                        <p class="note"><?php esc_html_e('Pick a custom background color of the header.(e.g. #a314a3)', 'kriya');?></p>
                    </div>

					<div class="column one-half last">
						<div class="bpanel-option-set">
	                        <?php echo kriya_admin_jqueryuislider( esc_html__("Background opacity", 'kriya'), "dttheme[colors][header-bgcolor-opacity]",
                                                                          kriya_option("colors","header-bgcolor-opacity"),"");?>
                        </div>
                        <p class="note"><?php esc_html_e('You can adjust opacity of the header BG color here.', 'kriya');?></p>
                    </div>
                </div><!-- .box-content -->
                
                <div class="box-title hidden">
                    <h3><?php esc_html_e('Top Bar', 'kriya');?></h3>
                </div>
                
                <div class="box-content hidden">
                    <div class="column one-third"><label><?php esc_html_e('Top Bar BG Color', 'kriya');?></label></div>
                    <div class="column two-third last"><?php
						$name  =  "dttheme[colors][topbar-bgcolor]";
						$value =  (kriya_option('colors','topbar-bgcolor') != NULL) ? kriya_option('colors','topbar-bgcolor') :"";
                        kriya_admin_color_picker_two($name,$value);?>
                        <p class="note"><?php esc_html_e('Pick a custom background color of the top bar.(e.g. #a314a3)', 'kriya');?></p>
                    </div>
                    <div class="hr"></div>
                    
                    <div class="column one-third"><label><?php esc_html_e('Top Bar Text Color', 'kriya');?></label></div>
                    <div class="column two-third last"><?php
						$name  =  "dttheme[colors][topbar-textcolor]";
						$value =  (kriya_option('colors','topbar-textcolor') != NULL) ? kriya_option('colors','topbar-textcolor') :"";
                        kriya_admin_color_picker_two($name,$value);?>
                        <p class="note"><?php esc_html_e('Pick a custom text color of the top bar.(e.g. #a314a3)', 'kriya');?></p>
                    </div>
                    <div class="hr"></div>
                    
                    <div class="column one-third"><label><?php esc_html_e('Top Bar Link Color', 'kriya');?></label></div>
                    <div class="column two-third last"><?php
						$name  =  "dttheme[colors][topbar-linkcolor]";
						$value =  (kriya_option('colors','topbar-linkcolor') != NULL) ? kriya_option('colors','topbar-linkcolor') :"";
                        kriya_admin_color_picker_two($name,$value);?>
                        <p class="note"><?php esc_html_e('Pick a custom link color of the top bar.(e.g. #a314a3)', 'kriya');?></p>
                    </div>
                    <div class="hr"></div>                    
                    
                    <div class="column one-third"><label><?php esc_html_e('Top Bar Link Hover Color', 'kriya');?></label></div>
                    <div class="column two-third last"><?php
						$name  =  "dttheme[colors][topbar-linkhovercolor]";
						$value =  (kriya_option('colors','topbar-linkhovercolor') != NULL) ? kriya_option('colors','topbar-linkhovercolor') :"";
                        kriya_admin_color_picker_two($name,$value);?>
                        <p class="note"><?php esc_html_e('Pick a custom link hover color of the top bar.(e.g. #a314a3)', 'kriya');?></p>
                    </div>
                </div><!-- .box-content -->
                
            </div><!-- .bpanel-box end -->            
        </div><!--tab2-header end-->

        <!-- tab3-menu -->
        <div id="tab3" class="tab-content">
            <!-- .bpanel-box -->
            <div class="bpanel-box">
                <div class="box-title">
                    <h3><?php esc_html_e('Menu', 'kriya');?></h3>
                </div>

                <div class="box-content">
                    <div class="column one-half">
                    	<label><?php esc_html_e('Menu BG Color', 'kriya');?></label>
                        <div class="clear"></div><?php
						$name  =  "dttheme[colors][menu-bgcolor]";
						$value =  (kriya_option('colors','menu-bgcolor') != NULL) ? kriya_option('colors','menu-bgcolor') :"";
                        kriya_admin_color_picker_two($name,$value);?>
                        <p class="note"><?php esc_html_e('Pick a custom background color of the menu.(e.g. #a314a3)', 'kriya');?></p>
                    </div>

					<div class="column one-half last">
						<div class="bpanel-option-set">
	                        <?php echo kriya_admin_jqueryuislider( esc_html__("Background opacity", 'kriya'), "dttheme[colors][menu-bgcolor-opacity]",
                                                                          kriya_option("colors","menu-bgcolor-opacity"),"");?>
                        </div>
                        <p class="note"><?php esc_html_e('You can adjust opacity of the menu BG color here.', 'kriya');?></p>
                    </div>
					<div class="hr"></div>

                    <div class="column one-third"><label><?php esc_html_e('Menu Link Color', 'kriya');?></label></div>
                    <div class="column two-third last"><?php
						$name  =  "dttheme[colors][menu-linkcolor]";
						$value =  (kriya_option('colors','menu-linkcolor') != NULL) ? kriya_option('colors','menu-linkcolor') :"";
                        kriya_admin_color_picker_two($name,$value);?>
                        <p class="note"><?php esc_html_e('Pick a custom color of the menu links.(e.g. #a314a3)', 'kriya');?></p>
                    </div>
                    <div class="hr"></div>

                    <div class="column one-third"><label><?php esc_html_e('Menu Hover Color', 'kriya');?></label></div>
                    <div class="column two-third last"><?php
						$name  =  "dttheme[colors][menu-hovercolor]";
						$value =  (kriya_option('colors','menu-hovercolor') != NULL) ? kriya_option('colors','menu-hovercolor') :"";
                        kriya_admin_color_picker_two($name,$value);?>
                        <p class="note"><?php esc_html_e('Pick a custom color of the hover menu links.(e.g. #a314a3)', 'kriya');?></p>
                    </div>
                    <div class="hr"></div>

                    <div class="column one-third"><label><?php esc_html_e('Menu Link Active Color', 'kriya');?></label></div>
                    <div class="column two-third last"><?php
						$name  =  "dttheme[colors][menu-activecolor]";
						$value =  (kriya_option('colors','menu-activecolor') != NULL) ? kriya_option('colors','menu-activecolor') :"";
                        kriya_admin_color_picker_two($name,$value);?>
                        <p class="note"><?php esc_html_e('Pick a custom color of the active menu links.(e.g. #a314a3)', 'kriya');?></p>
                    </div>
                    <div class="hr hidden"></div>

                    <div class="column one-third hidden"><label><?php esc_html_e('Menu Link Active BG', 'kriya');?></label></div>
                    <div class="column two-third last hidden"><?php
						$name  =  "dttheme[colors][menu-activebgcolor]";
						$value =  (kriya_option('colors','menu-activebgcolor') != NULL) ? kriya_option('colors','menu-activebgcolor') :"";
                        kriya_admin_color_picker_two($name,$value);?>
                        <p class="note"><?php esc_html_e('Pick a custom color of the active menu links background.(e.g. #a314a3)', 'kriya');?></p>
                    </div>
                </div><!-- .box-content -->
            </div><!-- .bpanel-box end -->            
        </div><!--tab3-menu end-->

        <!-- tab4-content -->
        <div id="tab4" class="tab-content">
            <!-- .bpanel-box -->
            <div class="bpanel-box">
                <div class="box-title">
                    <h3><?php esc_html_e('Content', 'kriya');?></h3>
                </div>
                
                <div class="box-content">
                    <div class="column one-third"><label><?php esc_html_e('Text Color', 'kriya');?></label></div>
                    <div class="column two-third last"><?php
						$name  =  "dttheme[colors][content-text-color]";
						$value =  (kriya_option('colors','content-text-color') != NULL) ? kriya_option('colors','content-text-color') :"";
                        kriya_admin_color_picker_two($name,$value);?>
                        <p class="note"><?php esc_html_e('Pick a custom color of the body content text.(e.g. #a314a3)', 'kriya');?></p>
                    </div>
                    <div class="hr"></div>

                    <div class="column one-third"><label><?php esc_html_e('Link Color', 'kriya');?></label></div>
                    <div class="column two-third last"><?php
						$name  =  "dttheme[colors][content-link-color]";
						$value =  (kriya_option('colors','content-link-color') != NULL) ? kriya_option('colors','content-link-color') :"";
                        kriya_admin_color_picker_two($name,$value);?>
                        <p class="note"><?php esc_html_e('Pick a custom color of the body content link.(e.g. #a314a3)', 'kriya');?></p>
                    </div>
                    <div class="hr"></div>

                    <div class="column one-third"><label><?php esc_html_e('Link Hover Color', 'kriya');?></label></div>
                    <div class="column two-third last"><?php
						$name  =  "dttheme[colors][content-link-hcolor]";
						$value =  (kriya_option('colors','content-link-hcolor') != NULL) ? kriya_option('colors','content-link-hcolor') :"";
                        kriya_admin_color_picker_two($name,$value);?>
                        <p class="note"><?php esc_html_e('Pick a custom hover color of the body content link.(e.g. #a314a3)', 'kriya');?></p>
                    </div>
                </div><!-- .box-content -->
            </div><!-- .bpanel-box end -->            
        </div><!--tab4-content end-->

        <!-- tab5-footer -->
        <div id="tab5" class="tab-content">
            <!-- .bpanel-box -->
            <div class="bpanel-box">
                <div class="box-title">
                    <h3><?php esc_html_e('Footer', 'kriya');?></h3>
                </div>
                
                <div class="box-content">
                    <div class="column one-half">
                    	<label><?php esc_html_e('Footer Background Color', 'kriya');?></label>
                        <div class="clear"></div><?php
						$name  =  "dttheme[colors][footer-bgcolor]";
						$value =  (kriya_option('colors','footer-bgcolor') != NULL) ? kriya_option('colors','footer-bgcolor') :"";
                        kriya_admin_color_picker_two($name,$value);?>
                        <p class="note"><?php esc_html_e('Pick a custom color of the footer background.(e.g. #a314a3)', 'kriya');?></p>
                    </div>

					<div class="column one-half last">
						<div class="bpanel-option-set">
	                        <?php echo kriya_admin_jqueryuislider( esc_html__("Background opacity", 'kriya'), "dttheme[colors][footer-bgcolor-opacity]",
                                                                          kriya_option("colors","footer-bgcolor-opacity"),"");?>
                        </div>
                        <p class="note"><?php esc_html_e('You can adjust opacity of the footer BG color here.', 'kriya');?></p>
                    </div>
					<div class="hr"></div>

                    <div class="column one-third"><label><?php esc_html_e('Footer Text Color', 'kriya');?></label></div>
                    <div class="column two-third last"><?php
						$name  =  "dttheme[colors][footer-text-color]";
						$value =  (kriya_option('colors','footer-text-color') != NULL) ? kriya_option('colors','footer-text-color') :"";
                        kriya_admin_color_picker_two($name,$value);?>
                        <p class="note"><?php esc_html_e('Pick a custom color of the footer text elements.(e.g. #a314a3)', 'kriya');?></p>
                    </div>
                    <div class="hr"></div>

                    <div class="column one-third"><label><?php esc_html_e('Footer Link Color', 'kriya');?></label></div>
                    <div class="column two-third last"><?php
						$name  =  "dttheme[colors][footer-link-color]";
						$value =  (kriya_option('colors','footer-link-color') != NULL) ? kriya_option('colors','footer-link-color') :"";
                        kriya_admin_color_picker_two($name,$value);?>
                        <p class="note"><?php esc_html_e('Pick a custom color of the footer links.(e.g. #a314a3)', 'kriya');?></p>
                    </div>
                    <div class="hr"></div>

                    <div class="column one-third"><label><?php esc_html_e('Footer Hover Link Color', 'kriya');?></label></div>
                    <div class="column two-third last"><?php
						$name  =  "dttheme[colors][footer-link-hcolor]";
						$value =  (kriya_option('colors','footer-link-hcolor') != NULL) ? kriya_option('colors','footer-link-hcolor') :"";
                        kriya_admin_color_picker_two($name,$value);?>
                        <p class="note"><?php esc_html_e('Pick a custom hover color of the footer links.(e.g. #a314a3)', 'kriya');?></p>
                    </div>
                    <div class="hr"></div>

                    <div class="column one-third"><label><?php esc_html_e('Footer Heading Color', 'kriya');?></label></div>
                    <div class="column two-third last"><?php
						$name  =  "dttheme[colors][footer-heading-color]";
						$value =  (kriya_option('colors','footer-heading-color') != NULL) ? kriya_option('colors','footer-heading-color') :"";
                        kriya_admin_color_picker_two($name,$value);?>
                        <p class="note"><?php esc_html_e('Pick a custom color of the footer headings.(e.g. #a314a3)', 'kriya');?></p>
                    </div>
                </div><!-- .box-content -->
            </div><!-- .bpanel-box end -->  

            <!-- .bpanel-box -->
            <div class="bpanel-box">
                <div class="box-title">
                    <h3><?php esc_html_e('Copyright', 'kriya');?></h3>
                </div>
                <div class="box-content">
                    <div class="column one-half">
                        <label><?php esc_html_e('Copyright Section BG Color', 'kriya');?></label>
                        <div class="clear"></div><?php
                        $name  =  "dttheme[colors][copyright-bgcolor]";
                        $value =  (kriya_option('colors','copyright-bgcolor') != NULL) ? kriya_option('colors','copyright-bgcolor') :"";
                        kriya_admin_color_picker_two($name,$value);?>
                        <p class="note"><?php esc_html_e('Pick a custom color of the copyright section background.(e.g. #a314a3)', 'kriya');?></p>
                    </div>

                    <div class="column one-half last">
                        <div class="bpanel-option-set">
                            <?php echo kriya_admin_jqueryuislider( esc_html__("Background opacity", 'kriya'), "dttheme[colors][copyright-bgcolor-opacity]", kriya_option("colors","copyright-bgcolor-opacity"),"");?>
                        </div>
                        <p class="note"><?php esc_html_e('You can adjust opacity of the copyright section BG color here.', 'kriya');?></p>
                    </div>
                    <div class="hr"></div>

                    <div class="column one-third"><label><?php esc_html_e('Text Color', 'kriya');?></label></div>
                    <div class="column two-third last"><?php
                        $name  =  "dttheme[colors][copyright-text-color]";
                        $value =  (kriya_option('colors','copyright-text-color') != NULL) ? kriya_option('colors','copyright-text-color') :"";
                        kriya_admin_color_picker_two($name,$value);?>
                        <p class="note"><?php esc_html_e('Pick a custom color of the copyright text elements.(e.g. #a314a3)', 'kriya');?></p>
                    </div>
                    <div class="hr"></div>

                    <div class="column one-third"><label><?php esc_html_e('Link Color', 'kriya');?></label></div>
                    <div class="column two-third last"><?php
                        $name  =  "dttheme[colors][copyright-link-color]";
                        $value =  (kriya_option('colors','copyright-link-color') != NULL) ? kriya_option('colors','copyright-link-color') :"";
                        kriya_admin_color_picker_two($name,$value);?>
                        <p class="note"><?php esc_html_e('Pick a custom color of the copyright links.(e.g. #a314a3)', 'kriya');?></p>
                    </div>
                    <div class="hr"></div> 
                    
                    <div class="column one-third"><label><?php esc_html_e('Hover Link Color', 'kriya');?></label></div>
                    <div class="column two-third last"><?php
                        $name  =  "dttheme[colors][copyright-link-hcolor]";
                        $value =  (kriya_option('colors','copyright-link-hcolor') != NULL) ? kriya_option('colors','copyright-link-hcolor') :"";
                        kriya_admin_color_picker_two($name,$value);?>
                        <p class="note"><?php esc_html_e('Pick a custom hover color of the copyright links.(e.g. #a314a3)', 'kriya');?></p>
                    </div>
                </div>
            </div><!-- .bpanel-box end -->
        </div><!--tab5-footer end-->

        <!-- tab6-heading -->
        <div id="tab6" class="tab-content">
            <!-- .bpanel-box -->
            <div class="bpanel-box">
                <div class="box-title">
                    <h3><?php esc_html_e('Heading', 'kriya');?></h3>
                </div>
                
                <div class="box-content">
                    <div class="column one-third"><label><?php esc_html_e('Heading H1 Color', 'kriya');?></label></div>
                    <div class="column two-third last"><?php
						$name  =  "dttheme[colors][heading-h1-color]";
						$value =  (kriya_option('colors','heading-h1-color') != NULL) ? kriya_option('colors','heading-h1-color') :"";
                        kriya_admin_color_picker_two($name,$value);?>
                        <p class="note"><?php esc_html_e('Pick a custom color of the heading tag h1.(e.g. #a314a3)', 'kriya');?></p>
                    </div>
                    <div class="hr"></div>
                    
                    <div class="column one-third"><label><?php esc_html_e('Heading H2 Color', 'kriya');?></label></div>
                    <div class="column two-third last"><?php
						$name  =  "dttheme[colors][heading-h2-color]";
						$value =  (kriya_option('colors','heading-h2-color') != NULL) ? kriya_option('colors','heading-h2-color') :"";
                        kriya_admin_color_picker_two($name,$value);?>
                        <p class="note"><?php esc_html_e('Pick a custom color of the heading tag h2.(e.g. #a314a3)', 'kriya');?></p>
                    </div>
                    <div class="hr"></div>

                    <div class="column one-third"><label><?php esc_html_e('Heading H3 Color', 'kriya');?></label></div>
                    <div class="column two-third last"><?php
						$name  =  "dttheme[colors][heading-h3-color]";
						$value =  (kriya_option('colors','heading-h3-color') != NULL) ? kriya_option('colors','heading-h3-color') :"";
                        kriya_admin_color_picker_two($name,$value);?>
                        <p class="note"><?php esc_html_e('Pick a custom color of the heading tag h3.(e.g. #a314a3)', 'kriya');?></p>
                    </div>
                    <div class="hr"></div>

                    <div class="column one-third"><label><?php esc_html_e('Heading H4 Color', 'kriya');?></label></div>
                    <div class="column two-third last"><?php
						$name  =  "dttheme[colors][heading-h4-color]";
						$value =  (kriya_option('colors','heading-h4-color') != NULL) ? kriya_option('colors','heading-h4-color') :"";
                        kriya_admin_color_picker_two($name,$value);?>
                        <p class="note"><?php esc_html_e('Pick a custom color of the heading tag h4.(e.g. #a314a3)', 'kriya');?></p>
                    </div>
                    <div class="hr"></div>

                    <div class="column one-third"><label><?php esc_html_e('Heading H5 Color', 'kriya');?></label></div>
                    <div class="column two-third last"><?php
						$name  =  "dttheme[colors][heading-h5-color]";
						$value =  (kriya_option('colors','heading-h5-color') != NULL) ? kriya_option('colors','heading-h5-color') :"";
                        kriya_admin_color_picker_two($name,$value);?>
                        <p class="note"><?php esc_html_e('Pick a custom color of the heading tag h5.(e.g. #a314a3)', 'kriya');?></p>
                    </div>
                    <div class="hr"></div>

                    <div class="column one-third"><label><?php esc_html_e('Heading H6 Color', 'kriya');?></label></div>
                    <div class="column two-third last"><?php
						$name  =  "dttheme[colors][heading-h6-color]";
						$value =  (kriya_option('colors','heading-h6-color') != NULL) ? kriya_option('colors','heading-h6-color') :"";
                        kriya_admin_color_picker_two($name,$value);?>
                        <p class="note"><?php esc_html_e('Pick a custom color of the heading tag h6.(e.g. #a314a3)', 'kriya');?></p>
                    </div>
                </div><!-- .box-content -->
            </div><!-- .bpanel-box end -->            
        </div><!--tab6-heading end-->

    </div><!-- .bpanel-main-content end-->
</div><!-- colors end-->