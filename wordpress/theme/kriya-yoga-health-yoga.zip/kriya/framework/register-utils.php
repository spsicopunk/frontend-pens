<?php
/*
 * Load default theme options, while activating kriya theme
 */
if( !function_exists( 'kriya_default_option' )){
function kriya_default_option() {

	$footer_bg_img = get_template_directory_uri(). '/images/pattern-grudge.png';
	$page_notfound_bg_img = get_template_directory_uri(). '/images/bg2.jpg';
	$coming_bg_img = get_template_directory_uri(). '/images/bg3.jpg';


	$general = array(
		'enable-loader' => 'true',
		'show-pagecomments' => 'false',
		'enable-responsive' => 'true',
		'show-mobileslider' => 'true'
	);

	$layout = array(
		'logo' => 'true',
		'show-breadcrumb' => 'true',
		'breadcrumb-delimiter' => 'fa fa-angle-right',
		'breadcrumb-style' => 'breadcrumb-right',
		'site-layout' => 'wide',
		'bg-type' => 'bg-patterns',
		'show-boxed-layout-pattern-color' => 'true',
		'show-boxed-layout-bg-color' => 'true',
		'header-type' => 'split-header boxed-header',
		'layout-stickynav' => 'true',
		'header-position' => 'above slider',
		'header-transparant' => 'semi-transparent-header',
		'menu-active-type' => 'menu-active-highlight',
		'menu-border' => 'true',
		'menu-border-width-top' => '10',
		'menu-border-width-right' => '10',
		'menu-border-width-bottom' => '10',
		'menu-border-width-left' => '10',
		'menu-border-style' => 'solid',
		'menu-border-color' => '#ffffff',
		'menu-boxshadow' => 'true',
		'menu-title-bg' => 'true',
		'menu-title-bg-color' => '#ffda6b',
		'menu-title-text-color' => '#484338',
		'menu-title-hoverbg-color' => '#484338',
		'menu-title-hovertext-color' => '#ffffff',
		'menu-title-border-style' => 'dotted',
		'menu-link-text-dcolor' => '#484338',
		'menu-link-text-dhcolor' => '#7e8846',
		'menu-links-border' => 'true',		
		'menu-link-border-width' =>  '1',
		'menu-link-border-color' => '#a58251',
		'menu-link-border-style' => 'dashed',
		'menu-link-arrow' => 'true',
		'menu-link-arrow-style' => 'single',
		'show-sociables' => 'on',
		'enable-footer' => 'true',
		'footer-columns' => '11',
		'footer-bg-repeat' => 'repeat',
		'footer-bg' => $footer_bg_img ,
		'footer-bg-position' => 'top left',
		'enable-copyright' => 'true',
		'copyright-content' => '<div class=\"aligncenter\">KRIYA &copy; 2016. Made by <a href=\"#\">DesignThemes</a>.</div>',
		'enable-customcss' => 'true',
		'customcss-content' => '#main-menu ul li.menu-item-simple-parent.with-box-shadow ul, #main-menu .menu-item-megamenu-parent.with-box-shadow .megamenu-child-container { box-shadow: 0 0 0 1px #a58251 inset; }
#footer { background-color: #d4ad76; }
.footer-copyright .vc_separator .vc_sep_holder .vc_sep_line { border-color: #a58251; }
.footer-copyright, .footer-copyright a, .footer-copyright.dt-sc-dark-bg, .footer-copyright.dt-sc-dark-bg a { color: #a58251; }

/*----*****---- << Responsive >> ----*****----*/
@media only screen and (max-width: 767px) {
	#main-menu ul li.menu-item-simple-parent ul, #main-menu .megamenu-child-container { border: none !important; }
	#main-menu .menu-item-megamenu-parent.menu-title-with-bg .megamenu-child-container > ul.sub-menu > li > a, #main-menu .menu-item-megamenu-parent.menu-title-with-bg .megamenu-child-container > ul.sub-menu > li > .nolink-menu, #main-menu .megamenu-child-container ul.sub-menu > li > ul li a { padding-top: 7px; padding-bottom: 7px; }
	#main-menu .menu-item-megamenu-parent.menu-title-with-bg .megamenu-child-container > ul.sub-menu > li > a.dt-menu-expand { right: 15px; top: 0; }
	#main-menu ul li.menu-item-simple-parent ul li { padding-right: 15px; }
}'
	);	
	
	$social = array(
		'social-1' => array(
			'icon' => 'fa-facebook',
			'link' => '#'
		),
		'social-2' => array(
			'icon' => 'fa-twitter',
			'link' => '#'
		),
		'social-3' => array(
			'icon' => 'fa-google-plus',
			'link' => '#'
		)
	);
	
	$pageoptions = array(
		'post-archives-page-layout' => 'with-right-sidebar',
		'show-standard-left-sidebar-for-post-archives' => 'true',
		'show-standard-right-sidebar-for-post-archives' => 'true',
		'post-archives-post-layout' => 'one-half-column',
		'post-format-meta' => 'true',
		'post-author-meta' => 'true',
		'post-date-meta' => 'true',
		'post-comment-meta' => 'true',
		'post-category-meta' => 'true',
		'post-tag-meta' => 'true',
		'single-portfolio-related' => 'true',
		'portfolio-archives-page-layout' => 'content-full-width',
		'show-standard-left-sidebar-for-portfolio-archives' => 'true',
		'show-standard-right-sidebar-for-portfolio-archives' => 'true',
		'portfolio-archives-post-layout' => 'one-half-column',
		'portfolio-grid-space-size' => '5',
		'enable-404message' => 'true',
		'notfound-bg' => $page_notfound_bg_img ,
		'notfound-bg-repeat' => 'no-repeat',
		'notfound-bg-position' => 'bottom center',
		'show-notfound-bg-color' => 'true',
		'comingsoon-launchdate' => '08/11/2016 12:00:00',
		'comingsoon-bg' => $coming_bg_img ,
		'comingsoon-bg-repeat' => 'no-repeat',
		'show-comingsoon-bg-color' => 'true',
		'comingsoon-bg-style' => 'background-position: center 85%;',

		'course-archives-post-layout' => 'one-third-column',
		'course-archives-page-layout' => 'content-full-width',
		'single-course-slug' => 'dt_courses',
		'singular-course-name' => 'Course',
		'plural-course-name' => 'Courses',
		'single-stage-slug' => 'dt_yoga_stages',
		'singular-stage-name' => 'Stage',
		'plural-stage-name' => 'Stages',
		'single-day-slug' => 'dt_yoga_days',
		'singular-day-name' => 'Day',
		'plural-day-name' => 'Days',
		'single-class-slug' => 'dt_yoga_classes',
		'singular-class-name' => 'Class',
		'plural-class-name' => 'Classes',
		'single-period-slug' => 'dt_yoga_period',
		'singular-period-name' => 'Period',
		'plural-period-name' => 'Periods',
		'single-pose-slug' => 'dt_poses',
		'singular-pose-name' => 'Pose',
		'plural-pose-name' => 'Poses',
		'single-pose-category-slug' => 'dt_poses_categories',
		'singular-pose-category-name' => 'Category',
		'plural-pose-category-name' => 'Categories'
	);

	$woo = array(
		'shop-product-per-page' => '12',
		'shop-page-product-layout' => 'one-fourth-column',
		'product-category-layout' => 'content-full-width',
		'product-tag-layout' => 'content-full-width',
		'show-shop-standard-left-sidebar-for-product-category-layout' => 'true',
		'show-shop-standard-right-sidebar-for-product-category-layout' => 'true',
		'show-shop-standard-left-sidebar-for-product-tag-layout' => 'true',
		'show-shop-standard-right-sidebar-for-product-tag-layout' => 'true'
	);

	$colors = array(
		'theme-skin' => 'brown',

		'content-text-color' => '#484338',
		'content-link-color' => '#484338',
		'content-link-hcolor' => '#7e8446',

		'body-bgcolor' => '#f5f0e3',
		'menu-linkcolor' => '#ffffff',
		'footer-bgcolor' => '#d4ad76',
		'footer-text-color' => '#484338',
		'footer-link-color' => '#484338',
		'footer-link-hcolor' => '#484338',
		'footer-heading-color' => '#484338',
		'copyright-bgcolor' => '#000000',
		'copyright-bgcolor-opacity' => '0.6',
		'copyright-text-color' => '#a58251',
		'copyright-link-color' => '#a58251',
		'copyright-link-hcolor' => '#a58251',

		'heading-h1-color' => '#484338',
		'heading-h2-color' => '#484338',
		'heading-h3-color' => '#484338',
		'heading-h4-color' => '#484338',
		'heading-h5-color' => '#484338',
		'heading-h6-color' => '#484338',

	);

	$fonts = array(
		'content-font' => 'Rosario',
		'menu-font' => 'Overlock',
		'pagetitle-font' => 'PT Serif',
		'h1-font' => 'PT Serif',
		'h2-font' => 'PT Serif',
		'h3-font' => 'PT Serif',
		'h4-font' => 'PT Serif',
		'h5-font' => 'PT Serif',
		'h6-font' => 'PT Serif',
		'font-style' => array( '100', '100italic', '200', '200italic','300', '300italic','400', '400italic','500', '500italic','600', '600italic','700', '700italic','800', '800italic','900', '900italic'),
		'content-font-size' => '16',
		'menu-font-size' => '18',
		'h1-font-size' => '35',
		'h2-font-size' => '30',
		'h3-font-size' => '28',
		'h4-font-size' => '24',
		'h5-font-size' => '20',
		'h6-font-size' => '18',
		'menu-weight' => 'bold',
		'h1-weight' => 'bold',
		'h2-weight' => 'bold',
		'h3-weight' => 'bold',
		'h4-weight' => 'bold',
		'h5-weight' => 'bold',
		'h6-weight' => 'bold',
		'h2-letter-spacing' => '4.5px'
	);

	$paypal = array(
		'enable' => 'true',
		'currency' => 'USD',
		'language' => 'EN_US',
		'email' => 'giamdesigning@gmail.com'
	);
	
	$data = array(
		'general' => $general,
		'layout'  => $layout,
		'social'  => $social,
		'pageoptions' => $pageoptions,
		'woo'	  => $woo,
		'colors'  => $colors,
		'fonts'   => $fonts,
		'paypal' => $paypal,
	);
	return $data;
}
}
/*
 * Create function to get theme options
 */
if( !function_exists( 'kriya_option' )) {
function kriya_option($key1, $key2 = '') {
	$options = get_option ('kriya-opts');
	$output = NULL;

	if (is_array ( $options )) {

		if (array_key_exists ( $key1, $options )) {
			$output = $options [$key1];
			if (is_array ( $output ) && ! empty ( $key2 )) {
				$output = (array_key_exists ( $key2, $output ) && (! empty ( $output [$key2] ))) ? $output [$key2] : NULL;
			}
		} else {
			$output = $output;
		}
	}
	return $output;
}
}
/**
 * Getting individual Theme options
 */
if( ! function_exists( 'kriya_opts_get' ) ) {

	function kriya_opts_get( $opt_name, $default = null ) {

		$opts = get_option ('kriya-opts');
		$opts = is_array( $opts ) ? $opts : array();

		$value = kriya_array_search($opts, $opt_name);
		if( ! empty( $value ) ){
			return $value;
		} else {
			return $default;
		}
	}
}

/* 
 * Showing individual Theme options
 */
if( ! function_exists( 'kriya_opts_show' ) ) {

	function kriya_opts_show( $opt_name, $default = null ){

		// getting option
		$opts = get_option ( 'kriya-opts' );
		$opts = is_array( $opts ) ? $opts : array();

		$value = kriya_array_search($opts, $opt_name);
		if( ! empty( $value ) ){
			echo "{$value}";
		} else {
			echo "{$default}";
		}
	}
}

/* 
 * Theme Options search using key
 */
if( ! function_exists( 'kriya_array_search' ) ) {
function kriya_array_search(array $array, $search) {
	$keys = false;

	foreach ($array as $key => $value) {
		if (is_array($array[$key])) {
			if (array_key_exists($search, $array[$key])) {
				return $array[$key][$search];
			} else {
			    $keys = kriya_array_search($array[$key], $search);
			}
		}
	}
	return $keys;
}
}

/**
 * List all images from specific directory
 */
if( ! function_exists( 'kriya_listImage' ) ) {
function kriya_listImage($dir) {

	$sociables = array ();
	$icon_types = array ( 'jpg', 'jpeg', 'gif', 'png' );

	if (is_dir ( $dir )) {
		$handle = opendir ( $dir );
		while ( false !== ($dirname = readdir ( $handle )) ) {
			if ($dirname != "." && $dirname != "..") {
				$parts = explode ( '.', $dirname );
				$ext = strtolower ( $parts [count ( $parts ) - 1] );

				if (in_array ( $ext, $icon_types )) {
					$option = $parts [count ( $parts ) - 2];
					$sociables [$dirname] = str_replace ( ' ', '', $option );
				}
			}
		}
		closedir ( $handle );
	}

	return $sociables;
}
}
/**
 * Getting sub directories from parent directory
 */
if( ! function_exists( 'kriya_getfolders' ) ) {
function kriya_getfolders($directory, $starting_with = "", $sorting_order = 0) {

	if (! is_dir ( $directory ))
		return false;

	$dirs = array ();
	$handle = opendir ( $directory );
	while ( false !== ($dirname = readdir ( $handle )) ) {
		if ($dirname != "." && $dirname != ".." && is_dir ( $directory . "/" . $dirname )) {
			if ($starting_with == "")
				$dirs [] = $dirname;
			else {
				$filter = strstr ( $dirname, $starting_with );
				if ($filter !== false)
					$dirs [] = $dirname;
			}
		}
	}
	
	closedir ( $handle );
	
	if ($sorting_order == 1) {
		rsort ( $dirs );
	} else {
		sort ( $dirs );
	}
	return $dirs;
}
}
/**
 *  List of social icons
 */
if( ! function_exists( 'kriya_listSocial' ) ) {
function kriya_listSocial() {

	$sociables = array('fa-dribbble' => 'Dribble', 'fa-flickr' => 'Flickr', 'fa-github' => 'GitHub', 'fa-pinterest' => 'Pinterest', 'fa-stack-overflow' => 'Stack Overflow', 'fa-twitter' => 'Twitter', 'fa-youtube' => 'YouTube', 'fa-android' => 'Android', 'fa-dropbox' => 'Dropbox', 'fa-instagram' => 'Instagram', 'fa-windows' => 'Windows', 'fa-apple' => 'Apple', 'fa-facebook' => 'Facebook', 'fa-google-plus' => 'Google Plus', 'fa-linkedin' => 'LinkedIn', 'fa-skype' => 'Skype', 'fa-tumblr' => 'Tumblr', 'fa-vimeo-square' => 'Vimeo');
	return $sociables;
}
}
/**
 *  List of Google Fonts
 */
if( ! function_exists( 'kriya_fonts' ) ) {
function kriya_fonts( $type = false ) {

	$fonts = array();

	// system fonts won't be downloaded from Google Fonts
	$fonts['system'] = array( 'Arial', 'Georgia', 'Tahoma', 'Times New Roman', 'Trebuchet', 'Verdana' );

	// custom uploaded font
	if( kriya_option( 'fonts', 'customfont-name' ) || kriya_option( 'fonts', 'customfont2-name' ) ){
		$fonts['custom'] = array();

		if( kriya_option( 'fonts', 'customfont-name' ) ) $fonts['custom'][] = kriya_option( 'fonts', 'customfont-name' );
		if( kriya_option( 'fonts', 'customfont2-name' ) ) $fonts['custom'][] = kriya_option( 'fonts', 'customfont2-name' );
	}

	$fonts['all'] = array(
		'ABeeZee',
		'Abel',
		'Abril Fatface',
		'Aclonica',
		'Acme',
		'Actor',
		'Adamina',
		'Advent Pro',
		'Aguafina Script',
		'Akronim',
		'Aladin',
		'Aldrich',
		'Alef',
		'Alegreya',
		'Alegreya SC',
		'Alegreya Sans',
		'Alegreya Sans SC',
		'Alex Brush',
		'Alfa Slab One',
		'Alice',
		'Alike',
		'Alike Angular',
		'Allan',
		'Allerta',
		'Allerta Stencil',
		'Allura',
		'Almendra',
		'Almendra Display',
		'Almendra SC',
		'Amarante',
		'Amaranth',
		'Amatic SC',
		'Amethysta',
		'Anaheim',
		'Andada',
		'Andika',
		'Angkor',
		'Annie Use Your Telescope',
		'Anonymous Pro',
		'Antic',
		'Antic Didone',
		'Antic Slab',
		'Anton',
		'Arapey',
		'Arbutus',
		'Arbutus Slab',
		'Architects Daughter',
		'Archivo Black',
		'Archivo Narrow',
		'Arimo',
		'Arizonia',
		'Armata',
		'Artifika',
		'Arvo',
		'Asap',
		'Asset',
		'Astloch',
		'Asul',
		'Atomic Age',
		'Aubrey',
		'Audiowide',
		'Autour One',
		'Average',
		'Average Sans',
		'Averia Gruesa Libre',
		'Averia Libre',
		'Averia Sans Libre',
		'Averia Serif Libre',
		'Bad Script',
		'Balthazar',
		'Bangers',
		'Basic',
		'Battambang',
		'Baumans',
		'Bayon',
		'Belgrano',
		'Belleza',
		'BenchNine',
		'Bentham',
		'Berkshire Swash',
		'Bevan',
		'Bigelow Rules',
		'Bigshot One',
		'Bilbo',
		'Bilbo Swash Caps',
		'Bitter',
		'Black Ops One',
		'Bokor',
		'Bonbon',
		'Boogaloo',
		'Bowlby One',
		'Bowlby One SC',
		'Brawler',
		'Bree Serif',
		'Bubblegum Sans',
		'Bubbler One',
		'Buda',
		'Buenard',
		'Butcherman',
		'Butterfly Kids',
		'Cabin',
		'Cabin Condensed',
		'Cabin Sketch',
		'Caesar Dressing',
		'Cagliostro',
		'Calligraffitti',
		'Cambo',
		'Candal',
		'Cantarell',
		'Cantata One',
		'Cantora One',
		'Capriola',
		'Cardo',
		'Carme',
		'Carrois Gothic',
		'Carrois Gothic SC',
		'Carter One',
		'Caudex',
		'Cedarville Cursive',
		'Ceviche One',
		'Changa One',
		'Chango',
		'Chau Philomene One',
		'Chela One',
		'Chelsea Market',
		'Chenla',
		'Cherry Cream Soda',
		'Cherry Swash',
		'Chewy',
		'Chicle',
		'Chivo',
		'Cinzel',
		'Cinzel Decorative',
		'Clicker Script',
		'Coda',
		'Coda Caption',
		'Codystar',
		'Combo',
		'Comfortaa',
		'Coming Soon',
		'Concert One',
		'Condiment',
		'Content',
		'Contrail One',
		'Convergence',
		'Cookie',
		'Copse',
		'Corben',
		'Courgette',
		'Cousine',
		'Coustard',
		'Covered By Your Grace',
		'Crafty Girls',
		'Creepster',
		'Crete Round',
		'Crimson Text',
		'Croissant One',
		'Crushed',
		'Cuprum',
		'Cutive',
		'Cutive Mono',
		'Damion',
		'Dancing Script',
		'Dangrek',
		'Dawning of a New Day',
		'Days One',
		'Delius',
		'Delius Swash Caps',
		'Delius Unicase',
		'Della Respira',
		'Denk One',
		'Devonshire',
		'Didact Gothic',
		'Diplomata',
		'Diplomata SC',
		'Domine',
		'Donegal One',
		'Doppio One',
		'Dorsa',
		'Dosis',
		'Dr Sugiyama',
		'Droid Sans',
		'Droid Sans Mono',
		'Droid Serif',
		'Duru Sans',
		'Dynalight',
		'EB Garamond',
		'Eagle Lake',
		'Eater',
		'Economica',
		'Ek Mukta',
		'Electrolize',
		'Elsie',
		'Elsie Swash Caps',
		'Emblema One',
		'Emilys Candy',
		'Engagement',
		'Englebert',
		'Enriqueta',
		'Erica One',
		'Esteban',
		'Euphoria Script',
		'Ewert',
		'Exo',
		'Exo 2',
		'Expletus Sans',
		'Fanwood Text',
		'Fascinate',
		'Fascinate Inline',
		'Faster One',
		'Fasthand',
		'Fauna One',
		'Federant',
		'Federo',
		'Felipa',
		'Fenix',
		'Finger Paint',
		'Fira Mono',
		'Fira Sans',
		'Fjalla One',
		'Fjord One',
		'Flamenco',
		'Flavors',
		'Fondamento',
		'Fontdiner Swanky',
		'Forum',
		'Francois One',
		'Freckle Face',
		'Fredericka the Great',
		'Fredoka One',
		'Freehand',
		'Fresca',
		'Frijole',
		'Fruktur',
		'Fugaz One',
		'GFS Didot',
		'GFS Neohellenic',
		'Gabriela',
		'Gafata',
		'Galdeano',
		'Galindo',
		'Gentium Basic',
		'Gentium Book Basic',
		'Geo',
		'Geostar',
		'Geostar Fill',
		'Germania One',
		'Gilda Display',
		'Give You Glory',
		'Glass Antiqua',
		'Glegoo',
		'Gloria Hallelujah',
		'Goblin One',
		'Gochi Hand',
		'Gorditas',
		'Goudy Bookletter 1911',
		'Graduate',
		'Grand Hotel',
		'Gravitas One',
		'Great Vibes',
		'Griffy',
		'Gruppo',
		'Gudea',
		'Habibi',
		'Halant',
		'Hammersmith One',
		'Hanalei',
		'Hanalei Fill',
		'Handlee',
		'Hanuman',
		'Happy Monkey',
		'Headland One',
		'Henny Penny',
		'Herr Von Muellerhoff',
		'Hind',
		'Holtwood One SC',
		'Homemade Apple',
		'Homenaje',
		'IM Fell DW Pica',
		'IM Fell DW Pica SC',
		'IM Fell Double Pica',
		'IM Fell Double Pica SC',
		'IM Fell English',
		'IM Fell English SC',
		'IM Fell French Canon',
		'IM Fell French Canon SC',
		'IM Fell Great Primer',
		'IM Fell Great Primer SC',
		'Iceberg',
		'Iceland',
		'Imprima',
		'Inconsolata',
		'Inder',
		'Indie Flower',
		'Inika',
		'Irish Grover',
		'Istok Web',
		'Italiana',
		'Italianno',
		'Jacques Francois',
		'Jacques Francois Shadow',
		'Jim Nightshade',
		'Jockey One',
		'Jolly Lodger',
		'Josefin Sans',
		'Josefin Slab',
		'Joti One',
		'Judson',
		'Julee',
		'Julius Sans One',
		'Junge',
		'Jura',
		'Just Another Hand',
		'Just Me Again Down Here',
		'Kalam',
		'Kameron',
		'Kantumruy',
		'Karla',
		'Karma',
		'Kaushan Script',
		'Kavoon',
		'Kdam Thmor',
		'Keania One',
		'Kelly Slab',
		'Kenia',
		'Khand',
		'Khmer',
		'Kite One',
		'Knewave',
		'Kotta One',
		'Koulen',
		'Kranky',
		'Kreon',
		'Kristi',
		'Krona One',
		'La Belle Aurore',
		'Laila',
		'Lancelot',
		'Lato',
		'League Script',
		'Leckerli One',
		'Ledger',
		'Lekton',
		'Lemon',
		'Libre Baskerville',
		'Life Savers',
		'Lilita One',
		'Lily Script One',
		'Limelight',
		'Linden Hill',
		'Lobster',
		'Lobster Two',
		'Londrina Outline',
		'Londrina Shadow',
		'Londrina Sketch',
		'Londrina Solid',
		'Lora',
		'Love Ya Like A Sister',
		'Loved by the King',
		'Lovers Quarrel',
		'Luckiest Guy',
		'Lusitana',
		'Lustria',
		'Macondo',
		'Macondo Swash Caps',
		'Magra',
		'Maiden Orange',
		'Mako',
		'Marcellus',
		'Marcellus SC',
		'Marck Script',
		'Margarine',
		'Marko One',
		'Marmelad',
		'Marvel',
		'Mate',
		'Mate SC',
		'Maven Pro',
		'McLaren',
		'Meddon',
		'MedievalSharp',
		'Medula One',
		'Megrim',
		'Meie Script',
		'Merienda',
		'Merienda One',
		'Merriweather',
		'Merriweather Sans',
		'Metal',
		'Metal Mania',
		'Metamorphous',
		'Metrophobic',
		'Michroma',
		'Milonga',
		'Miltonian',
		'Miltonian Tattoo',
		'Miniver',
		'Miss Fajardose',
		'Modern Antiqua',
		'Molengo',
		'Molle',
		'Monda',
		'Monofett',
		'Monoton',
		'Monsieur La Doulaise',
		'Montaga',
		'Montez',
		'Montserrat',
		'Montserrat Alternates',
		'Montserrat Subrayada',
		'Moul',
		'Moulpali',
		'Mountains of Christmas',
		'Mouse Memoirs',
		'Mr Bedfort',
		'Mr Dafoe',
		'Mr De Haviland',
		'Mrs Saint Delafield',
		'Mrs Sheppards',
		'Muli',
		'Mystery Quest',
		'Neucha',
		'Neuton',
		'New Rocker',
		'News Cycle',
		'Niconne',
		'Nixie One',
		'Nobile',
		'Nokora',
		'Norican',
		'Nosifer',
		'Nothing You Could Do',
		'Noticia Text',
		'Noto Sans',
		'Noto Serif',
		'Nova Cut',
		'Nova Flat',
		'Nova Mono',
		'Nova Oval',
		'Nova Round',
		'Nova Script',
		'Nova Slim',
		'Nova Square',
		'Numans',
		'Nunito',
		'Odor Mean Chey',
		'Offside',
		'Old Standard TT',
		'Oldenburg',
		'Oleo Script',
		'Oleo Script Swash Caps',
		'Open Sans',
		'Open Sans Condensed',
		'Oranienbaum',
		'Orbitron',
		'Oregano',
		'Orienta',
		'Original Surfer',
		'Oswald',
		'Over the Rainbow',
		'Overlock',
		'Overlock SC',
		'Ovo',
		'Oxygen',
		'Oxygen Mono',
		'PT Mono',
		'PT Sans',
		'PT Sans Caption',
		'PT Sans Narrow',
		'PT Serif',
		'PT Serif Caption',
		'Pacifico',
		'Paprika',
		'Parisienne',
		'Passero One',
		'Passion One',
		'Pathway Gothic One',
		'Patrick Hand',
		'Patrick Hand SC',
		'Patua One',
		'Paytone One',
		'Peralta',
		'Permanent Marker',
		'Petit Formal Script',
		'Petrona',
		'Philosopher',
		'Piedra',
		'Pinyon Script',
		'Pirata One',
		'Plaster',
		'Play',
		'Playball',
		'Playfair Display',
		'Playfair Display SC',
		'Podkova',
		'Poiret One',
		'Poller One',
		'Poly',
		'Pompiere',
		'Pontano Sans',
		'Port Lligat Sans',
		'Port Lligat Slab',
		'Prata',
		'Preahvihear',
		'Press Start 2P',
		'Princess Sofia',
		'Prociono',
		'Prosto One',
		'Puritan',
		'Purple Purse',
		'Quando',
		'Quantico',
		'Quattrocento',
		'Quattrocento Sans',
		'Questrial',
		'Quicksand',
		'Quintessential',
		'Qwigley',
		'Racing Sans One',
		'Radley',
		'Rajdhani',
		'Raleway',
		'Raleway Dots',
		'Rambla',
		'Rammetto One',
		'Ranchers',
		'Rancho',
		'Rationale',
		'Redressed',
		'Reenie Beanie',
		'Revalia',
		'Ribeye',
		'Ribeye Marrow',
		'Righteous',
		'Risque',
		'Roboto',
		'Roboto Condensed',
		'Roboto Slab',
		'Rochester',
		'Rock Salt',
		'Rokkitt',
		'Romanesco',
		'Ropa Sans',
		'Rosario',
		'Rosarivo',
		'Rouge Script',
		'Rozha One',
		'Rubik Mono One',
		'Rubik One',
		'Ruda',
		'Rufina',
		'Ruge Boogie',
		'Ruluko',
		'Rum Raisin',
		'Ruslan Display',
		'Russo One',
		'Ruthie',
		'Rye',
		'Sacramento',
		'Sail',
		'Salsa',
		'Sanchez',
		'Sancreek',
		'Sansita One',
		'Sarina',
		'Sarpanch',
		'Satisfy',
		'Scada',
		'Schoolbell',
		'Seaweed Script',
		'Sevillana',
		'Seymour One',
		'Shadows Into Light',
		'Shadows Into Light Two',
		'Shanti',
		'Share',
		'Share Tech',
		'Share Tech Mono',
		'Shojumaru',
		'Short Stack',
		'Siemreap',
		'Sigmar One',
		'Signika',
		'Signika Negative',
		'Simonetta',
		'Sintony',
		'Sirin Stencil',
		'Six Caps',
		'Skranji',
		'Slabo 13px',
		'Slabo 27px',
		'Slackey',
		'Smokum',
		'Smythe',
		'Sniglet',
		'Snippet',
		'Snowburst One',
		'Sofadi One',
		'Sofia',
		'Sonsie One',
		'Sorts Mill Goudy',
		'Source Code Pro',
		'Source Sans Pro',
		'Source Serif Pro',
		'Special Elite',
		'Spicy Rice',
		'Spinnaker',
		'Spirax',
		'Squada One',
		'Stalemate',
		'Stalinist One',
		'Stardos Stencil',
		'Stint Ultra Condensed',
		'Stint Ultra Expanded',
		'Stoke',
		'Strait',
		'Sue Ellen Francisco',
		'Sunshiney',
		'Supermercado One',
		'Suwannaphum',
		'Swanky and Moo Moo',
		'Syncopate',
		'Tangerine',
		'Taprom',
		'Tauri',
		'Teko',
		'Telex',
		'Tenor Sans',
		'Text Me One',
		'The Girl Next Door',
		'Tienne',
		'Tinos',
		'Titan One',
		'Titillium Web',
		'Trade Winds',
		'Trocchi',
		'Trochut',
		'Trykker',
		'Tulpen One',
		'Ubuntu',
		'Ubuntu Condensed',
		'Ubuntu Mono',
		'Ultra',
		'Uncial Antiqua',
		'Underdog',
		'Unica One',
		'UnifrakturCook',
		'UnifrakturMaguntia',
		'Unkempt',
		'Unlock',
		'Unna',
		'VT323',
		'Vampiro One',
		'Varela',
		'Varela Round',
		'Vast Shadow',
		'Vesper Libre',
		'Vibur',
		'Vidaloka',
		'Viga',
		'Voces',
		'Volkhov',
		'Vollkorn',
		'Voltaire',
		'Waiting for the Sunrise',
		'Wallpoet',
		'Walter Turncoat',
		'Warnes',
		'Wellfleet',
		'Wendy One',
		'Wire One',
		'Yanone Kaffeesatz',
		'Yellowtail',
		'Yeseva One',
		'Yesteryear',
		'Zeyada',
	);

	if( $type ) {
		return $fonts[$type];
	} else {
		return $fonts;
	}
}
}

if( !function_exists( 'kriya_font_style' )){
function kriya_font_style() {

	$font_styles = array( '100'		=> '100 Thin',
		'100italic'	=> '100 Thin Italic',
		'200'		=> '200 Extra-Light',
		'200italic'	=> '200 Extra-Light Italic',
		'300'		=> '300 Light',
		'300italic'	=> '300 Light Italic',
		'400'		=> '400 Regular',
		'400italic'	=> '400 Regular Italic',
		'500'		=> '500 Medium',
		'500italic'	=> '500 Medium Italic',
		'600'		=> '600 Semi-Bold',
		'600italic'	=> '600 Semi-Bold Italic',
		'700'		=> '700 Bold',
		'700italic'	=> '700 Bold Italic',
		'800'		=> '800 Extra-Bold',
		'800italic'	=> '800 Extra-Bold Italic',
		'900'		=> '900 Black',
		'900italic'	=> '900 Black Italic' );
	
	return $font_styles;
}
}

/**
 * Register footer widget area
 */
if( !function_exists( 'kriya_footer_widgetarea' )){
function kriya_footer_widgetarea( $count ) {
	$name = esc_html__ ( "Footer Column", 'kriya' );
	if ($count <= 4) :
		for($i = 1; $i <= $count; $i ++) :
			register_sidebar ( array (
				'name' => $name . "-{$i}",
				'id' => "footer-sidebar-{$i}",
				'description' => esc_html__('Appears in the footer section of the site.', 'kriya'),
				'before_widget' => '<aside id="%1$s" class="widget %2$s">',
				'after_widget' => '</aside>',
				'before_title' => '<h3 class="widgettitle">',
				'after_title' => '</h3>'
			) );
		endfor;
	 elseif ($count == 5 || $count == 6) :
		$a = array ("1-4", "1-4", "1-2" );
		$a = ($count == 5) ? $a : array_reverse ( $a );
		foreach ( $a as $k => $v ) :
			register_sidebar ( array (
				'name' => $name . "-{$v}",
				'id' => "footer-sidebar-{$k}-{$v}",
				'description' => esc_html__('Appears in the footer section of the site.', 'kriya'),
				'before_widget' => '<aside id="%1$s" class="widget %2$s">',
				'after_widget' => '</aside>',
				'before_title' => '<h3 class="widgettitle">',
				'after_title' => '</h3>'
			) );
		endforeach;
	 elseif ($count == 7 || $count == 8) :
		$a = array ("1-4", "3-4");
		$a = ($count == 7) ? $a : array_reverse ( $a );
		foreach ( $a as $k => $v ) :
			register_sidebar ( array (
				'name' => $name . "-{$v}",
				'id' => "footer-sidebar-{$k}-{$v}",
				'description' => esc_html__('Appears in the footer section of the site.', 'kriya'),
				'before_widget' => '<aside id="%1$s" class="widget %2$s">',
				'after_widget' => '</aside>',
				'before_title' => '<h3 class="widgettitle">',
				'after_title' => '</h3>'
			) );
		endforeach;
	elseif ($count == 9 || $count == 10) :
		$a = array ("1-3", "2-3");
		$a = ($count == 9) ? $a : array_reverse ( $a );
		foreach ( $a as $k => $v ) :
			register_sidebar ( array (
				'name' => $name . "-{$v}",
				'id' => "footer-sidebar-{$k}-{$v}",
				'description' => esc_html__('Appears in the footer section of the site.', 'kriya'),
				'before_widget' => '<aside id="%1$s" class="widget %2$s">',
				'after_widget' => '</aside>',
				'before_title' => '<h3 class="widgettitle">',
				'after_title' => '</h3>'
			) );
		endforeach;
	elseif( $count == 11 ):
		$a = array ( "1-4", "1-2", "1-4" );
		foreach ( $a as $k => $v ) :
			register_sidebar ( array (
				'name' => $name . "-{$v}",
				'id' => "footer-sidebar-{$k}-{$v}",
				'description' => esc_html__('Appears in the footer section of the site.', 'kriya'),
				'before_widget' => '<aside id="%1$s" class="widget %2$s">',
				'after_widget' => '</aside>',
				'before_title' => '<h3 class="widgettitle">',
				'after_title' => '</h3>'
			) );
		endforeach;
	endif;
}
}
/**
 * Show footer widget area in front end
 */
if( !function_exists( 'kriya_show_footer_widgetarea' )){
function kriya_show_footer_widgetarea( $count ) {

	$classes = array (
		"1" => "dt-sc-full-width",
		"dt-sc-one-half",
		"dt-sc-one-third",
		"dt-sc-one-fourth",
		"1-2" => "dt-sc-one-half",
		"1-3" => "dt-sc-one-third",
		"1-4" => "dt-sc-one-fourth",
		"3-4" => "dt-sc-three-fourth",
		"2-3" => "dt-sc-two-third" );

	if ($count <= 4) :
		for($i = 1; $i <= $count; $i ++) :

			$class = $classes [$count];
			$class = esc_attr( $class );

			$first = ($i == 1) ? "first" : "";
			$first = esc_attr( $first );

			echo "<div class='column {$class} {$first}'>";
				if (function_exists ( 'dynamic_sidebar' ) && dynamic_sidebar ( "footer-sidebar-{$i}" )) : endif;
			echo "</div>";
		endfor;
	elseif ($count == 5 || $count == 6) :

		$a = array (
			"1-4",
			"1-4",
			"1-2" );

		$a = ($count == 5) ? $a : array_reverse ( $a );
		foreach ( $a as $k => $v ) :
			$class = $classes [$v];
			$class = esc_attr( $class );

			$first = ($k == 0 ) ? "first" : "";
			$first = esc_attr( $first );

			echo "<div class='column {$class} {$first}'>";
				if (function_exists ( 'dynamic_sidebar' ) && dynamic_sidebar ( "footer-sidebar-{$k}-{$v}" )) : endif;
			echo "</div>";
		endforeach;
	elseif ($count == 7 || $count == 8) :
		$a = array (
			"1-4",
			"3-4");

		$a = ($count == 7) ? $a : array_reverse ( $a );
		foreach ( $a as $k => $v ) :
			$class = $classes [$v];
			$class = esc_attr( $class );

			$first = ($k == 0 ) ? "first" : "";
			$first = esc_attr( $first );


			echo "<div class='column {$class} {$first}'>";
				if (function_exists ( 'dynamic_sidebar' ) && dynamic_sidebar ( "footer-sidebar-{$k}-{$v}" )) :endif;
			echo "</div>";
		endforeach;
	elseif ($count == 9 || $count == 10) :
		$a = array ( 
			"1-3",
			"2-3" );
		$a = ($count == 9) ? $a : array_reverse ( $a );

		foreach ( $a as $k => $v ) :
			$class = $classes [$v];
			$class = esc_attr( $class );

			$first = ($k == 0 ) ? "first" : "";
			$first = esc_attr( $first );

			echo "<div class='column {$class} {$first}'>";
				if (function_exists ( 'dynamic_sidebar' ) && dynamic_sidebar ( "footer-sidebar-{$k}-{$v}" )) :endif;
			echo "</div>";
		endforeach;
	elseif( $count == 11 ):
		$a = array ( "1-4", "1-2", "1-4" );
		foreach ( $a as $k => $v ) :
			$class = $classes [$v];
			$class = esc_attr( $class );
			$eclass = '';

			if( $k == 0 ) {
				$eclass = "alignright first";
			}elseif( $k == 1) {
				$eclass = "aligncenter";
			}
			$eclass = esc_attr( $eclass );

			echo "<div class='column {$class} {$eclass}'>";
				if (function_exists ( 'dynamic_sidebar' ) && dynamic_sidebar ( "footer-sidebar-{$k}-{$v}" )) :endif;
			echo "</div>";
		endforeach;
	endif;
}
}
/**
 *  Kriya comment style
 */
if( !function_exists( 'kriya_comment_style' )){
function kriya_comment_style( $comment, $args, $depth ) {
	$GLOBALS['comment'] = $comment;
	switch ($comment->comment_type ) :
	case 'pingback':
	case 'trackback':
		echo '<li class="post pingback outer-frame-border">';
		echo "<p>";
		esc_html_e('Pingback:', 'kriya');
		comment_author_link();
		edit_comment_link(esc_html__('Edit', 'kriya'), ' ', '');
		echo "</p>";
		break;

	default:
	case '':
		echo "<li ";
		echo ' id="li-comment-';
		comment_ID();
		echo '">';
		echo '<article class="comment outer-frame-border" id="comment-';
		comment_ID();
		echo '">';

		echo '<header class="comment-author">'.get_avatar($comment, 450).'</header>';

		echo '<section class="comment-details">';
		echo '	<div class="author-name">';
		echo 		comment_reply_link(array_merge($args, array('reply_text' => ucfirst(get_comment_author_link()) , 'depth' => $depth, 'max_depth' => $args['max_depth'])));
		echo '		<span class="commentmetadata"> / '.get_comment_date('d M Y').'</span>';
		echo '	</div>';		
		echo '  <div class="comment-body">';
					comment_text();
					if ($comment->comment_approved == '0') :
						esc_html_e('Your comment is awaiting moderation.', 'kriya');
					endif;
					edit_comment_link(esc_html__('Edit', 'kriya'));
		echo '	</div>';
		echo '	<div class="reply">';
		echo 		comment_reply_link(array_merge($args, array('reply_text' => esc_html__('Reply', 'kriya'), 'depth' => $depth, 'max_depth' => $args['max_depth'])));
		echo '	</div>';
		echo '</section>';
		echo '</article><!-- .comment-ID -->';
		break;
	endswitch;
}
}

/**
 *  Kriya show sidebar
 */
if( !function_exists( 'kriya_show_sidebar' )){
function kriya_show_sidebar( $type, $id, $position = 'right' ) {
	
	if( $type == 'page' ){
		$settings = get_post_meta($id,'_tpl_default_settings',TRUE);
		
		if($GLOBALS['enable_global_page_layout'] == true){
			$sidebar = 'standard-sidebar';
			if( is_active_sidebar( $sidebar ) ){
				dynamic_sidebar($sidebar);
			}
			return(1);
		}
	} elseif( $type == 'post' ){
		
		$settings = get_post_meta($id,'_dt_post_settings',TRUE);

		if($GLOBALS['enable_global_post_layout'] == true){
			$sidebar = 'standard-sidebar';
			if( is_active_sidebar( $sidebar ) ){
				dynamic_sidebar($sidebar);
			}
			return(1);
		}
	} elseif( $type == 'dt_portfolios' ){
		
		$settings = get_post_meta($id,'_portfolio_settings',TRUE);
	} else {
		
		$settings = get_post_meta($id,'_custom_settings',TRUE);		
	}
	
	$settings = is_array($settings) ? $settings  : array();
	
	$k = 'show-standard-sidebar-'.$position;
	if( isset($settings[$k]) ){
		$sidebar = 'standard-sidebar';
		if( is_active_sidebar( $sidebar ) ){
			dynamic_sidebar($sidebar);
		}
	}

	$k = 'widget-area-'.$position;
	if( array_key_exists($k, $settings) ){
		foreach($settings[$k] as $widgetarea ){
			$id = mb_convert_case($widgetarea, MB_CASE_LOWER, "UTF-8");

			if( is_active_sidebar($id) ){
				dynamic_sidebar($id);
			}
		}
	}
}
}

/**
 * Hexadecimal to RGB color conversion
 */
if( !function_exists('kriya_hex2rgb') ) {

	function kriya_hex2rgb( $hex ) {

		$hex = str_replace ( "#", "", $hex );

		if (strlen ( $hex ) == 3) :
			$r = hexdec ( substr ( $hex, 0, 1 ) . substr ( $hex, 0, 1 ) );
			$g = hexdec ( substr ( $hex, 1, 1 ) . substr ( $hex, 1, 1 ) );
			$b = hexdec ( substr ( $hex, 2, 1 ) . substr ( $hex, 2, 1 ) );
		 else :
			$r = hexdec ( substr ( $hex, 0, 2 ) );
			$g = hexdec ( substr ( $hex, 2, 2 ) );
			$b = hexdec ( substr ( $hex, 4, 2 ) );
		endif;
		
		$rgb = array($r, $g, $b);
		return $rgb;
	}
}

/**
 * Get global variables
 */

if( !function_exists( 'kriya_global_variables' )){
function kriya_global_variables($variable = '') {

	global $post, $wp_query, $pagenow, $kriya_like_love;

	switch($variable) {
		case 'post':
			return $post;
		break;
		case 'wp_query':
			return $wp_query;
		break;
		case 'pagenow':
			return $pagenow;
		break;
		case 'kriya_like_love':
			return $kriya_like_love;
		break;
	}
	
	return false;
}
}
/*
 * Get Current Post or Page ID
 */
if( !function_exists( 'kriya_ID' )){
function kriya_ID() {

	$post = kriya_global_variables('post');

	$postID = false;

	if( ! is_404() ){

		if( function_exists('is_woocommerce') && is_woocommerce() ){

			$postID = wc_get_page_id( 'shop' );

		} elseif( is_search() ){

			$postID = false;

		} else {

			$postID = get_the_ID();

		}
	}

	return $postID;
}
}

/* ---------------------------------------------------------------------------
 * Styles Minify
 * --------------------------------------------------------------------------- */
if( !function_exists( 'kriya_styles_minify' )){
function kriya_styles_minify( $css ){

	// remove comments
	$css = preg_replace( '!/\*[^*]*\*+([^/][^*]*\*+)*/!', '', $css );	

	// remove whitespace
	$css = str_replace( array("\r\n", "\r", "\n", "\t", '  ', '    ', '    '), '', $css );

	return $css;
}
}
/* ---------------------------------------------------------------------------
 *  Check attachment url for SSL
 * --------------------------------------------------------------------------- */
if( !function_exists( 'kriya_ssl_attachments' )){
add_filter( 'wp_get_attachment_url', 'kriya_ssl_attachments' );
function kriya_ssl_attachments( $url ) {
	if( is_ssl() ){
		return str_replace('http://', 'https://', $url);
	}
	
	return $url;
}
}
/* ---------------------------------------------------------------------------
 *  Unyson Page Bilder Disable
 * --------------------------------------------------------------------------- */


if ( ! function_exists( 'dt_theme_array_whitelist_assoc' ) ) {
		function dt_theme_array_whitelist_assoc( Array $array1, Array $array2 ) {
			if ( func_num_args() > 2 ) {
				$args = func_get_args();
				array_shift( $args );
				$array2 = call_user_func_array( 'array_merge', $args );
			}

			return array_intersect_key( $array1, array_flip( $array2 ) );
		}
	}

/* ---------------------------------------------------------------------------
	* Post Type Support
	* --------------------------------------------------------------------------- */
	if ( ! function_exists( 'dt_theme_limit_post_types_support' ) ) {
	add_filter( 'fw_ext_page_builder_supported_post_types', 'dt_theme_limit_post_types_support', 1 );
	function dt_theme_limit_post_types_support( $all_post_types ) {
		$white_listed_post_types = array( '' ); //allowed custom post type names
		$post_types              = dt_theme_array_whitelist_assoc( $all_post_types, $white_listed_post_types );
		return $post_types;
	}
}